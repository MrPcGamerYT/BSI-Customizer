@echo off
call "%~dp0RUN-UI.cmd" --export-sources "%~dp0PLANNED-ALL-UI-SOURCES.zip" %*
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
