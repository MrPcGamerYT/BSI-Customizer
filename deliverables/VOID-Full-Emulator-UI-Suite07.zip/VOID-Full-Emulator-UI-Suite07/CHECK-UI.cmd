@echo off
call "%~dp0RUN-UI.cmd" --check --report "%~dp0UI-COVERAGE.json" %*
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
