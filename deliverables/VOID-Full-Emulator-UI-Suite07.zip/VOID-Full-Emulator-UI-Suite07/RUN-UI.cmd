@echo off
setlocal
set "PYTHONUTF8=1"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 "%~dp0VOID-Full-UI.py" %*
exit /b %errorlevel%
:python
where python >nul 2>nul
if errorlevel 1 goto missing
python "%~dp0VOID-Full-UI.py" %*
exit /b %errorlevel%
:missing
echo Python 3.9+ is required. No files were changed.
exit /b 1
