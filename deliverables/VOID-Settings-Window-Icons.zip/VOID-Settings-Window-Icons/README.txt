VOID / SETTINGS WINDOW ICONS
Developed By NOVA XIS
https://www.youtube.com/@nova_xis20

12 original, distinct Settings-tab symbols matched to the black/silver emulator screenshot.
Transparent backgrounds. 24-unit viewBox, 1.65-unit rounded strokes.
States: normal silver, hover/selected white, optional accent red, disabled muted grey.
The screenshot uses WHITE selected icons with red controls; use hover/ for that look.
Red accent versions are optional, not a requirement to recolor the UI.

svg/: scalable editable source, compatible with the static-SVG importer.
png-24/ and png-48/: transparent PNGs at native and 2x size.
preview.png: enlarged design sheet, NOT an emulator screenshot.

Use Player Interface's Settings-panel custom icon picker when available, or map an exact
SVG resource in Emulator UI Studio after a manual scan. Tab IDs/resources vary by player.
No guessed resource mappings, QML patch, profile or EXE modification is included. Merely
copying these files into Assets does not attach them to native Settings.
These assets have not been applied to the emulator. Boot files remain unchanged.
