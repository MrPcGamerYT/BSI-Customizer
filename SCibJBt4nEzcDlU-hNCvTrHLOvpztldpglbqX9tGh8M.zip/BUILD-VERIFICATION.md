# Build verification

Built with MinGW-w64 x64 GCC/G++:

- `dist/Z-Lag.dll`
- `dist/libZLag.dll.a`
- The x64 host import example linked successfully.

Static checks confirmed:

- The DLL is a PE32+ x86-64 DLL.
- Its only named export is the native `ZLagImportAnchor` function.
- The sample host's import table names `Z-Lag.dll` and `ZLagImportAnchor`.
- No proxy export table or remote injector is part of this project.

The HWID code is compile-checked but the Firestore request was not run. The DLL has not been runtime-tested on Windows or against the target host's OpenGL implementation. Compile and PE-table checks do not prove successful authorization or visual effects.
