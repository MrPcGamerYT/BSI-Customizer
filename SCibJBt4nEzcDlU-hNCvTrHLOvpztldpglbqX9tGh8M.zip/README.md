# Z-Lag Native x64 DLL — import-loaded build

Rebuildable Windows x64 DLL project for a host executable you build or are authorized to modify. It uses the first archive's OpenGL overlay and post-processing source as its base. This is a **clean visual-effects extraction, not a literal merge of every feature in both archives**: the second archive's process-control/protection behavior is intentionally omitted.

Windows loads the DLL through the host's ordinary PE import table. `DllMain` only checks the host name and schedules a worker; authentication, file/config work, and hook installation happen on that worker after `DllMain` returns.

## Included

- ImGui overlay and settings UI
- OpenGL post-processing/shader pipeline and presets
- Presentation hooks in the importing host process
- The legacy HWID-to-Firestore check described below
- First archive's optional optimizer/debloat UI controls (not run during DLL load; review before use)
- Import library and a small host-link example

## Legacy HWID behavior (important)

On each DLL load in the configured host, the worker reads `GetCurrentHwProfileA`'s hardware-profile GUID and sends it over HTTPS to the Firestore REST endpoint from the second archive. It accepts **any HTTP 200** as authorized; it does not inspect the document body or verify a field. A failed request or non-200 response prevents the Z-Lag overlay/hooks from starting, while the host process itself continues.

This transmits a persistent device identifier to Google Firestore automatically. The legacy API key and project path are embedded in `src/hwid_auth.cpp`; the key is not a secret. This check is a basic document-existence gate, not robust license enforcement. The legacy request has no explicit timeout override.

## Excluded

- `version.dll` proxy exports / proxy behavior
- Remote-process injection or an injector/patcher
- The second archive's anti-debug/anti-analysis watchers, process blacklist/termination, self-delete, and host self-termination code
- Its machine-wide BCD/registry/ADB boost actions

The second archive is a separate boost/protection DLL, not an additive rendering module. Its HWID check is the only behavior copied into this project; its process-control code is not.

## Build (x64)

Install MinGW-w64 x64 GCC/G++, GNU make, and Python 3, then run:

```sh
make
```

Outputs:

```text
dist/Z-Lag.dll
dist/libZLag.dll.a
```

## Add the normal import dependency to your x64 host

Link your own x64 host against the import library and place `Z-Lag.dll` beside it:

```sh
x86_64-w64-mingw32-g++ host.cpp -Ldist -lZLag -o HD-Player.exe
```

See [`host-import-example.cpp`](host-import-example.cpp). The example calls the no-op `ZLagImportAnchor` solely to ensure the import appears in the host's PE import table. It is **not** an initialization function; `DllMain` schedules the worker automatically. If your host has a different executable name, change `ZL_HOST_EXE` in `src/menuown.cpp` before building.

## OpenGL/runtime limits

The worker installs presentation hooks; OpenGL state/shaders/UI are initialized from the intercepted presentation path on the render thread when a compatible context exists. If the host uses another renderer or never calls the hooked swap functions, effects remain inactive. Compile/import-table checks do not prove visual operation; test on a Windows development build of your authorized host. Keep a clean backup.

## Verification boundary

The x64 DLL and sample host link were compile-checked, and the DLL export/import tables were inspected. Actual HWID network authorization and visual rendering have not been runtime-tested on Windows.

## License notes

This project retains the source tree's license notices. ImGui and MinHook notices are in `src/imgui/LICENSE.txt` and `src/minhook/LICENSE.txt`.
