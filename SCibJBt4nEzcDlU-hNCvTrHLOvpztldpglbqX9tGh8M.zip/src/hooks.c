/* =====================================================================
 *  hooks.c  --  presentation hooks + per-frame orchestration
 *
 *  Two lanes, decided by what the host actually imports:
 *    wglSwapBuffers   (opengl32, libOpenglRender, libGLESv2)
 *    eglSwapBuffers   (libEGL / ANGLE / libOpenglRender)
 *
 *  Frame order (this is the whole trick):
 *    1. emulator renders its Android frame into the back buffer
 *    2. our detour fires before the real swap
 *    3. zl_gl_render_frame() grades that back buffer in place
 *    4. overlay menu / OSD is drawn ON TOP of the graded frame
 *    5. the real SwapBuffers presents everything at once
 *
 *  If anything fails, the detour forwards straight through and the
 *  emulator behaves exactly like it did without us.
 * ===================================================================== */
#include "common.h"
#include "menuwin.h"
#include "zlag_imgui.h"
#include "gl_loader.h"

#include "MinHook.h"

typedef BOOL (WINAPI* PFN_wglSwapBuffers)(HDC);
typedef BOOL (WINAPI* PFN_eglSwapBuffers)(void*, void*);
typedef BOOL (WINAPI* PFN_eglSwapInterval)(void*, int);
typedef BOOL (WINAPI* PFN_wglSwapIntervalEXT)(int);

static PFN_wglSwapBuffers     o_wglSwapBuffers    = NULL;
static PFN_eglSwapBuffers     o_eglSwapBuffers    = NULL;
static PFN_eglSwapInterval    o_eglSwapInterval   = NULL;
static PFN_wglSwapIntervalEXT o_wglSwapIntervalEXT = NULL;

static int  s_glReady   = 0;
static int  s_bootTried = 0;
static int  s_uiReady   = 0;

/* ------------------------------------------------------------------ */
/*  crash capture                                                      */
/*                                                                     */
/*  If this DLL ever faults, the log should say WHERE instead of the    */
/*  emulator just vanishing. The filter runs in the process, writes one */
/*  line with the exception code and the faulting module + offset, then */
/*  lets Windows handle it exactly as it would have. It changes no       */
/*  behaviour and installs nothing system-wide.                         */
/* ------------------------------------------------------------------ */
static LONG WINAPI zl_crash_filter(EXCEPTION_POINTERS* ep)
{
    static HMODULE s_self = NULL;
    if (!s_self)
        GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)&zl_crash_filter, &s_self);

    if (ep && ep->ExceptionRecord) {
        void* addr = ep->ExceptionRecord->ExceptionAddress;
        HMODULE hmod = NULL;
        unsigned long long rva = 0;
        unsigned int where = 2;          /* 0 = us, 1 = the emulator, 2 = other */
        MEMORY_BASIC_INFORMATION mbi;

        if (VirtualQuery(addr, &mbi, sizeof(mbi)) &&
            GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                               GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                               (LPCSTR)addr, &hmod) && hmod) {
            rva = (unsigned long long)((char*)addr - (char*)hmod);
            if (hmod == s_self) where = 0;
            else {
                char path[MAX_PATH];
                GetModuleFileNameA(hmod, path, MAX_PATH);
                if (strstr(path, "HD-Player")) where = 1;
            }
        }
        zl_priv_crash((unsigned int)ep->ExceptionRecord->ExceptionCode, rva,
                      (unsigned int)GetCurrentThreadId(), where);
        zl_log(LOG_ERR, "unexpected error 0x%08lX",
               (unsigned long)ep->ExceptionRecord->ExceptionCode);
    }
    return EXCEPTION_EXECUTE_HANDLER;   /* do not swallow: let it proceed */
}

/* ------------------------------------------------------------------ */
/*  fps timing                                                         */
/* ------------------------------------------------------------------ */
static LARGE_INTEGER s_freq, s_tLast;
static int   s_tInit = 0;
static float s_avgMs = 16.6f;
static DWORD s_winStart = 0;
static int   s_winFrames = 0;

static void tick_timer(void)
{
    if (!s_tInit) {
        QueryPerformanceFrequency(&s_freq);
        QueryPerformanceCounter(&s_tLast);
        s_tInit = 1;
        return;
    }
    LARGE_INTEGER now; QueryPerformanceCounter(&now);
    double ms = (double)(now.QuadPart - s_tLast.QuadPart) * 1000.0 /
                (double)s_freq.QuadPart;
    s_tLast = now;
    if (ms > 0.0 && ms < 500.0)
        s_avgMs = s_avgMs * 0.90f + (float)ms * 0.10f;

    DWORD t = GetTickCount();
    if (!s_winStart) { s_winStart = t; s_winFrames = 0; }
    s_winFrames++;
    if (t - s_winStart >= 1000) {
        g_state.fps    = (LONG)(s_winFrames * 1000 / (DWORD)(t - s_winStart));
        g_state.frameMs = (LONG)s_avgMs;
        s_winStart = t;
        s_winFrames = 0;
    }
}

/* ------------------------------------------------------------------ */
/*  first-present boot: everything that needs a live GL context        */
/* ------------------------------------------------------------------ */
static volatile LONG s_winLaneInited = 0;
static volatile LONG s_autoOpened = 0;

/* The external panel and its F2 listener need no emulator swap or shader
 * chain. Start them after settings load, even for a non-GL renderer. */
void zl_external_menu_boot(void)
{
#ifndef ZL_NO_MENUWIN
    if (!g_cfg.menuWindow) return;
    if (InterlockedCompareExchange(&s_winLaneInited, 1, 0) != 0) return;
    InterlockedExchange(&s_autoOpened, 1);
    InterlockedExchange(&g_state.menuWanted, g_cfg.autoOpen ? 1 : 0);
    InterlockedExchange(&g_state.menuOpen, g_cfg.autoOpen ? 1 : 0);
    if (zl_menuwin_start())
        zl_log(LOG_OK, "external menu thread started (F2 toggle)");
    else
        zl_log(LOG_ERR, "external menu thread could not be started");
#endif
}

static void boot_once(HDC hdc)
{
    /* Armed before the GL chain: needs no context, no window and no focus,
     * so it survives a host that swallows every key it sees. */
    zl_hotkey_register();

    s_bootTried = 1;
    g_state.pid      = GetCurrentProcessId();
    g_state.threadId = GetCurrentThreadId();

    if (!zgl_load()) {
        zl_log(LOG_ERR, "no GL2 entry points on the render thread");
        return;
    }

    const char* v = (const char*)zgl.glGetString(GL_VENDOR);
    const char* r = (const char*)zgl.glGetString(GL_RENDERER);
    const char* g = (const char*)zgl.glGetString(GL_VERSION);
    lstrcpynA(g_state.glVendor,   v ? v : "?", sizeof(g_state.glVendor));
    lstrcpynA(g_state.glRenderer, r ? r : "?", sizeof(g_state.glRenderer));
    lstrcpynA(g_state.glVersion,  g ? g : "?", sizeof(g_state.glVersion));
    zl_log(LOG_INFO, "GL context up | VENDOR=%s | RENDERER=%s | VERSION=%s",
           g_state.glVendor, g_state.glRenderer, g_state.glVersion);
    {
        const char* sl = (const char*)zgl.glGetString(0x8B8C);   /* GL_SHADING_LANGUAGE_VERSION */
        if (sl) zl_log(LOG_INFO, "GLSL in use: %s", sl);
    }

    if (hdc) {
        HWND hw = WindowFromDC(hdc);
        if (hw) {
            char cls[128] = {0};
            GetClassNameA(hw, cls, sizeof(cls) - 1);
            zl_log(LOG_INFO, "render window %p class='%s'", (void*)hw, cls);
            zl_input_install(hw);
        }
    }
    if (!g_state.hookedWgl && !g_state.hookedEgl)
        zl_input_install_fallback_hook();

    s_glReady = zl_gl_init();
    if (!s_glReady) {
        zl_log(LOG_WARN, "post-process chain unavailable -- overlay stays idle");
        return;
    }
    s_uiReady = zl_ui_init_once();
    if (s_uiReady) zl_ui_toast("Z-Lag ready -- press F2 for the panel");

    /* Open the panel here as well. If the host ever presents, this is
     * already true by the time the first graded frame is drawn, so the
     * panel cannot "forget" to appear because the swap-side check was
     * skipped. zl_autoopen_tick() is once-only whatever calls it. */
    /* ---- lane 2: the same menu, as a real Windows window --------------
     * Created on its own thread, WS_EX_APPWINDOW, so it shows up in
     * Alt+Tab and the taskbar and takes clicks and keyboard focus like any
     * other window. Gated on a config switch rather than compiled out,
     * because both lanes share one ImGui frame builder and the renderer
     * tells them apart by DC (zl_menuwin_is_ours) -- running both at once
     * is what the crash in R68 was about. */
    zl_autoopen_tick();

    /* ---- visibility knobs, for hosts where the pill does not show ----
     * ZLAG_LAUNCHER=force   draw the pill even if the OSD is switched off
     * ZLAG_SELFTEST=1       write zlag-selftest.txt at boot            */
    g_cfg.launcherForced = 0;
    {
        char e[32];
        DWORD n = GetEnvironmentVariableA("ZLAG_LAUNCHER", e, sizeof(e));
        if (n && (e[0] == 'f' || e[0] == 'F')) {
            g_cfg.launcherForced = 1;
            zl_log(LOG_INFO, "launcher forced visible (ZLAG_LAUNCHER)");
        }
        n = GetEnvironmentVariableA("ZLAG_SELFTEST", e, sizeof(e));
        if (n) {
            zl_selftest();
        }
    }

    /* No boot marker. The overlay's own button is on screen from the first
     * frame, which is the only proof of life anyone needs, and the rule for
     * this build is that the emulator's surface carries the button and
     * nothing else -- not even for a few seconds at startup. */
}

/* ------------------------------------------------------------------ */
/*  per-frame                                                          */
/* ------------------------------------------------------------------ */
static volatile LONG s_applyThreadBusy = 0;
static int s_selftestLate = 0;

static DWORD WINAPI apply_worker(LPVOID mask)
{
    int m = (int)(INT_PTR)mask;
    if (m & ZL_APPLY_RESETHOOKS) {
        zl_hooks_install();
        zl_log(LOG_OK, "presentation hooks re-scanned (wgl=%d egl=%d)",
               (int)g_state.hookedWgl, (int)g_state.hookedEgl);
        m &= ~ZL_APPLY_RESETHOOKS;
    }
    zl_optimizer_run(m);

    /* temp clean owns no bits in the mask: it walks the disk and can take
     * a second, so it gets its own flag and its own lane on this worker */
    if (InterlockedExchange((volatile LONG*)&zl_pending_tempclean, 0))
        zl_host_tempclean();
    InterlockedExchange((volatile LONG*)&s_applyThreadBusy, 0);
    return 0;
}

volatile DWORD zl_last_apply_tick = 0;

static void drain_pending_actions(void)
{
    LONG mask = InterlockedExchange((LONG*)&zl_pending_apply, 0);
    if (!mask) return;
    zl_last_apply_tick = GetTickCount();

    /* RESETHOOKS is cheap and must run on this thread's account only via
     * a worker -- MinHook re-enabling is not thread-affine, so a worker
     * is fine and keeps the render loop clean. */
    if (InterlockedCompareExchange(&s_applyThreadBusy, 1, 0) != 0) {
        InterlockedOr((LONG*)&zl_pending_apply, mask);
        return;
    }
    HANDLE h = CreateThread(NULL, 0, apply_worker, (LPVOID)(INT_PTR)mask, 0, NULL);
    if (h) CloseHandle(h);
    else {
        /* Do not lose an explicitly requested action when thread creation
         * fails. The menu or present thread will retry the queued mask. */
        InterlockedOr((LONG*)&zl_pending_apply, mask);
        InterlockedExchange(&s_applyThreadBusy, 0);
    }
}

/* The external menu exists even without a GL present hook. Allow its thread
 * to start the same background worker rather than silently losing ADB work. */
void zl_dispatch_pending_actions(void)
{
    drain_pending_actions();
}

/* Re-attempt hooking until something sticks: at proxy-load time the
 * emulator has not loaded libEGL / libOpenglRender yet, so the install
 * pass in zlag_worker is a first try, not the only one. */
static void retry_hooks(void)
{
    static DWORD last = 0;
    static int tries = 0;
    DWORD now = GetTickCount();
    if (g_state.hookedWgl || g_state.hookedEgl || tries > 12) return;
    if (last && now - last < 500) return;
    last = now;
    tries++;
    zl_hooks_install();

    /* The texture lane lives or dies on these pointers. If the first boot
     * ran before the host had a context, they were never filled in and
     * the potato slider had nothing to hook -- silently, forever. */
    if (!zgl_have()) {
        static DWORD lastZ = 0;
        DWORD nz = GetTickCount();
        if (!lastZ || nz - lastZ > 2000) {
            lastZ = nz;
            if (zgl_load()) zl_log(LOG_OK, "GL entry points picked up on a retry");
        }
    }

    /* Registered before the GL chain, on purpose: this lane works even if
     * the host never gives us a usable context, and even if it swallows
     * every key it sees. Ctrl+Shift+7 and Ctrl+Alt+7 wake the panel. */
    zl_hotkey_register();      /* MH_CreateHook on an existing hook is a no-op */
}

static DWORD s_lastPresent = 0;
static void* s_lastEglDpy = NULL;   /* for live swap-interval changes */

/* ------------------------------------------------------------------ */
/*  How much of the frame is OUR fault?                                */
/*                                                                     */
/*  Every frame this lane does a full GL state snapshot and restore    */
/*  (zl_gl_begin/end) plus the shader chain. That is the only CPU cost */
/*  the product adds, and until it was measured nobody could say whether*/
/*  the overlay was the thing eating frames or the emulator was.       */
/*  Two QueryPerformanceCounter calls per frame -- about 40 ns -- buys  */
/*  an honest number in the panel.                                     */
/* ------------------------------------------------------------------ */
static LARGE_INTEGER s_qpf, s_costT0;
static int s_qpfInit = 0;

static void cost_begin(void)
{
    if (!s_qpfInit) { QueryPerformanceFrequency(&s_qpf); s_qpfInit = 1; }
    QueryPerformanceCounter(&s_costT0);
}

static void cost_end(void)
{
    LARGE_INTEGER t1;
    LONGLONG us;
    QueryPerformanceCounter(&t1);
    us = (t1.QuadPart - s_costT0.QuadPart) * 1000000 / s_qpf.QuadPart;
    g_state.ovMicros    = (LONG)us;
    g_state.ovMicrosAvg = (LONG)(((LONGLONG)g_state.ovMicrosAvg * 15 + us) / 16);
}

static void frame_common(HDC hdc)
{
    /* Frame counter, published on the SELF-TEST page only. Deliberately no
     * longer called "swaps" in the UI: wglSwapBuffers and eglSwapBuffers are
     * both furiously deprecated by every vendor (ANGLE removed them, some
     * drivers present through WGL_DX_INTEROP or a private entry), so a
     * number in the UI named after the function we happen to hook is a lie
     * about what the emulator is doing -- and it read as "the overlay runs
     * on your swap chain", which is the complaint. It is now just a count of
     * frames the overlay has ticked on. */
    g_state.lastSwaps++;

    /* Counted HERE, before every early return below. It used to run after
     * the "GL pipeline not ready" bail-out, so on any machine where the
     * shader init fails the frame timer never ticked once and every fps
     * readout in the panel sat at 0 -- the counter looked broken when it
     * was only gated behind a feature that has nothing to do with frame
     * timing. Counting frames needs no GL context. */
    tick_timer();

    retry_hooks();

    /* optional frame limiter -- applies before we present, so it caps the
     * rate the emulator can actually put on screen */
    if (g_cfg.fpsCap > 0 && g_cfg.fpsCap <= 480) {
        DWORD budget = 1000 / (DWORD)g_cfg.fpsCap;
        DWORD now = GetTickCount();
        if (s_lastPresent) {
            DWORD spent = now - s_lastPresent;
            if (spent < budget) { Sleep(budget - spent); now = GetTickCount(); }
        }
        s_lastPresent = now;
    } else {
        s_lastPresent = 0;
    }

    if (!s_bootTried) {
        static int crashFilterSet = 0;
        if (!crashFilterSet) { crashFilterSet = 1; SetUnhandledExceptionFilter(zl_crash_filter); }
        boot_once(hdc);
    }

    /* --------------------------------------------------------------
     * These lanes do NOT need our shader chain, so they must not sit
     * behind the "GL pipeline not ready" bail-out below.
     *
     * They used to. zl_gl_init() can fail for reasons that have nothing
     * to do with the features here -- a context that rejects our shaders,
     * a driver in a mode we do not understand -- and when it did, the
     * early return skipped the dispatch queue and the texture lane along
     * with the drawing, so the panel stayed alive and responsive while
     * every effect did nothing at all. That is exactly the report:
     * "potato and optimization not working".
     *
     * Dispatching an action needs no context. Hooking a texture bind
     * needs no context either -- only the address of the function.
     * -------------------------------------------------------------- */
    drain_pending_actions();
    if (g_cfg.liteOn) {           /* off = the GL lane is never touched */
        zl_lite_tick();
        zl_lite_install_hooks();
    }

    /* the other backends: same rule, only while the feature is on */
    if (g_cfg.liteOn) zl_d3d_tick();

    /* Fallback for callers that did not start the window during attach. */
    zl_external_menu_boot();
    zl_autoopen_tick();

    /* rounded corners on the host's own window, if asked for */
    zl_round_tick(hdc);

    /* The cosmetic display multiplier. Deliberately NOT armed during the
     * first seconds of the process: it hooks ucrtbase's format routine,
     * which is called from CRT initialisation and from every log line, and
     * arming that while the host is still starting is how a panel ends up
     * never appearing. Ten seconds in, the process is settled. */
    {
        static int mulTried = 0;
        if (!mulTried && g_cfg.fpsMulPct > 1 && g_cfg.fpsMulPct != 100) {
            static int announcedOff = 0;
            if (!announcedOff) { announcedOff = 1;
                zl_log(LOG_INFO, "display multiplier is per-session: switch it on in the panel"); }
        }
    }
    /* A BlueStacks host can destroy and recreate its GL context (resolution
     * change, GL-mode switch, instance restart). If the first boot failed,
     * every frame is another chance -- the shaders may compile fine on the
     * new context. */
    if (!s_glReady) {
        if (g_state.lastSwaps % 60 == 0) {
            s_glReady = zl_gl_init();
            if (s_glReady && !s_uiReady) s_uiReady = zl_ui_init_once();
            if (s_glReady) zl_log(LOG_OK, "GL pipeline recovered on a later context");
        }
        if (!s_glReady) return;
    }
    if (s_glReady && !s_uiReady) s_uiReady = zl_ui_init_once();

    drain_pending_actions();

    /* texture-detail lane: counts frames for its cache re-stamp and keeps
     * trying to catch the GLES module, which can load long after us */
    zl_lite_tick();
    zl_lite_install_hooks();

    /* SetThreadExecutionState is per-thread: called from a worker it stops
     * working the moment that worker exits. This thread lives as long as the
     * emulator does, so the request is renewed from here, every 2 s. */
    if (g_keepAwake) {
        static DWORD s_lastAwake = 0;
        DWORD now2 = GetTickCount();
        if (now2 - s_lastAwake > 2000) {
            SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED |
                                    ES_DISPLAY_REQUIRED);
            s_lastAwake = now2;
        }
    }
    zl_input_watchdog();     /* hotkey survives fullscreen window swaps */

    /* Live vsync. Toggling the checkbox used to do nothing until the host
     * happened to call swap-interval itself, which is why it felt like it
     * needed a restart. We are on the render thread with this context
     * current right now, so the new interval can simply be set here. */
    {
        static int applied = -1;
        int want = g_cfg.vsyncOff ? 0 : 1;
        if (applied != want) {
            int ok = 0;
            if (o_wglSwapIntervalEXT) { o_wglSwapIntervalEXT(want); ok = 1; }
            else if (o_eglSwapInterval && s_lastEglDpy) {
                o_eglSwapInterval(s_lastEglDpy, want); ok = 1;
            }
            if (ok) {
                applied = want;
                zl_log(LOG_OK, "swap interval set live to %d", want);
            }
        }
    }

    /* The size the overlay draws at. GetDeviceCaps reports the DESKTOP, not
     * the GL surface -- in a fullscreen emulator those agree, but in a
     * window that is small (or mid mode-switch) they do not, and the overlay
     * ends up laid out for a surface that is not there. Prefer the real
     * drawable rect, and only fall back to the device caps when the window
     * rect is unavailable. */
    int w = 0, h = 0;
    /* The CLIENT RECT wins, and the GL viewport is only a fallback.
     *
     * This used to be the other way round, and it broke clicking. Mouse
     * messages arrive in client coordinates; if the UI lays itself out
     * against the GL viewport instead, then the moment the two disagree --
     * decorated window, DPI scaling, a driver that reports a padded
     * drawable -- the button is DRAWN in one place and HIT-TESTED in
     * another, by exactly the difference. Measured in the rig: pill drawn
     * at screen y 30..36, hit rect at 44..71. Fourteen pixels of dead
     * button, and no amount of clicking the thing you can see works.
     *
     * Laying out in client pixels makes the space the user points at and
     * the space ImGui draws into the same space, by construction. */
    {
        HWND hw = hdc ? WindowFromDC(hdc) : NULL;
        RECT rc = {0, 0, 0, 0};
        if (hw && GetClientRect(hw, &rc) &&
            rc.right > 0 && rc.bottom > 0 &&
            rc.right < 16384 && rc.bottom < 16384) {
            w = rc.right; h = rc.bottom;
        }
    }
    if (w <= 0 || h <= 0) {
        GLint vp[4] = {0, 0, 0, 0};
        zgl.glGetIntegerv(GL_VIEWPORT, vp);
        if (vp[2] > 0 && vp[3] > 0 && vp[2] < 16384 && vp[3] < 16384) {
            w = vp[2]; h = vp[3];
        }
    }
    if ((w <= 0 || h <= 0) && hdc) {
        w = GetDeviceCaps(hdc, HORZRES); h = GetDeviceCaps(hdc, VERTRES);
    }
    if (w <= 0 || h <= 0) { w = 1920; h = 1080; }
    if (w < 80 || h < 80) {
        /* a stalled or bogus viewport: keep the UI coherent rather than
         * laying it out for a surface that cannot exist */
        if (w < 80) w = 1280;
        if (h < 80) h = 720;
    }

    /* ---- open the panel by itself at startup ----------------------
     * Waits for a plausible surface first (a mode switch during launch
     * reports junk sizes), and for a handful of frames so the panel is
     * laid out against a real viewport instead of a guess. One shot per
     * process: if the user closes it, it stays closed. */
    /* Deliberately does NOT wait for the UI to have drawn: uiFrames only
     * starts counting once a frame succeeded, so gating on it means the
     * one machine where the UI is slow to come up is the one machine where
     * this never fires. It also does not wait for s_uiReady -- wanting the
     * panel open is state, not drawing. When the UI does come up it comes
     * up open. */
    zl_autoopen_tick();

    /* ---- EXTERNAL MODE: the menu is a real window, so this lane does
     * nothing at all -- no overlays, no render targets, no shaders.
     *
     * Both lanes draw the same ImGui frame, and the GL overlay lane rebuilds
     * its render targets whenever it sees a new surface size. With the menu
     * window also presenting, those sizes alternate 760x600 -> 1016x734 ->
     * 760x600 every frame, so the emulator's GL context spent its life
     * rebuilding framebuffers for a window that was not even the menu. That
     * is the crash, and it is also why the emulator dropped frames. */
    if (g_cfg.menuWindow) {
        /* ---- EXTERNAL MENU MODE: grade the game, just do not draw the menu
         * into it. ------------------------------------------------------
         *
         * This branch used to return here, so window mode disabled the
         * shader chain entirely: FXAA, bloom, saturation, contrast, sharpen
         * and every other effect did nothing, because zl_gl_render_frame()
         * is the function that does all of them. That was my mistake -- "do
         * not draw the menu over the game" was implemented as "do not touch
         * the game at all", and those are different things.
         *
         * What the menu window actually made unsafe was the second half of
         * this function: the ImGui pass. The menu window presents on its own
         * GL context in this same process, its presents reach this same
         * hook, and with two surface sizes alternating 760x600 -> 1016x734
         * the pipeline rebuilt its render targets every frame from another
         * thread. That is what crashed, and that is what stays out.
         *
         * So: run the pipeline exactly as the in-game lane does, then skip
         * only step 2 (the ImGui draw). The game gets graded; the menu still
         * lives in its own window and still puts nothing on the emulator's
         * frame. The row below is the difference between a working product
         * and a menu that only looks alive. */
        static int logged = 0;
        if (!logged) {
            logged = 1;
            zl_log(LOG_OK, "window mode: menu is external, the game is still graded");
        }
        InterlockedExchange((volatile LONG*)&g_state.menuOpen, g_state.menuWanted ? 1 : 0);
        InterlockedIncrement(&g_state.swFrames);
        InterlockedExchange((volatile LONG*)&g_state.tAttachMs, (LONG)GetTickCount());

        /* The dedicated menu thread applies menuWanted itself. Do not
         * synchronously manipulate its HWND from the emulator's render thread. */

        /* 0-1. Effects off means NO WORK AT ALL in this lane.
         *
         * zl_gl_begin() is ~20 glGetIntegerv calls and zl_gl_end() puts
         * every one of them back. That is the single largest CPU cost this
         * product adds to the emulator, and with "effects" unchecked there
         * was nothing to protect it for -- the render call returned
         * immediately, but the snapshot and restore ran every frame
         * anyway. Skipping both is a real, measurable frame-time saving,
         * not a cosmetic one. */
        if (g_cfg.masterOn && zl_effects_active()) {
            cost_begin();
            zl_gl_begin();

            /* Marked as OUR pass so the lite-graphics bind hook leaves the
             * composite textures alone -- biasing those would soften the
             * whole screen instead of the game's art. */
            zl_lite_own_pass(1);
            zl_gl_render_frame(w, h);
            zl_lite_own_pass(0);
        } else {
            g_state.skippedFrames++;   /* effects off or all neutral */
        }

        if (!s_selftestLate && g_state.swFrames > 90) {
            s_selftestLate = 1;
            zl_selftest();
        }

        /* 2. deliberately absent: no zl_ui_frame(). The menu draws itself
         *    in its own window; drawing it here is the overlay the user
         *    asked to be rid of, and the mixed-context present that used to
         *    rebuild this context's targets mid-frame. */

        /* 3. hand the context back exactly as found */
        if (g_cfg.masterOn && zl_effects_active()) {
            zl_gl_end();
            cost_end();
        }
        return;
    }

    /* 2. the menu is never graded: it goes on top of the result.
     * Nothing to draw and nothing to grade -> touch no GL state at all. */
    if (s_uiReady || g_cfg.masterOn) {
        cost_begin();
        zl_gl_begin();
        if (s_uiReady) {
            zl_lite_own_pass(1);      /* the font atlas is not game art */
            if (!zl_ui_frame(w, h))
                InterlockedIncrement(&g_state.uiFails);
            zl_lite_own_pass(0);
        }
    } else {
        g_state.skippedFrames++;
    }

    /* 3. hand the context back */
    if (s_uiReady || g_cfg.masterOn) { zl_gl_end(); cost_end(); }
}

/* ------------------------------------------------------------------ */
/*  Startup panel. Called from the present hook AND from the input
 *  watchdog, because a host that presents a few frames and then sits
 *  inside its loading screen would otherwise never reach the swap-side
 *  check. Whoever gets there first wins; the exchange makes it once-only. */
void zl_autoopen_tick(void)
{
    if (s_autoOpened) return;

    if (!g_cfg.autoOpen) {
        if (g_state.swFrames > 30) {
            s_autoOpened = 1;
            zl_log(LOG_INFO, "auto-open off in settings -- panel stays closed");
        }
        return;
    }

    /* one frame is enough to know the host is presenting; do not wait for
     * the UI to have drawn, that is the thing that is slow on a cold start */
    if (g_state.swFrames < 2) return;
    if (g_state.menuWanted) { s_autoOpened = 1; return; }

    if (InterlockedExchange(&s_autoOpened, 1) == 0) {
        InterlockedExchange(&g_state.menuWanted, 1);
        /* no separate window any more: the panel is drawn in this frame */
        zl_log(LOG_OK, "panel opened automatically at startup "
                       "(frames=%ld ui=%ld fails=%ld)",
               (long)g_state.swFrames, (long)g_state.uiFrames,
               (long)g_state.uiFails);
    }
}

/* ------------------------------------------------------------------ */
static BOOL WINAPI hk_wglSwapBuffers(HDC hdc)
{
    static LONG inHook = 0;
    if (inHook || g_state.shuttingDown) return o_wglSwapBuffers(hdc);

    /* The menu window is its own window with its own GL context, but it
     * lives in this process, so its presents land on this same detour. Left
     * alone that is fatal-ish: frame_common() reads a 760x600 viewport,
     * decides the surface changed, and tears down + rebuilds the emulator's
     * six-render-target chain -- every single frame, while the emulator is
     * mid-frame in another thread. Best case it stutters, worst case the
     * emulator samples a texture that was just deleted. Do not grade it. */
    /* ALWAYS, in every build. This guard used to be compiled out under
     * ZLAG_MENU_ONLY on the reasoning that window mode returned early and
     * therefore touched nothing. That stopped being true the moment window
     * mode started running the shader chain: the menu window presents on its
     * own GL context in this same process, its presents land on this same
     * process-wide detour, and without this line the pipeline bound the
     * emulator's render targets to the menu's 760x600 surface -- the menu
     * came back blank white. Now the menu's presents skip the pipeline and
     * the emulator's presents run it, which is what each of them wants. */
    if (zl_menuwin_is_ours((void*)hdc)) return o_wglSwapBuffers(hdc);

    InterlockedExchange(&inHook, 1);

    frame_common(hdc);

    BOOL r = o_wglSwapBuffers(hdc);
    InterlockedExchange(&inHook, 0);
    return r;
}

static BOOL WINAPI hk_eglSwapBuffers(void* dpy, void* surf)
{
    static LONG inHook = 0;
    if (inHook || g_state.shuttingDown) return o_eglSwapBuffers(dpy, surf);
    InterlockedExchange(&inHook, 1);

    s_lastEglDpy = dpy;
    frame_common(NULL);

    BOOL r = o_eglSwapBuffers(dpy, surf);
    InterlockedExchange(&inHook, 0);
    return r;
}

static BOOL WINAPI hk_eglSwapInterval(void* dpy, int iv)
{
    if (g_cfg.vsyncOff) iv = 0;
    g_state.origSwapIv = iv;
    return o_eglSwapInterval ? o_eglSwapInterval(dpy, iv) : 1;
}

static BOOL WINAPI hk_wglSwapIntervalEXT(int iv)
{
    if (g_cfg.vsyncOff) iv = 0;
    g_state.origSwapIv = iv;
    return o_wglSwapIntervalEXT ? o_wglSwapIntervalEXT(iv) : 1;
}

/* ------------------------------------------------------------------ */
static void* resolve_export(const char* dll, const char* name)
{
    HMODULE h = GetModuleHandleA(dll);
    if (!h) h = LoadLibraryA(dll);
    return h ? (void*)GetProcAddress(h, name) : NULL;
}

void zl_hooks_install(void)
{
    MH_STATUS init_status = MH_Initialize();
    if (init_status != MH_OK && init_status != MH_ERROR_ALREADY_INITIALIZED) {
        zl_log(LOG_ERR, "MinHook init failed -- visual hooks disabled");
        return;
    }

    /* lane 1: desktop GL */
    void* sw = resolve_export("opengl32.dll", "wglSwapBuffers");
    if (sw) {
        if (MH_CreateHook(sw, (void*)&hk_wglSwapBuffers, (void**)&o_wglSwapBuffers) == MH_OK &&
            MH_EnableHook(sw) == MH_OK) {
            g_state.hookedWgl = 1;
            zl_log(LOG_OK, "hooked wglSwapBuffers @ %p", sw);
        } else {
            zl_log(LOG_WARN, "wglSwapBuffers hook refused");
        }
    }

    void* si = resolve_export("opengl32.dll", "wglSwapIntervalEXT");
    if (!si) si = resolve_export("libOpenglRender.dll", "wglSwapIntervalEXT");
    if (si && MH_CreateHook(si, (void*)&hk_wglSwapIntervalEXT,
                            (void**)&o_wglSwapIntervalEXT) == MH_OK &&
        MH_EnableHook(si) == MH_OK)
        zl_log(LOG_OK, "hooked wglSwapIntervalEXT @ %p", si);

    /* lane 2: ANGLE / native GLES */
    void* es = resolve_export("libEGL.dll", "eglSwapBuffers");
    if (!es) es = resolve_export("libOpenglRender.dll", "eglSwapBuffers");
    if (es) {
        if (MH_CreateHook(es, (void*)&hk_eglSwapBuffers, (void**)&o_eglSwapBuffers) == MH_OK &&
            MH_EnableHook(es) == MH_OK) {
            g_state.hookedEgl = 1;
            zl_log(LOG_OK, "hooked eglSwapBuffers @ %p", es);
        }
    }
    void* ei = resolve_export("libEGL.dll", "eglSwapInterval");
    if (!ei) ei = resolve_export("libOpenglRender.dll", "eglSwapInterval");
    if (ei && MH_CreateHook(ei, (void*)&hk_eglSwapInterval,
                            (void**)&o_eglSwapInterval) == MH_OK &&
        MH_EnableHook(ei) == MH_OK)
        zl_log(LOG_OK, "hooked eglSwapInterval @ %p", ei);

    if (!g_state.hookedWgl && !g_state.hookedEgl)
        zl_log(LOG_WARN, "no presentation entry point yet -- will retry on first GL call");
    else
        zl_log(LOG_OK, "presentation hooked (wgl=%d egl=%d)",
               (int)g_state.hookedWgl, (int)g_state.hookedEgl);
}

void zl_hooks_remove(void)
{
    MH_DisableHook(MH_ALL_HOOKS);
    MH_Uninitialize();
}
