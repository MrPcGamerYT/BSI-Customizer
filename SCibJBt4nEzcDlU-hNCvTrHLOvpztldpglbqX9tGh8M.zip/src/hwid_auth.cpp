#include "hwid_auth.h"

#include <windows.h>
#include <winhttp.h>
#include <string>

namespace ZLagAuth {

std::string GetHardwareProfileId()
{
    HW_PROFILE_INFOA profile = {};
    if (GetCurrentHwProfileA(&profile))
        return std::string(profile.szHwProfileGuid);
    return "UNKNOWN";
}

bool VerifyHardwareProfile(const std::string& hwid)
{
    // Preserve the verification request from the supplied source archive.
    // This sends the hardware-profile GUID to Firestore over HTTPS.
    const std::wstring wideHwid(hwid.begin(), hwid.end());
    const std::wstring path =
        L"/v1/projects/version-free/databases/(default)/documents/users/" +
        wideHwid +
        L"?key=AIzaSyD3jak2GPPJe6j0M6EWycZd7vH3m0nh1R8";

    HINTERNET session = WinHttpOpen(L"EmulatorMod/1.0",
                                    WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                                    NULL, NULL, 0);
    if (!session) return false;

    HINTERNET connection = WinHttpConnect(session, L"firestore.googleapis.com",
                                          INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!connection) {
        WinHttpCloseHandle(session);
        return false;
    }

    HINTERNET request = WinHttpOpenRequest(connection, L"GET", path.c_str(), NULL,
                                           WINHTTP_NO_REFERER,
                                           WINHTTP_DEFAULT_ACCEPT_TYPES,
                                           WINHTTP_FLAG_SECURE);
    bool authorized = false;
    if (request) {
        if (WinHttpSendRequest(request, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                               WINHTTP_NO_REQUEST_DATA, 0, 0, 0) &&
            WinHttpReceiveResponse(request, NULL)) {
            DWORD statusCode = 0;
            DWORD statusSize = sizeof(statusCode);
            if (WinHttpQueryHeaders(request,
                                    WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                                    NULL, &statusCode, &statusSize, NULL) &&
                statusCode == 200) {
                authorized = true;
            }
        }
        WinHttpCloseHandle(request);
    }

    WinHttpCloseHandle(connection);
    WinHttpCloseHandle(session);
    return authorized;
}

} // namespace ZLagAuth
