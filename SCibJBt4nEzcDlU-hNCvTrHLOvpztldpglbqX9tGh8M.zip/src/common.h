/* =====================================================================
 *  Z-Lag OpenGL overlay and visual-effects library (v1.0)
 *  ------------------------------------------------------------------
 *  Loaded into a host you build/control through an ordinary import-table
 *  dependency. DllMain only schedules the worker; overlay and GL setup run
 *  after the loader lock is released. No proxy exports or remote loader.
 * ===================================================================== */
#ifndef ZLAG_COMMON_H
#define ZLAG_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* ---- version / identity (UI text, banner, log header) ---------------- */
#define ZL_NAME        "Z-Lag Emulator Optimizer"

/* The standalone menu has one fixed toggle key. */
#define ZL_TOGGLE_VK   VK_F2
#define ZL_TAG         "Z-LAG"
#define ZL_VER         "1.0.0"
#define ZL_BUILD       "R1"
#define ZL_BANNER      ZL_NAME " v" ZL_VER " (" ZL_BUILD ")"

/* ---- shared build id: gen_strings.py greps this exact line ----------- */
#define ZL_BUILD_ID    "ZLAG-R1-20261118-nogit"

/* ---- local settings storage ----------------------------------------- */
#define ZL_CFG         __attribute__((section("ZLAGCFG")))

#define ZL_MAX(a,b)    (((a) > (b)) ? (a) : (b))
#define ZL_MIN(a,b)    (((a) < (b)) ? (a) : (b))
#define ZL_CLAMP01(x)  ZL_MIN(1.0f, ZL_MAX(0.0f, (x)))

/* ---- logging -------------------------------------------------------- */
enum { LOG_INFO = 0, LOG_OK = 1, LOG_WARN = 2, LOG_ERR = 3 };
void  zl_log(int level, const char* fmt, ...);
void zl_priv_crash(unsigned int code, unsigned long long rva, unsigned int tid, unsigned int where);
void  zl_log_init(void);
int   zl_lite_is_hooked(void);
void  zl_host_tempclean(void);
void  zl_round_tick(HDC hdc);
void  zl_d3d_install(void);
void  zl_d3d_tick(void);
const char* zl_backend_name(void);
extern volatile LONG zl_d3d_seen;
extern volatile LONG zl_d3d_scaled;
extern int zl_d3d_state;
void  zl_round_reset(void);
extern volatile LONG zl_pending_tempclean;
void  zl_fpsmul_install(void);
void  zl_fpsmul_remove(void);
void  zl_fpsmul_apply(void);
int   zl_fpsmul_state(void);
float zl_lite_bias_now(void);
extern volatile LONG zl_lite_biases;
extern volatile LONG zl_lite_binds;
extern volatile LONG zl_lite_skip;
extern volatile LONG zl_lite_scaled;
extern volatile LONG zl_lite_uploads;
extern int up_hooked;
extern char g_hook_mod_name[64];
float zl_lite_pct_for_bias(float bias);
extern volatile DWORD zl_last_apply_tick;
void  zl_log_hexdump_quiet(void);            /* no-op placeholder */
int   zl_log_ring_count(void);
const char* zl_log_ring_get(int age);

/* ---- settings ------------------------------------------------------- */
typedef struct ZLagSettings {
    int    masterOn;      /* 0 = bit-exact untouched frame            */
    float  sat;           /* saturation      -1 .. +1  (0 = identity)  */
    float  con;           /* contrast        -1 .. +1  (0 = identity)  */
    float  shp;           /* sharpen         -1 .. +1  (0 = identity)  */
    float  blm;           /* bloom           0  .. 1                  */
    float  lift;          /* shadow lift     0  .. 1                  */
    float  vig;           /* vignette        0  .. 1                  */
    float  hdr;           /* HDR pop         -1 .. 1                  */
    float  amb;           /* ambient light   0  .. 1                  */
    float  mblur;         /* motion blur     0  .. 1                  */
    float  warm;          /* warmth          -1  .. 1                 */
    float  fxaa;          /* FXAA/sharpen AA 0  .. 1                  */
    float  flow;          /* optical flow weight 0 .. 1               */
    int    vsyncOff;      /* force swap interval 0                    */
    int    menuWindow;    /* draw the menu as a real Win32 window     */
    int    menuX, menuY;  /* where the user last put it (-1 = unset)  */
    int    menuW, menuH;  /* and the size they left it at            */
    int    adbPort;       /* ADB tab: port to connect to (5555)      */
    float  fpsBoost;      /* 1.0 = real number; 1.5 = shown number   */
    float  sres;          /* upscale detail reconstruction 0 .. 1    */
    float  rcas;          /* FSR-style contrast adaptive sharpen 0..1 */
    int    fpsCap;        /* 0 = uncapped                             */
    int    fpsMulPct;     /* cosmetic display multiplier; 0/100 = off */
    int    roundRadius;   /* emulator window corner radius; 0 = square    */
    int    showOsd;       /* on-screen status                         */
    int    hotkeyCtrl;    /* chord: hold Ctrl + press hotkeyVk         */
    int    hotkeyVk;      /* main key of the chord (default '7')       */
    int    maxFpsBound;
    int    helpSeen;          /* first-run card already dismissed */
    /* internal safety bound */
    int    launcherForced;    /* env ZLAG_LAUNCHER=force -> always draw  */
    int    autoOpen;          /* 1 = show the panel as soon as the host draws */
    int    autoOpenPolicy;    /* which default this file was written under  */
    int    bannerFrames;      /* >0: draw the unfilled "UP" marker       */
    int    liteOn;            /* lite graphics: coarser texture sampling */
    float  litePct;           /* remaining texture detail, 0.4..100      */
    float  liteBias;          /* mip bias, the real control; 0 = legacy  */
    int    liteSuper;         /* bias EVERYTHING, protection ignored     */
    int    liteProtect;       /* keep textures >= this px sharp; 0 = off  */
    int    gpuPref;           /* 1 = ask Windows for the discrete adapter */
} ZLagSettings;

typedef struct ZLagState {
    volatile LONG  menuOpen;
    volatile LONG  ovActive;      /* hook saw the target window           */
    volatile LONG  menuWanted;    /* menu opened by hotkey/tray           */
    volatile LONG  shuttingDown;
    volatile LONG  hookedWgl;
    volatile LONG  hookedEgl;
    volatile LONG  shaderFail;
    volatile LONG  origSwapIv;
    volatile LONG  lastSwaps;
    volatile LONG  fps;           /* measured fps                         */
    volatile LONG  frameMs;       /* rolling avg frame time               */
    DWORD          pid;
    DWORD          threadId;      /* GL worker thread id                   */
    char           exeName[MAX_PATH];
    char           glVendor[128];
    char           glRenderer[128];
    char           glVersion[64];
    DWORD          tAttachMs;
    /* live counters, published by the present hook every frame. These are
     * what the self-test reads back as proof that the overlay is alive. */
    volatile LONG  uiFrames;      /* frames the overlay actually rendered   */
    volatile LONG  uiFails;       /* frames that returned without drawing   */
    volatile LONG  swFrames;      /* frames the host presented              */
    volatile LONG  drawCalls;     /* ImGui draw lists in the last frame     */
    /* lite graphics, published from the render thread */
    volatile LONG  liteBiased;    /* textures the bias actually reached     */
    volatile LONG  liteMips;      /* mip chains we had to build ourselves   */
    volatile LONG  liteSkip;      /* refused / unsafe, left alone           */
    volatile LONG  ovMicros;      /* our cost in the last frame, us         */
    volatile LONG  ovMicrosAvg;   /* smoothed over 16 frames                */
    volatile LONG  skippedFrames; /* frames where we touched no GL at all   */
    volatile LONG  uiW, uiH;      /* viewport the overlay is drawing at     */
    volatile LONG  launcherX, launcherY, launcherW, launcherH;
    volatile LONG  deferredStart;  /* worker must be started by an API call */
    volatile LONG  uiFailLog;      /* rate-limit for the "drew nothing" log */
} ZLagState;

extern ZLagSettings g_cfg;
extern ZLagState    g_state;

void  zl_settings_load(void);        /* reads zlag.ini next to the DLL   */
void  zl_settings_save(void);
void  zl_settings_save_soon(void);   /* debounced: for per-frame drags     */
void  zl_settings_tick(void);        /* flush the debounce                */
int   zl_effects_active(void);       /* any effect parameter non-neutral   */

/* ADB tab / debloat (debloat.cpp) -- called from the optimizer worker */
void  zl_debloat_check(void);
void  zl_debloat_remove(void);
void  zl_debloat_disable(void);
void  zl_debloat_restore(void);
int   zl_adb_find(char* out, DWORD n);  /* debloat.cpp: the one lookup */
void  zl_android_anim(int on);
void  zl_android_killbg(void);
void  zl_android_gameboost(void);
void  zl_android_gms(int suspend);
void  zl_android_deep(void);
void  zl_android_stock(void);
void  zl_ff_detect(void);
void  zl_ff_optimize(void);
void  zl_android_res(int pct);
void  zl_host_threadboost(void);
void  zl_host_awake(int on);
void  zl_host_set_res(int w, int h);
void  zl_host_res_native(void);
void  zl_host_restart_explorer(void);
extern int zl_pick_res_w, zl_pick_res_h;
extern volatile LONG g_keepAwake;
extern char          g_ffPkg[80];
extern volatile LONG g_ffFound;
extern volatile LONG zl_android_cmd;   /* 1 = deep tune, 2 = stock */
void  zl_debloat_connect(int port);      /* adb connect 127.0.0.1:<port>    */
void  zl_debloat_disconnect(void);
extern volatile LONG g_dbRunning, g_dbDone, g_dbTotal, g_dbOk, g_dbFail;
extern volatile LONG g_dbChecked, g_dbPresent;
extern char          g_dbDevice[64];
/* App selection is read-only until the user confirms an explicit batch. */
void  zl_db_scan_apps(void);
void  zl_db_disable_selected(void);
void  zl_db_restore_changes(void);
void  zl_db_remove_requested(void);
void  zl_db_recover_removed(void);
extern volatile LONG g_dbPresetCommand;
void  zl_db_forget_scan(void);
int   zl_db_app_count(void);
const char* zl_db_app_name(int index);
int   zl_db_app_state(int index);
int   zl_db_app_protected(int index);
int   zl_db_app_requested(int index);
int   zl_db_requested_count(void);
int   zl_db_requested_total(void);
int   zl_db_requested_exact_found(void);
const char* zl_db_requested_missing(int index);
int   zl_db_folders_checked(void);
int   zl_db_folder_found(int index);
const char* zl_db_folder_name(int index);
int   zl_db_scan_bound(void);
int   zl_db_app_selected(int index);
int   zl_db_selected_count(void);
int   zl_db_select_app(int index, int on);
void  zl_db_clear_selection(void);
void  zl_dispatch_pending_actions(void);

/* optimizer action bits (shared by UI thread + worker) */
#define ZL_APPLY_POWER       (1 << 0)
#define ZL_APPLY_REGS        (1 << 1)
#define ZL_APPLY_REGS_OFF    (1 << 2)
#define ZL_APPLY_PRIORITY    (1 << 3)
#define ZL_APPLY_TRIM        (1 << 4)
#define ZL_APPLY_VSYNC       (1 << 5)
#define ZL_APPLY_RESETHOOKS  (1 << 6)
#define ZL_APPLY_INITSH      (1 << 7)   /* push + arm the boot hook       */
#define ZL_APPLY_INITSH_RUN  (1 << 8)   /* run it now                     */
#define ZL_APPLY_INITSH_OFF  (1 << 9)   /* remove hook + script + log     */
#define ZL_APPLY_INITSH_CHECK (1 << 10) /* report what is installed       */
#define ZL_APPLY_PROP_APPLY  (1 << 11)  /* setprop every key, this boot   */
#define ZL_APPLY_PROP_PERSIST (1 << 12) /* append to vendor + system prop */
#define ZL_APPLY_PROP_REVERT (1 << 13)  /* strip the appended blocks      */
#define ZL_APPLY_PROP_DIFF   (1 << 14)  /* report what would change       */
#define ZL_APPLY_TIMER       (1 << 15)  /* 1 ms timer resolution          */
#define ZL_APPLY_GPUPREF     (1 << 16)  /* this exe -> high-performance GPU */
#define ZL_APPLY_DB_CHECK    (1 << 17)  /* ADB tab: scan installed apps   */
#define ZL_APPLY_DB_REMOVE   (1 << 18)  /* explicit legacy app recovery   */
#define ZL_APPLY_DB_DISABLE  (1 << 19)  /* ADB tab: disable selected     */
#define ZL_APPLY_DB_RESTORE  (1 << 20)  /* restore saved app states       */
/* The basic bundle is process-local; more invasive host changes remain
 * separate opt-in actions and Android changes are never automatic. */
#define ZL_APPLY_ALL_TUNING  (ZL_APPLY_PRIORITY | ZL_APPLY_TIMER)
#define ZL_APPLY_DB_CONNECT    (1 << 21)  /* ADB tab: adb connect <host:port> */
#define ZL_APPLY_DB_DISCONNECT (1 << 22)  /* ADB tab: adb disconnect          */
#define ZL_APPLY_CLEAN_WAKE   (1 << 23)  /* wake worker for cleanup        */
#define ZL_APPLY_ANIM_OFF      (1 << 24)  /* Android: UI animations off       */
#define ZL_APPLY_ANIM_ON       (1 << 25)  /* Android: animations back         */
#define ZL_APPLY_KILLBG        (1 << 26)  /* Android: am kill-all             */
#define ZL_APPLY_GAMEBOOST     (1 << 27)  /* Android: oom + cpuset for the app */
#define ZL_APPLY_GMS_SUSPEND   (1 << 28)  /* Android: pm suspend gms          */
#define ZL_APPLY_GMS_RESUME    (1 << 29)  /* Android: pm unsuspend gms        */
#define ZL_APPLY_ANDROID_CMD   (1 << 30)  /* deep tune / back to stock        */
#define ZL_APPLY_DB_PRESET     ((int)0x80000000u) /* explicit remove / recovery */

/* No automatic startup hook, guest settings, service stops, property
 * writes, remounts, file cleanup, or cosmetic FPS multiplier. */
#define ZL_APPLY_TURBO       ZL_APPLY_ALL_TUNING
#define ZL_APPLY_ALLINONE    (ZL_APPLY_ALL_TUNING | ZL_APPLY_INITSH_CHECK | ZL_APPLY_PROP_DIFF)

void zl_optimizer_run(int mask);

/* image / preset helpers */
typedef struct ZLagPreset { const char* name; float v[11]; const char* blurb; } ZLagPreset;
void  zl_apply_preset(int idx);
int   zl_preset_count(void);
const ZLagPreset* zl_preset_get(int idx);

/* ---- sub-module entry points ---------------------------------------- */
void  zl_hooks_install(void);


void  zl_hooks_remove(void);
void  zl_input_install_fallback_hook(void);
void  zl_open_menu_toggle(void);
void  zl_optimizer_debloat(int dryRun);
int   zl_optimizer_start(void);      /* background thread: linux/app tweaks */
void  zl_optimizer_apply_app_tweaks(void);   /* called from GL thread     */
/* GL side (must be called on the context thread) */
int   zl_gl_init(void);
int   zl_gl_is_ready(void);
int   zl_gl_render_frame(int fbw, int fbh);   /* grades into backbuffer */
void  zl_gl_begin(void);                       /* snapshot host GL state */
void  zl_gl_end(void);                         /* hand it back untouched */
void  zl_gl_shutdown(void);

/* input hook (installed from the GL thread) */
void  zl_input_install(HWND target);
void  zl_input_install_fallback_hook(void);
void  zl_input_watchdog(void);          /* per-frame: keeps the hotkey alive */
void  zl_autoopen_tick(void);           /* startup panel, callable from any thread */
void  zl_external_menu_boot(void);       /* start external panel independently */
/* gpu.c -- adapter preference and scheduling class, nothing more */
int  zl_gpu_pref_get(void);        /* 0 unset, 1 power-saving, 2 high perf */
int  zl_gpu_pref_set(int high);
int  zl_gpu_nothrottle(int on);    /* 1 = Windows may not throttle us      */

/* lite.c -- texture LOD bias. Nothing here skips a draw call. */
float zl_lite_bias_for_percent(float pct);
void  zl_lite_apply(void);        /* push g_cfg into the bias + hooks    */
void  zl_lite_install_hooks(void);
void  zl_lite_tick(void);         /* per-frame cache re-stamp            */
void  zl_lite_own_pass(int on);   /* 1 = our own GL work, never bias     */

void  zl_hud_reset(void);               /* restart the uptime clock and fps avg  */
void  zl_hotkey_register(void);         /* system hotkey, no window needed    */
void  zl_hotkey_unregister(void);
void  zl_initsh_install(void);          /* push init.sh + arm the boot hook */
void  zl_initsh_run(void);
void  zl_initsh_restore_session(void);
void  zl_initsh_uninstall(void);
void  zl_initsh_status(void);
void  zl_buildprop_apply(void);       /* build.prop extras, runtime       */
void  zl_buildprop_persist(void);     /* build.prop extras, into the files */
void  zl_buildprop_revert(void);
void  zl_buildprop_diff(void);
void  zl_selftest(void);                /* writes zlag-selftest.txt, no GL    */
void  zl_boot_if_deferred(void);        /* safe from any thread, any time     */
void  zl_osd_banner(int frames);        /* flash "up" in the corner           */
void  zl_launcher_rect(int x, int y, int w, int h);  /* UI -> input handshake */
void  zl_panel_rect(int x, int y, int w, int h);     /* open panel's rect      */
void  zl_input_set_dpi(int dpi);                     /* window dpi at install  */

/* which surface a frame is being built for */
#define ZL_LANE_OVERLAY 0   /* the only lane: the emulator surface */     /* the emulator's own surface          */
#define ZL_LANE_WINDOW  1     /* the standalone menu window          */
int   zl_ui_frame(int w, int h);
int   zl_ui_frame_window(int w, int h);
void  zl_ui_lock(void);
void  zl_ui_unlock(void);
struct ImGuiContext;
void  zl_ui_bind_window_context(struct ImGuiContext* ctx);
int   zl_launcher_contains(int x, int y);

/* ---- helpers -------------------------------------------------------- */
void  zl_debug_logf(const char* filename, const char* fmt, ...); /* opt-in  */
const char* zl_cfg_ini_path(char* buf, DWORD n);
void        zl_cfg_set_dir(const char* dir);

#ifdef __cplusplus
}
#endif

#endif /* ZLAG_COMMON_H */
