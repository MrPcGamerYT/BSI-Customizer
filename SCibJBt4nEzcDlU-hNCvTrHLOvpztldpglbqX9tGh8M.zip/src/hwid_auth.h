#pragma once
#include <string>

namespace ZLagAuth {
    // Returns the Windows hardware-profile GUID, matching the legacy source.
    std::string GetHardwareProfileId();

    // Performs the legacy Firestore GET check. A successful HTTP 200 is the
    // allow decision; the Firestore document body is intentionally not parsed.
    bool VerifyHardwareProfile(const std::string& hwid);
}
