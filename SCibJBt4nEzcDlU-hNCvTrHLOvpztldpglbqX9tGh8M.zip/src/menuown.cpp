/*
 * Standard import-loaded DLL entry for a host executable you build/control.
 * The Windows loader calls DllMain when the host imports Z-Lag.dll; the
 * worker does initialization after DllMain returns. No proxy exports,
 * remote injection, or external loader are used.
 */
#include "common.h"
#include "strings.h"
#include "hwid_auth.h"
#include <string>

#ifndef ZL_HOST_EXE
#define ZL_HOST_EXE "HD-Player.exe"
#endif

static volatile LONG s_started = 0;

static int zl_is_expected_host(void)
{
    char path[MAX_PATH] = {0};
    DWORD n = GetModuleFileNameA(NULL, path, MAX_PATH);
    if (!n || n >= MAX_PATH) return 0;
    const char* leaf = strrchr(path, '\\');
    leaf = leaf ? leaf + 1 : path;
    return _stricmp(leaf, ZL_HOST_EXE) == 0;
}

static DWORD WINAPI zl_import_worker(LPVOID)
{
    if (!zl_is_expected_host()) return 0;

    zl_log_init();
    zl_log(LOG_OK, "%s -- loaded by the host's normal import table", ZL_BANNER);

    // Network/HWID work is intentionally outside DllMain and runs on this
    // worker. Preserve the supplied Firestore rule: HTTP 200 authorizes.
    const std::string hwid = ZLagAuth::GetHardwareProfileId();
    if (!ZLagAuth::VerifyHardwareProfile(hwid)) {
        zl_log(LOG_WARN, "HWID authorization failed or Firestore was unreachable");
        const std::string message =
            "This device is not authorized, or the license server could not be reached.\n\nHWID: " + hwid;
        MessageBoxA(NULL, message.c_str(), "Z-Lag authorization", MB_OK | MB_ICONWARNING);
        return 0;
    }
    zl_log(LOG_OK, "HWID authorization accepted");

    zl_settings_load();
    zl_lite_apply();

    char exe[MAX_PATH] = {0};
    GetModuleFileNameA(NULL, exe, MAX_PATH);
    const char* leaf = strrchr(exe, '\\');
    lstrcpynA(g_state.exeName, leaf ? leaf + 1 : exe, sizeof(g_state.exeName));
    g_state.pid = GetCurrentProcessId();
    g_state.tAttachMs = GetTickCount();
    zl_log(LOG_INFO, "host: %s (pid %lu, %s-bit)", g_state.exeName,
           (unsigned long)g_state.pid, sizeof(void*) == 8 ? "64" : "32");

#ifdef ZL_DEFAULT_MENUWINDOW
    zl_external_menu_boot();
#endif
    zl_hooks_install();
    zl_log(LOG_INFO, "%s", ZL_MSG_COPYRIGHT);
    return 0;
}

/* A no-op import anchor for the host's link step. It is not an initializer:
 * startup is automatic in DllMain when the host loads this dependency. */
extern "C" __declspec(dllexport) void WINAPI ZLagImportAnchor(void)
{
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(instance);
        if (InterlockedCompareExchange(&s_started, 1, 0) == 0) {
            HANDLE thread = CreateThread(NULL, 0, zl_import_worker, NULL, 0, NULL);
            if (thread) CloseHandle(thread);
            else InterlockedExchange(&s_started, 0);
        }
    } else if (reason == DLL_PROCESS_DETACH) {
        InterlockedExchange(&g_state.shuttingDown, 1);
    }
    return TRUE;
}
