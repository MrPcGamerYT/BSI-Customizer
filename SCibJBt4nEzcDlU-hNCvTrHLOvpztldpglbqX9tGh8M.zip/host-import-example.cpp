// Example only: compile this into a host executable you control.
// ZLagImportAnchor is a no-op import anchor. DllMain starts the module worker
// automatically when Windows loads the imported DLL.
#include <windows.h>

extern "C" __declspec(dllimport) void WINAPI ZLagImportAnchor(void);

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int)
{
    ZLagImportAnchor(); // forces a normal import-table dependency; not init
    MessageBoxW(nullptr, L"Host started with Z-Lag.dll imported.",
                L"Import test", MB_OK | MB_ICONINFORMATION);
    return 0;
}
