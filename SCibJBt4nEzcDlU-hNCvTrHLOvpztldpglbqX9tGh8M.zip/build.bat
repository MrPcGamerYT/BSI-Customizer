@echo off
setlocal
cd /d "%~dp0"
where mingw32-make >nul 2>nul || (
  echo mingw32-make not found. Run from an MSYS2 MINGW64 shell.
  exit /b 1
)
where g++ >nul 2>nul || (
  echo MinGW-w64 g++ not found.
  exit /b 1
)
where python >nul 2>nul || (
  echo Python 3 not found; src\gen_strings.py needs it.
  exit /b 1
)
mingw32-make
if errorlevel 1 exit /b 1
echo Built dist\Z-Lag.dll and dist\libZLag.dll.a
