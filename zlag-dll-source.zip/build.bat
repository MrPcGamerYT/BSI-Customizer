@echo off
REM =====================================================================
REM  Z-Lag Emulator Optimizer -- version.dll proxy
REM  build from a Windows machine with MSYS2 / mingw-w64 installed
REM
REM   1. install MSYS2            https://www.msys2.org
REM   2. open  "MSYS2 MINGW64"    (not the plain MSYS shell)
REM   3. pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-make python
REM   4. run this file
REM =====================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"

where gcc >nul 2>nul
if errorlevel 1 (
    echo [!] gcc not found. Run this from the MSYS2 "MINGW64" shell, or add
    echo     C:\msys64\mingw64\bin to PATH first.
    exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
    echo [!] python not found - needed by src\gen_strings.py
    exit /b 1
)

if not exist build mkdir build
if not exist dist  mkdir dist

echo [1/2] stamping build id
python src\gen_strings.py || exit /b 1

echo [2/2] compiling
mingw32-make -j%NUMBER_OF_PROCESSORS% 2>nul || mingw32-make
if errorlevel 1 exit /b 1

echo.
echo   built: dist\version.dll
echo   copy it next to HD-Player.exe and start BlueStacks, then press F7
echo.
