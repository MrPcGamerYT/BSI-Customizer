# Z-Lag Emulator Optimizer — `version.dll`

![Z-Lag overlay](docs/all-tabs.png)

*Every tab captured live — see [`docs/menu-preview.html`](docs/menu-preview.html) for the full-resolution gallery.*

An in-process overlay + frame post-processor for **BlueStacks 5** (`HD-Player.exe`),
shipped as a **`version.dll` proxy**. Drop it next to `HD-Player.exe`, start the
emulator, press **Ctrl+7**.

```
HD-Player.exe
├── version.dll      ← this build (proxy + overlay)
├── <everything else the emulator ships>
```

---

## 1. What it does

`version.dll` is loaded by the emulator before it creates its window. We sit in
that slot, forward **all 17 original exports** to the real
`C:\Windows\System32\version.dll`, and additionally:

| hook | why |
|---|---|
| `wglSwapBuffers` | desktop-GL lane — frame is graded right before it is presented |
| `eglSwapBuffers` | ANGLE / native-GLES lane (older BlueStacks builds) |
| `wglSwapIntervalEXT` / `eglSwapInterval` | vsync override (uncap FPS) |

Everything is done on the emulator's own render thread. There is **no DLL
injection, no remote thread, no process attaching, no service changes**.

### The overlay (Ctrl+7)

A full ImGui panel drawn inside the emulator's own GL context:

* **Performance** — live FPS / frame time, GL vendor+renderer, hooks status,
  vsync-off switch, frame limiter, re-scan hooks.
* **Visuals** — saturation, contrast, sharpen, warmth, HDR pop, shadow lift,
  ambient light, vignette, bloom, motion blur, flow gain, FXAA. Right-click any
  slider to zero it. Everything at 0 = **bit-exact untouched frame**.
* **Presets** — Neutral, BP9 Competitive, Cinematic, HDR Pop, Moonlight,
  Anime/Cel, Max FPS.
* **Optimize** — power plan, HKCU gaming flags (reversible), process priority,
  working-set trim. Each action is logged and reversible.
* **Log** — the same event ring that goes to `zlag.log`.
* **About** — build id, source layout, hotkeys, safety notes.

Everything is reachable by mouse as well as keyboard; the first launch shows a
one-time modal, and every state change answers with a 1.7 s toast above the panel.

`Esc` closes the panel. Settings persist in `zlag.ini` next to the DLL.

---

## 2. Install

Full walkthrough with troubleshooting: **[`docs/INSTALL.txt`](docs/INSTALL.txt)**

1. Close BlueStacks completely (including the tray agent). **This matters —
   a running emulator holds `version.dll` locked and your copy silently won't load.**
2. Pick the architecture — this is the step people get wrong:

   | emulator | use |
   |---|---|
   | BlueStacks 5 | `dist/version.dll` (x64) |
   | BlueStacks 4 / old 32-bit install | `dist32/version.dll` (x86) |

   A wrong-architecture DLL simply fails to load — BlueStacks runs normally and
   you get no overlay. It cannot break the emulator. Safe to swap and retry.
3. Copy it next to `HD-Player.exe` — usually
   `C:\Program Files\BlueStacks_nxt\` (or `...\BlueStacks\`).
4. Start BlueStacks normally. Press **Ctrl+7** in-game.

Nothing else is required. No admin rights, no installer, no driver.

### Uninstall

Delete `version.dll` (and optionally `zlag.ini` / `zlag.log`) from that folder.
If you used an Optimize action, hit the same button again to revert, or use
"Save + close" on defaults to write neutral settings.

---

## 3. Rebuild

Sources are complete and self-contained (ImGui + MinHook are vendored, both
permissively licensed — see `src/imgui/LICENSE.txt`, `src/minhook/LICENSE.txt`).

**Windows (MSYS2 / mingw-w64):**
```
pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-make python
build.bat
```

**Linux (cross-compile, both architectures):**
```
sudo apt install gcc-mingw-w64-x86-64 g++-mingw-w64-x86-64 \
                 gcc-mingw-w64-i686  g++-mingw-w64-i686
make                                                  # -> dist/version.dll   (x64)
make CROSS=i686-w64-mingw32- BUILD=build32 OUT=dist32 # -> dist32/version.dll (x86)
```

Both are plain PE DLLs whose only imports are the normal
user32/gdi32/kernel32/opengl32 set.

---

## 4. How the picture is graded

Ported from the recovered ENIGMA R69 shader set (see `uploads/01..07`), with
three fixes so they compile and behave on every BlueStacks GL stack:

```
capture back buffer
  ├─ fxaa.frag        3.11-style directional AA + edge sharpen  (fxaa > 0)
  ├─ brightpass.frag  → gauss h/v at half res                   (bloom > 0)
  ├─ opticalflow.frag 20-candidate 3×3 SAD, half res            (mblur > 0)
  └─ enhancer.frag    sat/con/sharp/bloom/hdr/amb/vig/mblur → back buffer
```
* `opticalflow.frag` was rewritten without dynamic array indexing — GLSL 1.10
  drivers (ANGLE, NVR) refuse `cb[k]` in a loop.
* unused samplers removed (`flowT`, `prev2F`, `flowF` were bound confusion).
* every stage early-outs to a **bit-exact pass-through** at zero weight;
  verified numerically (see §6).

---

## 5. Files

```
src/version.c        proxy exports + DllMain + worker
src/hooks.c          swap-chain hooks, frame orchestration, fps cap
src/gl_pipeline.c    FBO ping-pong, 6 shader programs, GL state save/restore
src/zlag_shaders.h   all six GLSL sources
src/overlay_ui.cpp   ImGui panel (Performance/Visuals/Presets/Optimize/Log/About)
src/input.c          window subclass, Ctrl+7, ImGui input feed
src/optimizer.cpp    power plan, HKCU flags, priority, working-set trim
src/settings.c       zlag.ini + zlag.log + in-memory log ring
src/presets.cpp      preset table
res/version.def      17 forwarded exports + build-id exports
res/version.rc       version resource + DPI manifest
```

---

## 6. What was tested

Run under Wine + Mesa llvmpipe with a GL host that imports `version.dll`
(exactly how BlueStacks loads it), 1280×800:

| check | result |
|---|---|
| all 17 `version.dll` exports present | ✅ matching ordinals |
| proxy forwards to system `version.dll` | ✅ |
| whole chain boots from `DllMain` worker | ✅ |
| `wglSwapBuffers` + `wglSwapIntervalEXT` hooked | ✅ |
| all six shader programs compile | ✅ 6/6 |
| Ctrl+7 opens the panel, Esc closes it | ✅ |
| flat-frame colour check `(204,102,51)` sat 0.6 con 0.3 | ✅ `255,73,0` = shader math |
| lift 0.8 / warm 0.5 / amb 0.8 / sat −0.8 | ✅ all within 1 LSB |
| effects off → untouched frame | ✅ `204,102,51` |
| **all 7 shaders compile in a real ES2 context** | ✅ 7/7 (Mesa GLES) |
| **composite links in ES2, 17/17 uniforms resolve** | ✅ |
| x86 build links + exports the same 17 entry points | ✅ |

**Not testable here:** real `HD-Player.exe` behaviour on your machine. GL
stacks, window classes and BlueStacks versions differ; if the panel shows but
the picture is unchanged, open **Performance** and check `hooks wgl=on`, then
look at `zlag.log` next to the DLL.

---

## 7. Honest limits

* BlueStacks' own **"Safe mode / GL compatibility"** settings can move rendering
  to a lane that never calls a swap function we can hook — then the overlay
  simply stays dormant and the emulator is untouched.
* Anti-cheat: none of this touches any game process, but some titles with
  kernel anti-cheat dislike *any* in-process overlay. Use at your own risk;
  turn effects off with Ctrl+7 → master switch if a game misbehaves.
* The `Optimize` tab edits HKCU and the power scheme. Both are reversible;
  nothing is changed silently at startup.

---

## 8. License

The proxy, the overlay and the optimization module are original work, GPLv3.
Vendored: ImGui 1.90.9 (MIT), MinHook (BSD-2), both unmodified except the
OpenGL2 backend, which is routed through a runtime loader instead of linking
`opengl32` (so it works in ANGLE contexts too).
