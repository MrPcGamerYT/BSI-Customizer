#!/system/bin/sh
# Optional per-user app actions. Selected apps may be disabled; a separate,
# confirmed preset uninstalls only the requested packages while asking Android
# to keep data. No system image files are deleted. Saved data is never run.
BASE=/data/local/tmp/zlag_debloat_v1
umask 077

valid_name() {
    case "$1" in
        ''|.*|*..*|*[!A-Za-z0-9_.]*) return 1 ;;
        *.*) [ "${#1}" -le 120 ] ;;
        *) return 1 ;;
    esac
}

protected_name() {
    case "$1" in
        android|com.android.systemui|com.android.settings|com.android.shell|\
        com.android.vending|com.google.android.gms|com.google.android.gsf|\
        com.bluestacks.home|com.bluestacks.settings|\
        com.android.launcher|com.android.launcher2|com.android.launcher3|\
        com.google.android.packageinstaller|com.android.packageinstaller|\
        com.android.providers.*|com.android.inputmethod.*|\
        com.google.android.inputmethod.*)
            return 0 ;;
    esac
    return 1
}

# Exact allowlist generated from the requested package list. Any additional
# match must have a package-manager path in one of the specified folders.
requested_name() {
    case "$1" in
        # BEGIN GENERATED REQUESTED PACKAGES
        com.bluestacks.bsxlauncher) return 0 ;;
        com.bluestacks.gamecenter) return 0 ;;
        com.bluestacks.home) return 0 ;;
        com.bluestacks.nowgg) return 0 ;;
        com.bluestacks.piggy) return 0 ;;
        com.bluestacks.quest) return 0 ;;
        com.android.play.games) return 0 ;;
        com.google.android.syncadapters.calendar) return 0 ;;
        com.google.android.syncadapters.contacts) return 0 ;;
        com.location.provider) return 0 ;;
        gg.now.accounts) return 0 ;;
        com.android.calendar) return 0 ;;
        com.android.contacts) return 0 ;;
        com.android.dialer) return 0 ;;
        com.android.camera2) return 0 ;;
        com.android.deskclock) return 0 ;;
        com.android.gallery3d) return 0 ;;
        com.android.bookmarkprovider) return 0 ;;
        com.android.htmlviewer) return 0 ;;
        com.android.wallpaper.livepicker) return 0 ;;
        com.android.wallpapercropper) return 0 ;;
        com.android.wallpaperpicker) return 0 ;;
        com.android.printspooler) return 0 ;;
        com.android.printservice.recommendation) return 0 ;;
        com.android.bips) return 0 ;;
        com.android.providers.calendar) return 0 ;;
        com.android.providers.blockednumber) return 0 ;;
        com.android.providers.userdictionary) return 0 ;;
        com.android.statementservice) return 0 ;;
        com.android.simappdialog) return 0 ;;
        com.android.carrierconfig) return 0 ;;
        com.android.carrierdefaultapp) return 0 ;;
        com.android.cts.priv.ctsshim) return 0 ;;
        com.android.cts.ctsshim) return 0 ;;
        com.android.internal.display.cutout.emulation.corner) return 0 ;;
        com.android.internal.display.cutout.emulation.double) return 0 ;;
        com.android.internal.display.cutout.emulation.tall) return 0 ;;
        com.android.companiondevicemanager) return 0 ;;
        com.android.traceur) return 0 ;;
        com.android.settings.intelligence) return 0 ;;
        com.android.storagemanager) return 0 ;;
        com.android.sharedstoragebackup) return 0 ;;
        com.android.backupconfirm) return 0 ;;
        com.android.vpndialogs) return 0 ;;
        com.android.provision) return 0 ;;
        com.android.onetimeinitializer) return 0 ;;
        com.android.calculator2) return 0 ;;
        com.android.email) return 0 ;;
        gg.now.billing.service) return 0 ;;
        gg.now.billing.service2) return 0 ;;
        com.google.android.onetimeinitializer) return 0 ;;
        com.google.android.partnersetup) return 0 ;;
        com.google.android.backuptransport) return 0 ;;
        com.google.android.play.games) return 0 ;;
    # END GENERATED REQUESTED PACKAGES
    esac
    paths=$(pm path --user 0 "$1" 2>/dev/null) || return 1
    while IFS= read -r entry; do
        case "$entry" in
            package:/system/app/BookmarkProvider.apk|package:/system/app/BookmarkProvider/*|\
            package:/system/app/Camera2.apk|package:/system/app/Camera2/*|\
            package:/system/app/Gallery2.apk|package:/system/app/Gallery2/*|\
            package:/system/priv-app/CalendarProvider.apk|package:/system/priv-app/CalendarProvider/*|\
            package:/system/priv-app/DocumentsUI.apk|package:/system/priv-app/DocumentsUI/*|\
            package:/system/priv-app/Contacts.apk|package:/system/priv-app/Contacts/*|\
            package:/system/priv-app/ContactsProvider.apk|package:/system/priv-app/ContactsProvider/*|\
            package:/system/priv-app/FusedLocation.apk|package:/system/priv-app/FusedLocation/*)
                return 0 ;;
        esac
    done <<EOF
$paths
EOF
    return 1
}

package_presence() {
    found=$(pm list packages --user 0 "$1" 2>&1)
    result=$?
    if [ "$result" != 0 ]; then echo unknown; return; fi
    # An empty successful response means absent; unexpected non-package lines
    # are not trustworthy evidence of absence.
    if ! printf '%s\n' "$found" | awk 'NF && $0 !~ /^package:[A-Za-z0-9_.]+$/ { exit 1 }'; then
        echo unknown; return
    fi
    if printf '%s\n' "$found" | grep -Fx "package:$1" >/dev/null; then echo present; else echo absent; fi
}

open_base() {
    if [ -L "$BASE" ] || { [ -e "$BASE" ] && [ ! -d "$BASE" ]; }; then
        echo 'ZL-BACKUP-UNSAFE'
        return 1
    fi
    if [ ! -d "$BASE" ]; then
        if [ "$1" = list ] || [ "$1" = restore ] ||
           [ "$1" = list-removed ] || [ "$1" = reinstall ]; then
            echo 'ZL-NO-BACKUP'
            return 2
        fi
        mkdir "$BASE" 2>/dev/null || { echo 'ZL-BACKUP-FAILED'; return 1; }
    fi
    [ -d "$BASE" ] && [ ! -L "$BASE" ] || { echo 'ZL-BACKUP-UNSAFE'; return 1; }
    return 0
}

lock_base() {
    lock="$BASE/.lock"
    if ! mkdir "$lock" 2>/dev/null; then
        # A killed helper can leave a lock behind. Clear it only when its
        # numeric owner is demonstrably gone; never follow a lock symlink.
        if [ -L "$lock" ] || [ ! -d "$lock" ] || [ -L "$lock/pid" ] || [ ! -f "$lock/pid" ]; then
            echo 'ZL-BUSY'; return 1
        fi
        owner=$(cat "$lock/pid" 2>/dev/null)
        case "$owner" in ''|*[!0-9]*|0|1) echo 'ZL-BUSY'; return 1 ;; esac
        if kill -0 "$owner" 2>/dev/null; then echo 'ZL-BUSY'; return 1; fi
        rm -f "$lock/pid" 2>/dev/null && rmdir "$lock" 2>/dev/null && mkdir "$lock" 2>/dev/null || {
            echo 'ZL-BUSY'; return 1;
        }
    fi
    if ! printf '%s\n' "$$" > "$lock/pid" 2>/dev/null; then
        rmdir "$lock" 2>/dev/null || :
        echo 'ZL-BUSY'; return 1
    fi
    trap 'rm -f "$BASE/.lock/pid" 2>/dev/null; rmdir "$BASE/.lock" 2>/dev/null || :' EXIT
    trap 'exit 1' HUP INT TERM
    return 0
}

# Restrict the state line to the named Package block for Android user 0.
# If a guest's dumpsys output has another format, the operation fails closed.
app_state() {
    line=$(dumpsys package "$1" 2>/dev/null | awk -v pkg="$1" '
        /^[[:space:]]*Package \[/ { in_package = index($0, "Package [" pkg "]") != 0 }
        in_package && /^[[:space:]]*User 0:/ { print; exit }
    ')
    case " $line " in *' installed=true '*) : ;; *) echo unknown; return ;; esac
    case " $line " in
        *' enabled=0 '*) echo 0 ;;
        *' enabled=1 '*) echo 1 ;;
        *' enabled=2 '*) echo 2 ;;
        *' enabled=3 '*) echo 3 ;;
        *' enabled=4 '*) echo 4 ;;
        *) echo unknown ;;
    esac
}

list_backups() {
    for file in "$BASE"/*.state; do
        [ -e "$file" ] || [ -L "$file" ] || continue
        name=${file##*/}
        pkg=${name%.state}
        if valid_name "$pkg" && [ -f "$file" ] && [ ! -L "$file" ]; then
            printf 'ZL-SAVED %s\n' "$pkg"
        else
            echo 'ZL-INVALID-BACKUP'
        fi
    done
    echo 'ZL-LIST-DONE'
}

disable_one() {
    pkg=$1
    if ! valid_name "$pkg" || protected_name "$pkg"; then
        printf 'ZL-SKIP-DISABLE %s\n' "$pkg"
        return
    fi
    file="$BASE/$pkg.state"
    temp="$file.new"
    if [ -e "$file" ] || [ -L "$file" ] || [ -e "$temp" ] || [ -L "$temp" ]; then
        printf 'ZL-SKIP-DISABLE %s\n' "$pkg"
        return
    fi
    old=$(app_state "$pkg")
    case "$old" in 0|1) : ;; *) printf 'ZL-SKIP-DISABLE %s\n' "$pkg"; return ;; esac
    if ! pm list packages --user 0 -e "$pkg" 2>/dev/null | grep -Fx "package:$pkg" >/dev/null; then
        printf 'ZL-SKIP-DISABLE %s\n' "$pkg"
        return
    fi
    # Snapshot before changing anything. The lock and noclobber prevent
    # overwriting a saved state; never follow an existing backup symlink.
    if ! (set -C; printf '%s\n' "$old" > "$temp") 2>/dev/null ||
       ! mv "$temp" "$file" 2>/dev/null ||
       [ -L "$file" ] || [ ! -f "$file" ] || [ "$(cat "$file" 2>/dev/null)" != "$old" ]; then
        printf 'ZL-FAIL-DISABLE %s\n' "$pkg"
        return
    fi
    if [ "$(app_state "$pkg")" != "$old" ]; then
        # State changed concurrently; retain the snapshot for inspection.
        printf 'ZL-UNCERTAIN-DISABLE %s\n' "$pkg"
        return
    fi
    pm disable-user --user 0 "$pkg" >/dev/null 2>&1
    now=$(app_state "$pkg")
    if [ "$now" = 3 ]; then
        printf 'ZL-OK-DISABLED %s\n' "$pkg"
    elif [ "$now" = "$old" ]; then
        if rm -f "$file" 2>/dev/null; then
            printf 'ZL-FAIL-DISABLE %s\n' "$pkg"
        else
            printf 'ZL-UNCERTAIN-DISABLE %s\n' "$pkg"
        fi
    else
        printf 'ZL-UNCERTAIN-DISABLE %s\n' "$pkg"
    fi
}

restore_one() {
    pkg=$1
    if ! valid_name "$pkg"; then
        printf 'ZL-FAIL-RESTORE %s\n' "$pkg"
        return
    fi
    file="$BASE/$pkg.state"
    if [ -L "$file" ] || [ ! -f "$file" ]; then
        printf 'ZL-FAIL-RESTORE %s\n' "$pkg"
        return
    fi
    old=$(cat "$file" 2>/dev/null)
    case "$old" in 0|1) : ;; *) printf 'ZL-FAIL-RESTORE %s\n' "$pkg"; return ;; esac
    now=$(app_state "$pkg")
    if [ "$now" = 3 ]; then
        if [ "$old" = 0 ]; then
            pm default-state --user 0 "$pkg" >/dev/null 2>&1
        else
            pm enable --user 0 "$pkg" >/dev/null 2>&1
        fi
        now=$(app_state "$pkg")
    fi
    # Do not override a later, unrelated state such as disabled by policy.
    if [ "$now" = "$old" ]; then
        if rm -f "$file" 2>/dev/null; then
            printf 'ZL-OK-RESTORED %s\n' "$pkg"
        else
            printf 'ZL-UNCERTAIN-RESTORE %s\n' "$pkg"
        fi
    else
        printf 'ZL-FAIL-RESTORE %s\n' "$pkg"
    fi
}

list_removed() {
    for file in "$BASE"/*.removed; do
        [ -e "$file" ] || [ -L "$file" ] || continue
        name=${file##*/}
        pkg=${name%.removed}
        if valid_name "$pkg" && [ -f "$file" ] && [ ! -L "$file" ]; then
            printf 'ZL-REMOVED %s\n' "$pkg"
        else
            echo 'ZL-INVALID-BACKUP'
        fi
    done
    echo 'ZL-REMOVE-LIST-DONE'
}

uninstall_one() {
    pkg=$1
    if ! valid_name "$pkg" || ! requested_name "$pkg"; then
        printf 'ZL-SKIP-REMOVE %s\n' "$pkg"
        return
    fi
    file="$BASE/$pkg.removed"
    temp="$file.new"
    if [ -e "$file" ] || [ -L "$file" ] || [ -e "$temp" ] || [ -L "$temp" ]; then
        printf 'ZL-SKIP-REMOVE %s\n' "$pkg"
        return
    fi
    before=$(package_presence "$pkg")
    old=$(app_state "$pkg")
    case "$old" in 0|1|2|3|4) : ;; *) printf 'ZL-SKIP-REMOVE %s\n' "$pkg"; return ;; esac
    if [ "$before" != present ]; then
        printf 'ZL-SKIP-REMOVE %s\n' "$pkg"
        return
    fi
    if ! (set -C; printf '%s\n' "$old" > "$temp") 2>/dev/null ||
       ! mv "$temp" "$file" 2>/dev/null || [ -L "$file" ] || [ ! -f "$file" ] ||
       [ "$(cat "$file" 2>/dev/null)" != "$old" ]; then
        printf 'ZL-FAIL-REMOVE %s\n' "$pkg"
        return
    fi
    if [ "$(package_presence "$pkg")" != present ] || [ "$(app_state "$pkg")" != "$old" ]; then
        printf 'ZL-UNCERTAIN-REMOVE %s\n' "$pkg"
        return
    fi
    pm uninstall -k --user 0 "$pkg" >/dev/null 2>&1
    result=$?
    after=$(package_presence "$pkg")
    if [ "$result" = 0 ] && [ "$after" = absent ]; then
        printf 'ZL-OK-REMOVED %s\n' "$pkg"
    elif [ "$after" = present ] && [ "$(app_state "$pkg")" = "$old" ]; then
        if rm -f "$file" 2>/dev/null; then
            printf 'ZL-FAIL-REMOVE %s\n' "$pkg"
        else
            printf 'ZL-UNCERTAIN-REMOVE %s\n' "$pkg"
        fi
    else
        printf 'ZL-UNCERTAIN-REMOVE %s\n' "$pkg"
    fi
}

reinstall_one() {
    pkg=$1
    if ! valid_name "$pkg"; then printf 'ZL-FAIL-REINSTALL %s\n' "$pkg"; return; fi
    file="$BASE/$pkg.removed"
    if [ -L "$file" ] || [ ! -f "$file" ]; then printf 'ZL-FAIL-REINSTALL %s\n' "$pkg"; return; fi
    old=$(cat "$file" 2>/dev/null)
    case "$old" in 0|1|2|3|4) : ;; *) printf 'ZL-FAIL-REINSTALL %s\n' "$pkg"; return ;; esac
    presence=$(package_presence "$pkg")
    if [ "$presence" = absent ]; then
        # install-existing cannot restore an APK that no longer exists.
        cmd package install-existing --user 0 "$pkg" >/dev/null 2>&1 ||
            pm install-existing --user 0 "$pkg" >/dev/null 2>&1 || :
        [ "$(package_presence "$pkg")" = present ] || { printf 'ZL-FAIL-REINSTALL %s\n' "$pkg"; return; }
        case "$old" in
            0) pm default-state --user 0 "$pkg" >/dev/null 2>&1 ;;
            1) pm enable --user 0 "$pkg" >/dev/null 2>&1 ;;
            2) pm disable --user 0 "$pkg" >/dev/null 2>&1 ;;
            3) pm disable-user --user 0 "$pkg" >/dev/null 2>&1 ;;
            4) pm disable-until-used --user 0 "$pkg" >/dev/null 2>&1 ;;
        esac
    elif [ "$presence" != present ]; then
        printf 'ZL-FAIL-REINSTALL %s\n' "$pkg"
        return
    fi
    # For an independently reinstalled app, never overwrite a later state.
    if [ "$(app_state "$pkg")" = "$old" ]; then
        if rm -f "$file" 2>/dev/null; then printf 'ZL-OK-REINSTALLED %s\n' "$pkg"
        else printf 'ZL-UNCERTAIN-REINSTALL %s\n' "$pkg"; fi
    else
        printf 'ZL-FAIL-REINSTALL %s\n' "$pkg"
    fi
}

mode=${1:-}
[ "$#" -gt 0 ] && shift
case "$mode" in
    list|disable|restore|list-removed|uninstall|reinstall) : ;;
    *) echo 'ZL-UNKNOWN-ACTION'; exit 1 ;;
esac
open_base "$mode"
status=$?
[ "$status" = 2 ] && exit 0
[ "$status" = 0 ] || exit 1
if [ "$mode" = list ]; then list_backups; exit 0; fi
if [ "$mode" = list-removed ]; then list_removed; exit 0; fi
lock_base || exit 1
[ "$#" -gt 0 ] || { echo 'ZL-NO-PACKAGES'; exit 1; }
for pkg in "$@"; do
    case "$mode" in
        disable) disable_one "$pkg" ;;
        restore) restore_one "$pkg" ;;
        uninstall) uninstall_one "$pkg" ;;
        reinstall) reinstall_one "$pkg" ;;
    esac
done
exit 0
