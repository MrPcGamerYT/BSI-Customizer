#!/system/bin/sh
# Optional, reversible cosmetic animation tuning. No vendor script is
# sourced and no device, service, kernel, renderer, network, identity or
# system/vendor property is changed.

BACKUP=/data/local/tmp/zlag_safe_animation_v1
LOG=/data/local/tmp/zlag_safe_animation.log
KEYS='window_animation_scale transition_animation_scale animator_duration_scale'

say() {
    printf '%s\n' "$*"
    printf '%s\n' "$*" >> "$LOG" 2>/dev/null || :
}

valid_value() {
    case "$1" in
        null) return 0 ;;
        ''|*[!0-9.]*|.*|*.|*.*.*) return 1 ;;
        *) return 0 ;;
    esac
}

snapshot_valid() {
    count=0
    seen_window=0
    seen_transition=0
    seen_animator=0
    while IFS='=' read -r key value; do
        case "$key" in
            window_animation_scale) seen_window=$((seen_window + 1)) ;;
            transition_animation_scale) seen_transition=$((seen_transition + 1)) ;;
            animator_duration_scale) seen_animator=$((seen_animator + 1)) ;;
            *) return 1 ;;
        esac
        valid_value "$value" || return 1
        count=$((count + 1))
    done < "$BACKUP"
    [ "$count" -eq 3 ] && [ "$seen_window" -eq 1 ] && \
        [ "$seen_transition" -eq 1 ] && [ "$seen_animator" -eq 1 ]
}

save_originals() {
    if [ -f "$BACKUP" ]; then snapshot_valid; return $?; fi
    tmp="${BACKUP}.$$.tmp"
    umask 077
    : > "$tmp" || return 1
    for key in $KEYS; do
        value=$(settings get global "$key" 2>/dev/null) || { rm -f "$tmp"; return 1; }
        valid_value "$value" || { rm -f "$tmp"; return 1; }
        printf '%s=%s\n' "$key" "$value" >> "$tmp" || { rm -f "$tmp"; return 1; }
    done
    mv -f "$tmp" "$BACKUP" || { rm -f "$tmp"; return 1; }
    return 0
}

restore_originals() {
    if [ ! -f "$BACKUP" ]; then
        say 'ZL-NO-SNAPSHOT'
        return 2
    fi
    # Validate the entire snapshot before making any change. Never source it.
    snapshot_valid || { say 'ZL-INVALID-SNAPSHOT'; return 1; }
    failed=0
    while IFS='=' read -r key value; do
        if [ "$value" = null ]; then
            settings delete global "$key" >/dev/null 2>&1 || failed=1
        else
            settings put global "$key" "$value" >/dev/null 2>&1 || failed=1
        fi
        actual=$(settings get global "$key" 2>/dev/null) || failed=1
        [ "$actual" = "$value" ] || failed=1
    done < "$BACKUP"
    if [ "$failed" -ne 0 ]; then
        say 'ZL-RESTORE-FAILED'
        return 1
    fi
    rm -f "$BACKUP" || { say 'ZL-RESTORE-FAILED'; return 1; }
    say 'ZL-RESTORED'
    return 0
}

apply_safe() {
    save_originals || { say 'ZL-SNAPSHOT-FAILED'; return 1; }
    for key in $KEYS; do
        if ! settings put global "$key" 0.5 >/dev/null 2>&1; then
            say 'ZL-APPLY-FAILED'
            restore_originals || :
            return 1
        fi
        actual=$(settings get global "$key" 2>/dev/null) || actual=''
        if [ "$actual" != 0.5 ]; then
            say 'ZL-APPLY-FAILED'
            restore_originals || :
            return 1
        fi
    done
    say 'ZL-APPLIED'
    return 0
}

LOCK="${BACKUP}.lock"
if ! mkdir "$LOCK" 2>/dev/null; then
    say 'ZL-BUSY'
    exit 1
fi
trap 'rmdir "$LOCK" 2>/dev/null || :' EXIT
trap 'exit 1' HUP INT TERM

case "${1:-}" in
    init|bootcomplete|run|apply) apply_safe ;;
    restore) restore_originals ;;
    *) say 'ZL-UNKNOWN-ACTION'; exit 1 ;;
esac
