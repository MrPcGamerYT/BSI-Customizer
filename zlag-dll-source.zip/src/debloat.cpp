/* =====================================================================
 *  debloat.cpp  --  the ADB tab back-end.
 *
 *  Talks to the running instance through the emulator's own adb binary
 *  (HD-Adb.exe), runs the two package lists, and reports every package
 *  individually. Nothing here runs on its own: a bit is set by the UI,
 *  the worker thread picks it up, and every action prints what it did.
 *
 *  Reversibility, stated up front because it is the whole risk:
 *      pm uninstall --user 0 <pkg>   ->  pm install-existing --user 0 <pkg>
 *      pm disable-user --user 0 <pkg> -> pm enable <pkg>
 *  It is an uninstall for user 0, not a deletion of the APK. "Restore
 *  everything" in the ADB tab undoes both lists.
 *
 *  Nothing is executed when adb is missing or no device is attached: the
 *  log says so and the counters stay at zero, rather than reporting a
 *  pass that never happened.
 * ===================================================================== */
#include "common.h"
#include "safe_adb.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <tlhelp32.h>

/* optimizer.cpp owns this (and the log buffer the UI reads) */
void apply_log(const char* fmt, ...);

/* ---- the two lists, exactly as the user specified them ------------ */
static const char* const DL_REMOVE[] = {
    "com.android.calendar",
    "com.android.contacts",
    "com.android.dialer",
    "com.android.camera2",
    "com.android.deskclock",
    "com.android.gallery3d",
    "com.android.bookmarkprovider",
    "com.android.htmlviewer",
    "com.android.wallpaper.livepicker",
    "com.android.wallpapercropper",
    "com.android.wallpaperpicker",
    "com.android.printspooler",
    "com.android.printservice.recommendation",
    "com.android.bips",
    "com.android.providers.calendar",
    "com.android.providers.blockednumber",
    "com.android.providers.userdictionary",
    "com.android.statementservice",
    "com.android.simappdialog",
    "com.android.carrierconfig",
    "com.android.carrierdefaultapp",
    "com.android.cts.priv.ctsshim",
    "com.android.cts.ctsshim",
    "com.android.internal.display.cutout.emulation.corner",
    "com.android.internal.display.cutout.emulation.double",
    "com.android.internal.display.cutout.emulation.tall",
    "com.android.companiondevicemanager",
    "com.android.traceur",
    "com.android.settings.intelligence",
    "com.android.storagemanager",
    "com.android.sharedstoragebackup",
    "com.android.backupconfirm",
    "com.android.vpndialogs",
    "com.android.provision",
    "com.android.onetimeinitializer",
    "com.android.calculator2",
    "com.android.email",
    "gg.now.billing.service",
    "gg.now.billing.service2",
    "gg.now.accounts",
    "com.google.android.onetimeinitializer",
    "com.google.android.syncadapters.contacts",
    "com.google.android.syncadapters.calendar",
    "com.google.android.partnersetup",
    "com.google.android.backuptransport",
    "com.google.android.play.games",
    NULL
};

static const char* const DL_DISABLE[] = {
    "com.android.vending",
    "com.bluestacks.home",
    "android.ext.services",
    "com.android.providers.telephony",
    "com.android.cellbroadcastreceiver",
    NULL
};

/* ---- shared state read by the UI --------------------------------- */
volatile LONG g_dbRunning = 0;
volatile LONG g_dbDone    = 0;
volatile LONG g_dbTotal   = 0;
volatile LONG g_dbOk      = 0;
volatile LONG g_dbFail    = 0;
volatile LONG g_dbChecked = 0;    /* 1 = a check pass has run         */
volatile LONG g_dbPresent = 0;    /* of the two lists, how many exist */
char          g_dbDevice[64] = {0};

static int count_list(const char* const* l)
{
    int n = 0;
    while (l[n]) n++;
    return n;
}

/* ---- find the emulator's adb ------------------------------------- */
static int db_find_adb(char* out, DWORD n)
{
    const char* cand[] = {
        "C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe",
        "C:\\Program Files\\BlueStacks\\HD-Adb.exe",
        "C:\\Program Files (x86)\\BlueStacks\\HD-Adb.exe",
        NULL
    };
    char self[MAX_PATH];
    GetModuleFileNameA(NULL, self, MAX_PATH);
    char* slash = strrchr(self, '\\');
    if (slash) {
        for (int i = 0; cand[i]; i++) {
            const char* leaf = strrchr(cand[i], '\\');
            char probe[MAX_PATH];
            *slash = 0;
            _snprintf(probe, sizeof(probe), "%s\\%s", self, leaf ? leaf + 1 : cand[i]);
            probe[sizeof(probe) - 1] = 0;
            if (GetFileAttributesA(probe) != INVALID_FILE_ATTRIBUTES) {
                lstrcpynA(out, probe, n);
                return 1;
            }
            *slash = '\\';
        }
    }
    for (int i = 0; cand[i]; i++) {
        if (GetFileAttributesA(cand[i]) != INVALID_FILE_ATTRIBUTES) {
            lstrcpynA(out, cand[i], n);
            return 1;
        }
    }
    if (SearchPathA(NULL, "adb.exe", NULL, n, out, NULL)) return 1;
    return 0;
}

static char s_adb[MAX_PATH] = {0};

/* One lookup for the whole product. The other modules each had their own
 * copy and NONE of them looked next to the emulator, so a portable HD-Adb
 * that the user dropped in the BlueStacks folder was reported as "no adb
 * found" while the ADB tab found it fine. */
extern "C" int zl_adb_find(char* out, DWORD n)
{
    if (s_adb[0]) { lstrcpynA(out, s_adb, n); return 1; }
    return db_find_adb(out, n);
}

static int db_adb(const char* args, void (*onLine)(const char*, void*), void* ctx)
{
    if (!s_adb[0] && !db_find_adb(s_adb, MAX_PATH)) return -99;
    return zl_adb_spawn(s_adb, args, onLine, ctx);
}

/* Never select the first attached device. Every guest operation targets
 * only the configured loopback port after a BlueStacks identity check. */
static int db_attach(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, sizeof(serial))) {
        g_dbDevice[0] = 0;
        return 0;
    }
    lstrcpynA(s_adb, adb, sizeof(s_adb));
    lstrcpynA(g_dbDevice, serial, sizeof(g_dbDevice));
    return 1;
}

/* ---- connect to a port ------------------------------------------- */
/* adb connect 127.0.0.1:<port> is how an emulator instance that is not on
 * the default serial gets reached: BlueStacks listens on 5555 unless the
 * user changed it, and a second instance is 5565, 5556, or whatever the
 * multi-instance manager handed out. The port is typed by the user, so it
 * is parsed as digits only and bounded -- a shell string built from raw
 * text is how you get a command injection into the user's own machine. */
extern "C" void zl_debloat_connect(int port)
{
    if (port < 1 || port > 65535) {
        apply_log("[!!] enter a port from 1 to 65535");
        return;
    }
    g_cfg.adbPort = port;
    if (!s_adb[0] && !db_find_adb(s_adb, MAX_PATH)) {
        apply_log("[!!] Android connection tool not found");
        return;
    }
    char args[128];
    _snprintf(args, sizeof(args), "connect 127.0.0.1:%d", port);
    args[sizeof(args) - 1] = 0;
    int rc = db_adb(args, NULL, NULL);
    if (rc != 0 || !db_attach()) {
        g_dbDevice[0] = 0;
        apply_log("[!!] selected instance was not verified; no guest changes were made");
        return;
    }
    zl_db_forget_scan(); /* selection and scan belong to the previous connection */
    apply_log("[ok] connected to the verified instance on port %d", port);
}

extern "C" void zl_debloat_disconnect(void)
{
    if (!g_dbDevice[0]) { apply_log("[i] nothing connected"); return; }
    char args[128];
    _snprintf(args, sizeof(args), "disconnect %s", g_dbDevice);
    args[sizeof(args) - 1] = 0;
    int rc = db_adb(args, NULL, NULL);
    if (rc == 0) {
        apply_log("[i] disconnect requested for %s", g_dbDevice);
        g_dbDevice[0] = 0;
        zl_db_forget_scan();
    } else {
        apply_log("[!!] disconnect request failed or timed out");
    }
}

/* ---- "which of these packages exist right now" -------------------- */
#define DB_INST_BUF 24576
static char s_installed[DB_INST_BUF];
static char s_disabled[DB_INST_BUF];

static void collect_line(const char* line, void* ctx)
{
    char* buf = (char*)ctx;
    size_t used = strlen(buf);
    if (strncmp(line, "package:", 8) != 0) return;
    const char* p = line + 8;
    size_t add = strlen(p) + 2;
    if (used + add + 2 >= DB_INST_BUF) return;
    if (used) { strcat(buf, "\n"); }
    strcat(buf, p);
}

/* Newline-wrapped membership test: prevents com.android.a matching
 * com.android.ab, which a plain strstr would do. */
static int in_set(const char* set, const char* pkg)
{
    char needle[256];
    _snprintf(needle, sizeof(needle), "\n%s\n", pkg);
    needle[sizeof(needle) - 1] = 0;
    char hay[DB_INST_BUF + 2];
    _snprintf(hay, sizeof(hay), "\n%s\n", set);
    hay[sizeof(hay) - 1] = 0;
    return strstr(hay, needle) != NULL;
}

extern "C" void zl_debloat_check(void)
{
    if (!db_attach()) { InterlockedExchange(&g_dbChecked, 0); return; }

    s_installed[0] = 0;
    s_disabled[0] = 0;
    char a[512];
    _snprintf(a, sizeof(a), "-s %s shell pm list packages", g_dbDevice);
    db_adb(a, collect_line, s_installed);
    _snprintf(a, sizeof(a), "-s %s shell pm list packages -d", g_dbDevice);
    db_adb(a, collect_line, s_disabled);

    int have = 0, want = 0;
    for (int i = 0; DL_REMOVE[i]; i++) {
        want++;
        if (in_set(s_installed, DL_REMOVE[i])) have++;
    }
    for (int i = 0; DL_DISABLE[i]; i++) {
        want++;
        if (in_set(s_installed, DL_DISABLE[i])) have++;
    }
    InterlockedExchange(&g_dbPresent, have);
    InterlockedExchange(&g_dbChecked, 1);
    apply_log("[ok] check: %d of %d packages on this instance", have, want);
    apply_log("[--] nothing was changed by the check");
}

/* ---- run the lists ------------------------------------------------ */
/* Batches of ten per adb call with an echo marker after each package, so
 * one droid-side failure does not hide the rest and the UI can still show
 * which package it is on. One adb process per package would be 51 spawns
 * on the host for a job that fits in six. */
#define DB_BATCH 10

static void result_line(const char* line, void* ctx)
{
    long* st = (long*)ctx;
    if (strstr(line, "Success") || strstr(line, "new state: enabled") ||
        strstr(line, "installed for user")) st[0]++;
    else if (strstr(line, "Failure") || strstr(line, "Exception") ||
             strstr(line, "Error") || strstr(line, "Unknown package")) st[1]++;
    if (strncmp(line, "ZL:", 3) == 0) {
        char done[64];
        lstrcpynA(done, line + 3, sizeof(done));
        apply_log("    %s", done);
    }
}

static void run_list(const char* const* list, const char* const* fmt)
{
    int n = count_list(list);
    InterlockedExchange(&g_dbTotal, n);
    InterlockedExchange(&g_dbDone, 0);
    InterlockedExchange(&g_dbOk, 0);
    InterlockedExchange(&g_dbFail, 0);

    char cmd[1500];
    int i = 0;
    while (i < n) {
        int j = i, len = 0;
        cmd[0] = 0;
        len = _snprintf(cmd, sizeof(cmd), "-s %s shell \"", g_dbDevice);
        if (len < 0 || len >= (int)sizeof(cmd) - 2) {
            apply_log("[!!] recovery command was too long; no batch sent");
            break;
        }
        while (j < n && j - i < DB_BATCH) {
            char entry[600];
            int add;
            char one[400];
            int oneLen = _snprintf(one, sizeof(one), fmt[0], list[j]);
            if (oneLen < 0 || oneLen >= (int)sizeof(one)) break;
            add = _snprintf(entry, sizeof(entry), "%s; echo ZL:%s; ", one, list[j]);
            if (add < 0 || add >= (int)sizeof(entry) ||
                len + add + 2 > (int)sizeof(cmd)) break;
            memcpy(cmd + len, entry, add);
            len += add;
            ++j;
        }
        if (j == i) {
            apply_log("[!!] recovery batch could not be formed");
            break;
        }
        cmd[len++] = '\"';
        cmd[len] = 0;

        long st[2] = {0, 0};
        int rc = db_adb(cmd, result_line, st);
        if (rc != 0) {
            apply_log("[!!] a package recovery batch failed or timed out");
            long unreported = (j - i) - st[0] - st[1];
            if (unreported > 0) st[1] += unreported;
        }
        InterlockedExchange(&g_dbOk,   g_dbOk + (LONG)st[0]);
        InterlockedExchange(&g_dbFail, g_dbFail + (LONG)st[1]);
        InterlockedExchange(&g_dbDone, j);
        apply_log("[..] %d / %d", j, n);
        i = j;
    }
}

extern "C" void zl_debloat_remove(void)
{
    apply_log("[!!] package removal is disabled to protect apps and their data");
}

extern "C" void zl_debloat_disable(void)
{
    apply_log("[!!] disabling system apps is unavailable for stability");
}

extern "C" void zl_debloat_restore(void)
{
    if (!db_attach()) return;
    static const char* rein[] = { "pm install-existing --user 0 %s" };
    static const char* en[]   = { "pm enable %s" };

    apply_log("--- restoring: re-installing the removed list ---");
    run_list(DL_REMOVE, rein);
    long okA = g_dbOk, failA = g_dbFail;

    apply_log("--- restoring: re-enabling the disabled list ---");
    run_list(DL_DISABLE, en);
    apply_log("[i] recovery: %ld reported success, %ld reported failure",
              (long)(okA + g_dbOk), (long)(failA + g_dbFail));
    apply_log("[i] packages the emulator never had will report 'Failure' -- "
              "that is expected and harmless");
}

/* =====================================================================
 *  Android speed actions -- the ones our boot script did not already do.
 *
 *  Ideas taken from the uploaded optimizer, implementation written here:
 *  every one of them is a single adb shell call, every one has an undo in
 *  the same tab, and none of them touches the game's own files.
 *
 *  The rules that made me leave some of that code alone: no /sys writes
 *  (a wrong path there hangs the GPU driver), no killing system_server or
 *  the launcher, and nothing that survives a reboot without the user
 *  pressing it again.
 * ===================================================================== */

typedef struct ShellOutput { char* data; size_t size; } ShellOutput;
static void shell_line(const char* line, void* ctx)
{
    ShellOutput* o = (ShellOutput*)ctx;
    if (!o || !o->data || o->size < 2 || !line[0]) return;
    size_t used = strlen(o->data);
    if (used && used + 1 < o->size) o->data[used++] = '\n';
    size_t avail = o->size - used - 1;
    size_t len = strlen(line);
    if (len > avail) len = avail;
    memcpy(o->data + used, line, len);
    o->data[used + len] = 0;
}

static int db_shell(const char* cmd, char* out, int outLen)
{
    if (out && outLen > 0) out[0] = 0;
    if (!s_adb[0] || !g_dbDevice[0]) {
        apply_log("[!!] no verified instance -- nothing sent");
        return -1;
    }
    char args[1600];
    int n = _snprintf(args, sizeof(args), "-s %s shell \"%s\"", g_dbDevice, cmd);
    if (n < 0 || n >= (int)sizeof(args)) return -4;
    ShellOutput o = {out, outLen > 0 ? (size_t)outLen : 0};
    return db_adb(args, out ? shell_line : NULL, &o);
}

extern "C" void zl_android_anim(int on)
{
    if (on) zl_initsh_restore_session();
    else zl_initsh_run();
}

extern "C" void zl_android_killbg(void)
{
    if (!db_attach()) return;
    apply_log("--- closing everything in the background ---");
    char before[512] = {0}, after[512] = {0};
    db_shell("ps -A | wc -l", before, sizeof(before));
    int rc = db_shell("am kill-all", NULL, 0);
    apply_log(rc == 0 ? "[ok] background close request accepted"
                      : "[!!] the instance refused am kill-all");
    db_shell("ps -A | wc -l", after, sizeof(after));
    if (before[0] && after[0])
        apply_log("[ok] processes: %s -> %s", before, after);
    apply_log("[i] background work may be interrupted; no apps were uninstalled");
}

/* Foreground inspection is read-only: do not force OOM or CPU sets. */
extern "C" void zl_android_gameboost(void)
{
    if (!db_attach()) return;
    char focus[512] = {0};
    int rc = db_shell("dumpsys window | grep -m1 -oE 'u0 [a-zA-Z0-9_.]+/' | head -1",
                      focus, sizeof(focus));
    if (rc == 0 && focus[0]) apply_log("[i] foreground app: %s", focus);
    else apply_log("[!!] foreground app could not be identified");
    apply_log("[i] CPU scheduling and memory policy were left unchanged");
}

extern "C" void zl_android_gms(int suspend)
{
    if (suspend) {
        apply_log("[!!] suspending essential services is disabled for stability");
        return;
    }
    if (!db_attach()) return;
    const char* apps[] = {"com.google.android.gms", "com.android.vending",
                          "com.google.android.googlequicksearchbox", NULL};
    for (int i = 0; apps[i]; ++i) {
        char command[256], reply[512] = {0};
        _snprintf(command, sizeof(command), "pm unsuspend %s", apps[i]);
        int rc = db_shell(command, reply, sizeof(reply));
        if (rc == 0 && (strstr(reply, "unsuspended") || strstr(reply, "Success") ||
                        strstr(reply, "not suspended")) &&
            !strstr(reply, "Error") && !strstr(reply, "Failure") &&
            !strstr(reply, "Exception"))
            apply_log("[ok] resume request accepted for %s", apps[i]);
        else
            apply_log("[!!] resume request failed for %s", apps[i]);
    }
}

/* Legacy deep tuning forced thermal, memory, renderer and services. It is
 * deliberately retired. The gentle replacement snapshots animation values. */
volatile LONG zl_android_cmd = 0;

extern "C" void zl_android_deep(void)
{
    zl_initsh_run();
}

extern "C" void zl_android_stock(void)
{
    zl_initsh_uninstall();
    apply_log("[i] check older property overrides separately; no unsaved values were guessed");
}

/* =====================================================================
 *  FREE FIRE lane.
 *
 *  The package name is detected, not assumed: Free Fire ships as
 *  com.dts.freefireth, com.dts.freefiremax, com.dts.freefireth.lite and
 *  half a dozen regional builds, and a hard-coded name silently optimises
 *  nothing on the ones it does not match. Detection asks the instance what
 *  is actually installed, prefers whichever of them is running, and says
 *  out loud which name it picked.
 * ===================================================================== */
char          g_ffPkg[80] = {0};
volatile LONG g_ffFound = 0;

typedef struct { char names[8][80]; int n; } FFList;

static void ff_line(const char* line, void* ctx)
{
    FFList* l = (FFList*)ctx;
    if (strncmp(line, "package:", 8) != 0 || l->n >= 8) return;
    lstrcpynA(l->names[l->n], line + 8, 80);
    l->n++;
}

extern "C" void zl_ff_detect(void)
{
    g_ffPkg[0] = 0;
    if (!db_attach()) { InterlockedExchange(&g_ffFound, 0); return; }

    FFList l; memset(&l, 0, sizeof(l));
    {
        /* filter host-side: the pipe costs one process and gives us the
         * lines already trimmed, which is the only way to see them */
        char args[400];
        _snprintf(args, sizeof(args),
                  "-s %s shell pm list packages | grep -iE 'freefire|garena|dts\\.freefire'",
                  g_dbDevice);
        zl_adb_spawn(s_adb, args, ff_line, &l);
    }

    if (!l.n) {
        /* grep may not exist on a stripped build: fall back to the full list */
        char args[300], big[4096] = {0};
        _snprintf(args, sizeof(args), "-s %s shell pm list packages", g_dbDevice);
        zl_adb_spawn(s_adb, args, shell_line, big);
        char* p = big;
        while (p && *p && l.n < 8) {
            char* nl = strchr(p, '\n');
            if (nl) *nl = 0;
            const char* name = p;
            if (strncmp(name, "package:", 8) == 0) name += 8;
            char low[128];
            lstrcpynA(low, name, sizeof(low));
            for (char* q = low; *q; q++) if (*q >= 'A' && *q <= 'Z') *q += 32;
            if (strstr(low, "freefire") || strstr(low, "garena")) {
                lstrcpynA(l.names[l.n], name, 80);
                l.n++;
            }
            p = nl ? nl + 1 : NULL;
        }
    }

    if (!l.n) {
        g_ffPkg[0] = 0;
        InterlockedExchange(&g_ffFound, 0);
        apply_log("[!!] Free Fire is not installed on this instance. Install it, "
                  "or press this while the game is open.");
        return;
    }

    /* several builds installed: take the one that is running */
    int chosen = 0;
    for (int i = 0; i < l.n; i++) {
        char q[200], pid[64] = {0};
        _snprintf(q, sizeof(q), "pidof %s", l.names[i]);
        db_shell(q, pid, sizeof(pid));
        if (atoi(pid) > 0) { chosen = i; break; }
    }
    lstrcpynA(g_ffPkg, l.names[chosen], sizeof(g_ffPkg));
    InterlockedExchange(&g_ffFound, 1);
    apply_log("[ok] Free Fire: %s%s", g_ffPkg,
              l.n > 1 ? " (of several builds installed, this is the one running)"
                      : "");
}

extern "C" void zl_ff_optimize(void)
{
    zl_ff_detect();
    if (!g_ffPkg[0]) {
        apply_log("[!!] game not detected; no tuning applied");
        return;
    }
    apply_log("[i] game detected; no game files, services or process policy changed");
    zl_initsh_run();
}

/* ---------------------------------------------------------------------
 *  Guest resolution. This is the single biggest real FPS lever in an
 *  emulator: the GPU cost of a frame scales with the number of guest
 *  pixels, so rendering at 75% of the width and height is ~44% less work,
 *  and the emulator upscales the result to the window. Softer picture,
 *  genuinely more frames.
 *
 *  Reversible with the 100% button, which is just the platform's own
 *  "wm size reset" -- no state of ours to lose.
 * ------------------------------------------------------------------- */
static int first_int(const char* s, int from)
{
    int i = from;
    while (s[i] && (s[i] < '0' || s[i] > '9')) i++;
    int v = 0;
    while (s[i] >= '0' && s[i] <= '9') { v = v * 10 + (s[i] - '0'); i++; }
    return v;
}

extern "C" void zl_android_res(int pct)
{
    if (!db_attach()) return;

    if (pct >= 100) {
        db_shell("wm size reset; wm density reset", NULL, 0);
        apply_log("[ok] display back to the instance's own size and density");
        return;
    }

    char sz[256] = {0}, de[128] = {0};
    db_shell("wm size", sz, sizeof(sz));
    db_shell("wm density", de, sizeof(de));

    /* "Physical size: 1920x1080" -- take the first WxH on the line */
    int w = first_int(sz, 0);
    const char* x = strchr(sz, 'x');
    int h = x ? first_int(x, 1) : 0;
    int den = first_int(de, 0);

    if (w < 320 || h < 240) {
        apply_log("[!!] could not read the current size (%s)", sz[0] ? sz : "no answer");
        return;
    }
    int nw = w * pct / 100, nh = h * pct / 100;
    if (nw < 320 || nh < 240) { apply_log("[!!] %d%% would be too small to run", pct); return; }
    int nd = den > 0 ? den * pct / 100 : 0;

    char cmd[256];
    if (nd > 0) _snprintf(cmd, sizeof(cmd), "wm size %dx%d; wm density %d", nw, nh, nd);
    else        _snprintf(cmd, sizeof(cmd), "wm size %dx%d", nw, nh);
    cmd[sizeof(cmd) - 1] = 0;
    db_shell(cmd, NULL, 0);

    apply_log("[ok] rendering at %dx%d (%d%% of %dx%d) -- the emulator upscales it",
              nw, nh, pct, w, h);
    apply_log("[i] press 100%% to go back; drag the window or restart the app if "
              "a game letterboxes");
}

/* Host-side: raise the threads that draw. Our own render thread is inside
 * HD-Player and spends its life in SwapBuffers, so it is the one that has
 * to win the scheduler against everything else on the machine. Reversible
 * only in the sense that the process can lower them again -- it dies with
 * the emulator, which is exactly what we want from a per-session boost. */
extern "C" void zl_host_threadboost(void)
{
    SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
    int raised = 0, total = 0;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snap == INVALID_HANDLE_VALUE) {
        apply_log("[!!] cannot list threads (err %lu)", GetLastError());
        return;
    }
    THREADENTRY32 te; te.dwSize = sizeof(te);
    DWORD me = GetCurrentThreadId();
    if (Thread32First(snap, &te)) {
        do {
            if (te.th32OwnerProcessID != GetCurrentProcessId()) continue;
            if (te.th32ThreadID == me) continue;
            total++;
            HANDLE th = OpenThread(THREAD_SET_INFORMATION | THREAD_SET_LIMITED_INFORMATION,
                                   FALSE, te.th32ThreadID);
            if (!th) continue;
            if (SetThreadPriority(th, THREAD_PRIORITY_HIGHEST)) raised++;
            CloseHandle(th);
        } while (Thread32Next(snap, &te));
    }
    CloseHandle(snap);
    apply_log("[ok] %d of %d emulator threads raised to highest (%d skipped: "
              "Windows refused them)", raised, total, total - raised);
    apply_log("[i] the thread that draws is the one that matters; this is a "
              "per-session boost, gone when the emulator restarts");
}

volatile LONG g_keepAwake = 0;

extern "C" void zl_host_awake(int on)
{
    InterlockedExchange(&g_keepAwake, on ? 1 : 0);
    if (!on) SetThreadExecutionState(ES_CONTINUOUS);
    apply_log(on ? "[ok] the display and the CPU will stay awake while this runs"
                 : "[ok] normal sleep behaviour restored");
}
