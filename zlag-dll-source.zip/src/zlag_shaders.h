/* =====================================================================
 *  zlag_shaders.h  --  the six-stage post-process chain.
 *
 *  Ported from the ENIGMA R69 sources (shaders/enhancer.frag etc.) with
 *  four deliberate fixes so they run on every BlueStacks GL stack:
 *
 *   1. NO "#version" directive at all. The chain has to compile in three
 *      completely different worlds:
 *        - desktop GL 2.x+ context   (compatibility profile, #version 110 ok)
 *        - BlueStacks native GLES 2  (ES GLSL 1.00 -- "#version 110" is an
 *                                     error there, ES wants "100 es")
 *        - ANGLE                     (translates ES; also rejects 110)
 *      Omitting the directive makes every one of them default to its own
 *      language version. The code below is the common subset: attribute/
 *      varying/texture2D/gl_FragColor, no array indexing, no in/out, no
 *      texture(), no bitwise ops, loops with constant bounds only.
 *
 *   2. GLSL 1.00 has no dynamic array indexing -> the 3x3 SAD block in
 *      opticalflow is unrolled (identical maths, 20 candidates).
 *
 *   3. enhancer declared unused samplers (flowF/prev2F/flowT) which some
 *      drivers happily bind to unit 0 -> removed.
 *
 *   4. every stage early-outs to a bit-exact pass-through when its weight
 *      is zero, so "off" really means "untouched frame".
 * ===================================================================== */
#ifndef ZLAG_SHADERS_H
#define ZLAG_SHADERS_H

/* ---------------- fullscreen quad -------------------------------- */
static const char* ZL_VS =
"#ifdef GL_ES\n"
"precision highp float;\n"
"#endif\n"
"attribute vec2 aPos;\n"
"attribute vec2 aUV;\n"
"varying vec2 vUV;\n"
"void main(){ vUV = aUV; gl_Position = vec4(aPos, 0.0, 1.0); }\n";

/* ---------------- 1. FXAA 3.11-style + edge sharpen --------------- */
static const char* ZL_FS_FXAA =
"#ifdef GL_ES\n"
"precision highp float;\n"
"precision mediump sampler2D;\n"
"#endif\n"
"uniform sampler2D t;\n"
"uniform vec2 texel;\n"
"uniform float amt;\n"
"varying vec2 vUV;\n"
"void main(){\n"
"  vec3 rgbM = texture2D(t, vUV).rgb;\n"
"  if (amt < 0.004) { gl_FragColor = vec4(rgbM, 1.0); return; }\n"
"  vec3 nw = texture2D(t, vUV + vec2(-1.0,-1.0)*texel).rgb;\n"
"  vec3 ne = texture2D(t, vUV + vec2( 1.0,-1.0)*texel).rgb;\n"
"  vec3 sw = texture2D(t, vUV + vec2(-1.0, 1.0)*texel).rgb;\n"
"  vec3 se = texture2D(t, vUV + vec2( 1.0, 1.0)*texel).rgb;\n"
"  vec3 L = vec3(0.299, 0.587, 0.114);\n"
"  float lNW = dot(nw,L), lNE = dot(ne,L), lSW = dot(sw,L), lSE = dot(se,L), lM = dot(rgbM,L);\n"
"  float lMin = min(lM, min(min(lNW,lNE), min(lSW,lSE)));\n"
"  float lMax = max(lM, max(max(lNW,lNE), max(lSW,lSE)));\n"
"  if (lMax - lMin < 0.10) { gl_FragColor = vec4(rgbM, 1.0); return; }\n"
"  vec2 dir = vec2(-((lNW+lNE)-(lSW+lSE)), ((lNW+lSW)-(lNE+lSE)));\n"
"  float dr = max((lNW+lNE+lSW+lSE)*0.03125, 0.0078125);\n"
"  float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + dr);\n"
"  dir = clamp(dir*rcp, vec2(-3.0), vec2(3.0)) * texel;\n"
"  vec3 a = 0.5*(texture2D(t, vUV + dir*(1.0/3.0-0.5)).rgb\n"
"              + texture2D(t, vUV + dir*(2.0/3.0-0.5)).rgb);\n"
"  vec3 b = a*0.5 + 0.25*(texture2D(t, vUV - dir*0.5).rgb\n"
"                       + texture2D(t, vUV + dir*0.5).rgb);\n"
"  float lB = dot(b,L);\n"
"  vec3 chosen = (lB < lMin || lB > lMax) ? a : b;\n"
"  gl_FragColor = vec4(mix(rgbM, chosen, 0.84*amt), 1.0);\n"
"}\n";

/* ---------------- 2. bloom bright-pass --------------------------- */
static const char* ZL_FS_BRIGHT =
"#ifdef GL_ES\n"
"precision highp float;\n"
"precision mediump sampler2D;\n"
"#endif\n"
"uniform sampler2D t;\n"
"uniform float thr;\n"
"varying vec2 vUV;\n"
"void main(){\n"
"  vec3 c = texture2D(t, vUV).rgb;\n"
"  float l = dot(c, vec3(0.3086, 0.6094, 0.0820));\n"
"  gl_FragColor = vec4(c * smoothstep(thr, thr + 0.46, l), 1.0);\n"
"}\n";

/* ---------------- 3. separable gaussian -------------------------- */
static const char* ZL_FS_GAUSS =
"#ifdef GL_ES\n"
"precision highp float;\n"
"precision mediump sampler2D;\n"
"#endif\n"
"uniform sampler2D t;\n"
"uniform vec2 dir;\n"
"varying vec2 vUV;\n"
"void main(){\n"
"  vec3 a = texture2D(t, vUV).rgb * 0.2270270270;\n"
"  vec2 o1 = dir * 1.3846153846;\n"
"  vec2 o2 = dir * 3.2307692308;\n"
"  a += (texture2D(t, vUV + o1).rgb + texture2D(t, vUV - o1).rgb) * 0.3162162162;\n"
"  a += (texture2D(t, vUV + o2).rgb + texture2D(t, vUV - o2).rgb) * 0.0702702703;\n"
"  gl_FragColor = vec4(a, 1.0);\n"
"}\n";

/* ---------------- 4. optical flow (camera motion) -----------------
 * 20-candidate 3x3 SAD block matcher, exactly the maths of the ENIGMA
 * opticalflow.frag, written without dynamic array indexing so it also
 * compiles as ES GLSL 1.00.
 * Output: rg = motion vector (v/8 + 0.5), b = confidence.
 * ---------------------------------------------------------------- */
static const char* ZL_FS_FLOW =
"#ifdef GL_ES\n"
"precision highp float;\n"
"precision mediump sampler2D;\n"
"#endif\n"
"uniform sampler2D cur;\n"
"uniform sampler2D prev;\n"
"uniform vec2 texel;\n"
"varying vec2 vUV;\n"
"const vec3 W = vec3(0.3086, 0.6094, 0.0820);\n"
"float Lc(vec2 uv){ return dot(texture2D(cur,  uv).rgb, W); }\n"
"float Lp(vec2 uv){ return dot(texture2D(prev, uv).rgb, W); }\n"
"float sadAt(vec2 o, float fd0, float fd1, float fd2, float fd3, float fd4,\n"
"            float fd5, float fd6, float fd7, float fd8){\n"
"  float q0 = Lp(vUV+o);\n"
"  float q1 = Lp(vUV+o+vec2( texel.x, 0.0));\n"
"  float q2 = Lp(vUV+o+vec2(-texel.x, 0.0));\n"
"  float q3 = Lp(vUV+o+vec2(0.0,  texel.y));\n"
"  float q4 = Lp(vUV+o+vec2(0.0, -texel.y));\n"
"  float q5 = Lp(vUV+o+vec2( texel.x,  texel.y));\n"
"  float q6 = Lp(vUV+o+vec2(-texel.x,  texel.y));\n"
"  float q7 = Lp(vUV+o+vec2( texel.x, -texel.y));\n"
"  float q8 = Lp(vUV+o+vec2(-texel.x, -texel.y));\n"
"  float qb = (q0+q1+q2+q3+q4+q5+q6+q7+q8) * 0.1111111;\n"
"  return abs(fd0-(q0-qb)) + abs(fd1-(q1-qb)) + abs(fd2-(q2-qb))\n"
"       + abs(fd3-(q3-qb)) + abs(fd4-(q4-qb)) + abs(fd5-(q5-qb))\n"
"       + abs(fd6-(q6-qb)) + abs(fd7-(q7-qb)) + abs(fd8-(q8-qb));\n"
"}\n"
"void main(){\n"
"  float fd0, fd1, fd2, fd3, fd4, fd5, fd6, fd7, fd8;\n"
"  float c0 = Lc(vUV);\n"
"  float c1 = Lc(vUV + vec2( texel.x, 0.0));\n"
"  float c2 = Lc(vUV + vec2(-texel.x, 0.0));\n"
"  float c3 = Lc(vUV + vec2(0.0,  texel.y));\n"
"  float c4 = Lc(vUV + vec2(0.0, -texel.y));\n"
"  float c5 = Lc(vUV + vec2( texel.x,  texel.y));\n"
"  float c6 = Lc(vUV + vec2(-texel.x,  texel.y));\n"
"  float c7 = Lc(vUV + vec2( texel.x, -texel.y));\n"
"  float c8 = Lc(vUV + vec2(-texel.x, -texel.y));\n"
"  float cb = (c0+c1+c2+c3+c4+c5+c6+c7+c8) * 0.1111111;\n"
"  fd0 = c0-cb; fd1 = c1-cb; fd2 = c2-cb; fd3 = c3-cb; fd4 = c4-cb;\n"
"  fd5 = c5-cb; fd6 = c6-cb; fd7 = c7-cb; fd8 = c8-cb;\n"
"  float var = (fd0*fd0+fd1*fd1+fd2*fd2+fd3*fd3+fd4*fd4+\n"
"               fd5*fd5+fd6*fd6+fd7*fd7+fd8*fd8) * 0.1111111;\n"
"  if (var < 0.0004) { gl_FragColor = vec4(0.5, 0.5, 0.0, 1.0); return; }\n"
"  float bc0 = sadAt(vec2(0.0), fd0,fd1,fd2,fd3,fd4,fd5,fd6,fd7,fd8);\n"
"  if (bc0 < 0.18) { gl_FragColor = vec4(0.5, 0.5, 0.0, 1.0); return; }\n"
"  float best = 1.0e9; float scnd = 1.0e9; vec2 mv = vec2(0.0);\n"
"  /* ring 1: 1 texel, ring 2: 2 texels, far: 4 texels on the axes.\n"
"     r1 is what makes 2-6px in-game pans representable. */\n"
"  for (int a = -1; a <= 1; a++)\n"
"    for (int b = -1; b <= 1; b++) {\n"
"      if (a == 0 && b == 0) continue;\n"
"      vec2 o = vec2(float(b), float(a)) * texel;\n"
"      float d = sadAt(o, fd0,fd1,fd2,fd3,fd4,fd5,fd6,fd7,fd8);\n"
"      if (d < best) { scnd = best; best = d; mv = o; }\n"
"      else if (d < scnd) { scnd = d; }\n"
"    }\n"
"  for (int a2 = -2; a2 <= 2; a2 += 2)\n"
"    for (int b2 = -2; b2 <= 2; b2 += 2) {\n"
"      if (a2 == 0 && b2 == 0) continue;\n"
"      vec2 o2 = vec2(float(b2), float(a2)) * texel * 2.0;\n"
"      float d2 = sadAt(o2, fd0,fd1,fd2,fd3,fd4,fd5,fd6,fd7,fd8);\n"
"      if (d2 < best) { scnd = best; best = d2; mv = o2; }\n"
"      else if (d2 < scnd) { scnd = d2; }\n"
"    }\n"
"  vec2 fx = vec2(1.0, 0.0) * texel * 4.0;\n"
"  float d3 = sadAt( fx, fd0,fd1,fd2,fd3,fd4,fd5,fd6,fd7,fd8); if (d3 < best) { scnd = best; best = d3; mv =  fx; } else if (d3 < scnd) { scnd = d3; }\n"
"  float d4 = sadAt(-fx, fd0,fd1,fd2,fd3,fd4,fd5,fd6,fd7,fd8); if (d4 < best) { scnd = best; best = d4; mv = -fx; } else if (d4 < scnd) { scnd = d4; }\n"
"  vec2 fy = vec2(0.0, 1.0) * texel * 4.0;\n"
"  float d5 = sadAt( fy, fd0,fd1,fd2,fd3,fd4,fd5,fd6,fd7,fd8); if (d5 < best) { scnd = best; best = d5; mv =  fy; } else if (d5 < scnd) { scnd = d5; }\n"
"  float d6 = sadAt(-fy, fd0,fd1,fd2,fd3,fd4,fd5,fd6,fd7,fd8); if (d6 < best) { scnd = best; best = d6; mv = -fy; } else if (d6 < scnd) { scnd = d6; }\n"
"  if (best > bc0 * 0.55) { gl_FragColor = vec4(0.5, 0.5, 0.0, 1.0); return; }\n"
"  float confq    = 1.0 - clamp((best - 0.10) * 1.2, 0.0, 1.0);\n"
"  float distinct = clamp((scnd - best) * 1.5, 0.0, 1.0);\n"
"  vec2 enc = mv / (texel * 4.0) * 0.5 + 0.5;\n"
"  float cf = confq * distinct;\n"
"  gl_FragColor = vec4(mix(vec2(0.5), enc, cf), cf, 1.0);\n"
"}\n";

/* ---------------- 5. final composite ------------------------------
 * sat / con / shp / warm / lift / hdr / amb / vig / bloom + the
 * camera-locked motion smear driven by the flow texture.  Every term is
 * weighted so the neutral setting is a mathematical identity.
 * --------------------------------------------------------------- */
static const char* ZL_FS_COMPOSITE =
"#ifdef GL_ES\n"
"precision highp float;\n"
"precision mediump sampler2D;\n"
"#endif\n"
"uniform sampler2D frame;\n"
"uniform sampler2D bloomT;\n"
"uniform sampler2D flowT;\n"
"uniform sampler2D prevF;\n"
"uniform float sat, con, shp, warm, blm, lift, vig, hdr, amb, mblur, flowAmt;\n"
"uniform float sres;\n"
"uniform float rcas;\n"
"uniform vec2 texel;\n"
"uniform float hasPrev;\n"
"varying vec2 vUV;\n"
"void main(){\n"
"  vec2 uv = vUV;\n"
"  vec3 c = texture2D(frame, uv).rgb;\n"
"  if (mblur > 0.001 && flowAmt > 0.001) {\n"
"    vec4 f = texture2D(flowT, uv);\n"
"    vec2 enc = f.rg;\n"
"    float cw = clamp(f.b * flowAmt, 0.0, 1.0);\n"
"    vec2 mv = (enc * 2.0 - 1.0) * 4.0;          /* texels */\n"
"    vec2 v  = mv * texel * 1.5;\n"
"    vec3 t1 = texture2D(frame, uv - v * 0.35).rgb;\n"
"    vec3 t2 = texture2D(frame, uv - v * 0.70).rgb;\n"
"    vec3 p1 = hasPrev > 0.5 ? texture2D(prevF, uv).rgb : c;\n"
"    float w  = mblur * cw;\n"
"    float wt = mblur * (1.0 - cw) * 0.22;\n"
"    c = c * (1.0 - w * 0.45 - wt) + t1 * (w * 0.27) + t2 * (w * 0.18) + p1 * wt;\n"
"  }\n"
"  if (abs(shp) > 0.001) {\n"
"    vec3 cE = texture2D(frame, uv + vec2(texel.x, 0.0)).rgb;\n"
"    vec3 cW = texture2D(frame, uv - vec2(texel.x, 0.0)).rgb;\n"
"    vec3 cN = texture2D(frame, uv + vec2(0.0, texel.y)).rgb;\n"
"    vec3 cS = texture2D(frame, uv - vec2(0.0, texel.y)).rgb;\n"
"    vec3 avg = (cE + cW + cN + cS) * 0.25;\n"
"    vec3 shd = clamp(c - avg, vec3(-0.08), vec3(0.08));\n"
"    c = c + shd * shp * 1.35;\n"
"  }\n"
  /* ---- upscale reconstruction ------------------------------------
   * Runs the frame at the resolution the emulator gave us, which for a
   * 960x540 guest blown up to a 1080p window has already been bilinearly
   * stretched: the edges are soft and the detail is gone before we see it.
   * This cannot invent detail, but it can put back the edge profile that
   * bilinear smoothing removed, which is most of what "looks soft" means.
   *
   * Contrast-adaptive: the correction is a 4-tap cross laplacian, and its
   * size is limited per pixel by how much local contrast is already there.
   * Flat areas get almost nothing (no noise amplification), and strong
   * edges are clamped so they cannot ring. Four extra taps and a handful
   * of ALU ops -- this is why it costs no measurable frame time. */
  /* ---- RCAS: the sharpening half of FSR ---------------------------
   * FidelityFX Contrast Adaptive Sharpening. This is a real slice of the
   * FSR 1 pipeline, not a look-alike: a high-pass of the 4 axis neighbours,
   * scaled per pixel by how much headroom that pixel has between its local
   * min and max. Flat areas get almost nothing, so noise is not amplified;
   * already-saturated edges get almost nothing, so nothing rings.
   *
   * What FSR's other half (EASU) needs is the LOW resolution source so it
   * can decide edge direction while upscaling. We only ever see the frame
   * after the emulator has already stretched it, so EASU has nothing to
   * work from here -- that is the super-resolution block above, doing what
   * it can with the same idea. All of this is SPATIAL: vendor-neutral, no
   * tensor cores, works identically on NVIDIA, AMD and Intel.
   */
"  if (rcas > 0.001) {\n"
"    vec3 aN = texture2D(frame, uv + vec2(0.0, texel.y)).rgb;\n"
"    vec3 aS = texture2D(frame, uv - vec2(0.0, texel.y)).rgb;\n"
"    vec3 aE = texture2D(frame, uv + vec2(texel.x, 0.0)).rgb;\n"
"    vec3 aW = texture2D(frame, uv - vec2(texel.x, 0.0)).rgb;\n"
"    vec3 mn = min(c, min(min(aN, aS), min(aE, aW)));\n"
"    vec3 mx = max(c, max(max(aN, aS), max(aE, aW)));\n"
"    vec3 hitMin = mn / max(mx, vec3(0.0001)) * 0.25;\n"
"    vec3 hitMax = (1.0 - mx) / max(1.0 - mn, vec3(0.0001)) * 0.25;\n"
"    vec3 lobe = clamp(min(hitMin, hitMax), 0.0, 1.0);\n"
"    vec3 hp = c - (aN + aS + aE + aW) * 0.25;\n"
"    c = clamp(c + lobe * hp * (rcas * 2.2), 0.0, 1.0);\n"
"  }\n"
"  if (sres > 0.001) {\n"
"    vec3 cN2 = texture2D(frame, uv + vec2(0.0, texel.y)).rgb;\n"
"    vec3 cS2 = texture2D(frame, uv - vec2(0.0, texel.y)).rgb;\n"
"    vec3 cE2 = texture2D(frame, uv + vec2(texel.x, 0.0)).rgb;\n"
"    vec3 cW2 = texture2D(frame, uv - vec2(texel.x, 0.0)).rgb;\n"
"    vec3 lap = c * 4.0 - cN2 - cS2 - cE2 - cW2;\n"
"    vec3 lo = min(min(cN2, cS2), min(cE2, cW2));\n"
"    vec3 hi = max(max(cN2, cS2), max(cE2, cW2));\n"
"    vec3 rng = hi - lo;\n"
"    float detail = 1.0 / (1.0 + dot(rng, vec3(0.3333)) * 9.0);\n"
"    lap = clamp(lap, vec3(-0.14), vec3(0.14));\n"
"    c += lap * sres * (0.22 + 0.58 * detail);\n"
"  }\n"
"  c += texture2D(bloomT, uv).rgb * blm * 2.4;\n"
"  float l = dot(c, vec3(0.3086, 0.6094, 0.0820));\n"
"  c = mix(vec3(l), c, 1.0 + sat);\n"
"  /* con*2+1 keeps 0 = identity (1+con doubled the image) */\n"
"  c = (c - 0.5) * (1.0 + con * 2.0) + 0.5;\n"
"  c.r += warm * 2.0; c.g += warm * 0.6; c.b -= warm * 1.2;\n"
"  c = pow(max(c, vec3(0.0)), vec3(1.0 / (1.0 + lift)));\n"
"  float hl = max(dot(c, vec3(0.3086, 0.6094, 0.0820)), 0.0);\n"
"  c = c * (1.0 + hdr * (hl - 0.35) * 1.15);\n"
"  float al = 1.0 - clamp(dot(c, vec3(0.3086, 0.6094, 0.0820)), 0.0, 1.0);\n"
"  c += vec3(0.085, 0.115, 0.19) * amb * al * al;\n"
"  c *= 1.0 - vig * 0.85 * smoothstep(0.36, 0.82, distance(uv, vec2(0.5)));\n"
"  c = c / (1.0 + max(c - 1.0, vec3(0.0)) * 0.85);\n"
"  gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);\n"
"}\n";

/* ---------------- 6. pass-through (fallback / probe) ------------- */
static const char* ZL_FS_COPY =
"#ifdef GL_ES\n"
"precision highp float;\n"
"precision mediump sampler2D;\n"
"#endif\n"
"uniform sampler2D t;\n"
"varying vec2 vUV;\n"
"void main(){ gl_FragColor = texture2D(t, vUV); }\n";

#endif /* ZLAG_SHADERS_H */
