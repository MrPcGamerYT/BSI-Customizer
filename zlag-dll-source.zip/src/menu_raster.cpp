/* =====================================================================
 *  menu_raster.cpp  --  ImGui draw lists -> an RGBA pixel buffer.
 *
 *  The menu window needs to show pixels. Getting them through the GL in
 *  this process kept failing in ways an external process does not: the
 *  buffer ids, attribute arrays and texture sampling all behaved
 *  differently here than in a plain application, and every failure looked
 *  like success (correct draw data, no error, black screen).
 *
 *  So the window rasterises its own pixels. ImGui still lays everything
 *  out -- same widgets, same tabs, same code path as the overlay -- and
 *  this file turns the resulting triangles into colour. No GL state can
 *  interfere, because the only thing GL still does is blit the finished
 *  buffer, and a blit that fails is a blit that fails visibly.
 * ===================================================================== */
#include <math.h>
#include <string.h>
#include "imgui.h"

extern "C" void zlm_raster(const ImDrawData* dd, unsigned int* out,
                           int w, int h, const unsigned char* atlas,
                           int aw, int ah);

static inline unsigned int blend(unsigned int dst, float sr, float sg, float sb, float sa)
{
    if (sa <= 0.0f) return dst;
    float dr = (float)( dst        & 0xFF) / 255.0f;
    float dg = (float)((dst >> 8)  & 0xFF) / 255.0f;
    float db = (float)((dst >> 16) & 0xFF) / 255.0f;
    float da = (float)((dst >> 24) & 0xFF) / 255.0f;

    float or_ = sr * sa + dr * (1.0f - sa);
    float og  = sg * sa + dg * (1.0f - sa);
    float ob  = sb * sa + db * (1.0f - sa);
    float oa  = sa      + da * (1.0f - sa);

    unsigned int r = (unsigned int)(or_ * 255.0f + 0.5f);
    unsigned int g = (unsigned int)(og  * 255.0f + 0.5f);
    unsigned int b = (unsigned int)(ob  * 255.0f + 0.5f);
    unsigned int a = (unsigned int)(oa  * 255.0f + 0.5f);
    if (r > 255) r = 255;
    if (g > 255) g = 255;
    if (b > 255) b = 255;
    if (a > 255) a = 255;
    return (r) | (g << 8) | (b << 16) | (a << 24);
}


/* one triangle, clipped to the scissor rectangle */
static void tri(const ImDrawVert* a, const ImDrawVert* b, const ImDrawVert* c,
                unsigned int* fb, int w, int h,
                const unsigned char* atlas, int aw, int ah,
                int cx0, int cy0, int cx1, int cy1)
{
    float area = (b->pos.x - a->pos.x) * (c->pos.y - a->pos.y) -
                 (c->pos.x - a->pos.x) * (b->pos.y - a->pos.y);
    if (area > -0.0001f && area < 0.0001f) return;      /* degenerate */
    float inv = 1.0f / area;

    int minX = (int)floorf(fminf(a->pos.x, fminf(b->pos.x, c->pos.x)));
    int maxX = (int)ceilf (fmaxf(a->pos.x, fmaxf(b->pos.x, c->pos.x)));
    int minY = (int)floorf(fminf(a->pos.y, fminf(b->pos.y, c->pos.y)));
    int maxY = (int)ceilf (fmaxf(a->pos.y, fmaxf(b->pos.y, c->pos.y)));

    if (minX < cx0) minX = cx0;
    if (minY < cy0) minY = cy0;
    if (maxX > cx1) maxX = cx1;
    if (maxY > cy1) maxY = cy1;
    if (minX < 0) minX = 0;
    if (minY < 0) minY = 0;
    if (maxX > w) maxX = w;
    if (maxY > h) maxY = h;

    for (int y = minY; y < maxY; y++) {
        float py = (float)y + 0.5f;
        for (int x = minX; x < maxX; x++) {
            float px = (float)x + 0.5f;

            /* barycentric weights */
            float w0 = ((b->pos.x - px) * (c->pos.y - py) -
                        (c->pos.x - px) * (b->pos.y - py)) * inv;
            float w1 = ((c->pos.x - px) * (a->pos.y - py) -
                        (a->pos.x - px) * (c->pos.y - py)) * inv;
            float w2 = 1.0f - w0 - w1;
            if (w0 < 0.0f || w1 < 0.0f || w2 < 0.0f) continue;

            float u = a->uv.x * w0 + b->uv.x * w1 + c->uv.x * w2;
            float v = a->uv.y * w0 + b->uv.y * w1 + c->uv.y * w2;

            /* vertex colour, interpolated then used as a float */
            float cr = (float)( a->col        & 0xFF) * w0 +
                       (float)( b->col        & 0xFF) * w1 +
                       (float)( c->col        & 0xFF) * w2;
            float cg = (float)((a->col >> 8)  & 0xFF) * w0 +
                       (float)((b->col >> 8)  & 0xFF) * w1 +
                       (float)((c->col >> 8)  & 0xFF) * w2;
            float cb = (float)((a->col >> 16) & 0xFF) * w0 +
                       (float)((b->col >> 16) & 0xFF) * w1 +
                       (float)((c->col >> 16) & 0xFF) * w2;
            float ca = (float)((a->col >> 24) & 0xFF) * w0 +
                       (float)((b->col >> 24) & 0xFF) * w1 +
                       (float)((c->col >> 24) & 0xFF) * w2;

            float tr = 1.0f, tg = 1.0f, tb = 1.0f, ta = 1.0f;
            if (atlas && aw > 0 && ah > 0) {
                /* nearest-neighbour: the atlas is drawn at roughly 1:1,
                 * and a sharp sample beats a blurry one for text */
                int tx = (int)(u * (float)aw);
                int ty = (int)(v * (float)ah);
                if (tx < 0) tx = 0; if (tx >= aw) tx = aw - 1;
                if (ty < 0) ty = 0; if (ty >= ah) ty = ah - 1;
                const unsigned char* p = atlas + ((size_t)ty * (size_t)aw + tx) * 4;
                tr = (float)p[0] / 255.0f;
                tg = (float)p[1] / 255.0f;
                tb = (float)p[2] / 255.0f;
                ta = (float)p[3] / 255.0f;
            }

            /* ImGui's shader: colour * texel */
            float sr = (cr / 255.0f) * tr;
            float sg = (cg / 255.0f) * tg;
            float sb = (cb / 255.0f) * tb;
            float sa = (ca / 255.0f) * ta;

            fb[(size_t)y * (size_t)w + x] = blend(fb[(size_t)y * (size_t)w + x],
                                                  sr, sg, sb, sa);
        }
    }
}

extern "C" void zlm_raster(const ImDrawData* dd, unsigned int* out,
                           int w, int h, const unsigned char* atlas,
                           int aw, int ah)
{
    if (!dd || !out) return;

    for (int n = 0; n < dd->CmdListsCount; n++) {
        const ImDrawList* cl = dd->CmdLists[n];

        for (int ci = 0; ci < cl->CmdBuffer.Size; ci++) {
            const ImDrawCmd* cmd = &cl->CmdBuffer[ci];
            if (cmd->UserCallback) continue;
            if (cmd->ElemCount == 0) continue;

            int cx0 = (int)cmd->ClipRect.x, cy0 = (int)cmd->ClipRect.y;
            int cx1 = (int)cmd->ClipRect.z, cy1 = (int)cmd->ClipRect.w;
            if (cx0 >= cx1 || cy0 >= cy1) continue;

            for (unsigned e = 0; e + 2 < cmd->ElemCount + 1; e += 3) {
                if (e + 2 >= cmd->ElemCount) break;
                const ImDrawVert* a =
                    &cl->VtxBuffer.Data[cmd->VtxOffset + cl->IdxBuffer.Data[cmd->IdxOffset + e + 0]];
                const ImDrawVert* b =
                    &cl->VtxBuffer.Data[cmd->VtxOffset + cl->IdxBuffer.Data[cmd->IdxOffset + e + 1]];
                const ImDrawVert* c =
                    &cl->VtxBuffer.Data[cmd->VtxOffset + cl->IdxBuffer.Data[cmd->IdxOffset + e + 2]];
                tri(a, b, c, out, w, h, atlas, aw, ah, cx0, cy0, cx1, cy1);
            }
        }
    }
}
