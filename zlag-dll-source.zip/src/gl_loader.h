/* =====================================================================
 *  gl_loader.h  --  minimal, lazy OpenGL 1.x..3.x symbol loader.
 *  We never link opengl32 (the proxy only forwards it) so everything we
 *  need is resolved with wglGetProcAddress / GetModuleHandle fallback.
 * ===================================================================== */
#ifndef ZLAG_GL_LOADER_H
#define ZLAG_GL_LOADER_H

#include <windows.h>

typedef unsigned int  GLenum;
typedef unsigned int  GLuint;
typedef unsigned int  GLbitfield;
typedef int           GLint;
typedef int           GLsizei;
typedef float         GLfloat;
typedef float         GLclampf;
typedef double        GLdouble;
typedef char          GLchar;
typedef char          GLboolean;
typedef unsigned char GLubyte;
typedef ptrdiff_t     GLsizeiptr;
typedef ptrdiff_t     GLintptr;
typedef void          GLvoid;
typedef void (APIENTRY* GLDEBUGPROCARB)(GLenum, GLenum, GLuint, GLenum, GLsizei, const GLchar*, const void*);

#ifndef APIENTRY
#define APIENTRY __stdcall
#endif

#define GL_FALSE 0
#define GL_TRUE  1

#define GL_TEXTURE_2D          0x0DE1
#define GL_TEXTURE0            0x84C0
#define GL_TEXTURE1            0x84C1
#define GL_TEXTURE2            0x84C2
#define GL_TEXTURE3            0x84C3
#define GL_TEXTURE_MIN_FILTER  0x2801
#define GL_TEXTURE_MAG_FILTER  0x2800
#define GL_TEXTURE_WRAP_S      0x2802
#define GL_TEXTURE_WRAP_T      0x2803
#define GL_LINEAR              0x2601
#define GL_NEAREST             0x2600
#define GL_CLAMP_TO_EDGE       0x812F
#define GL_RGBA                0x1908
#define GL_RGBA8               0x8058
#define GL_BGRA                0x80E1
#define GL_UNSIGNED_BYTE       0x1401
#define GL_FLOAT               0x1406
#define GL_TRIANGLES           0x0004
#define GL_TRIANGLE_STRIP      0x0005
#define GL_FRAMEBUFFER         0x8D40
#define GL_READ_FRAMEBUFFER    0x8CA8
#define GL_DRAW_FRAMEBUFFER    0x8CA9
#define GL_COLOR_ATTACHMENT0   0x8CE0
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_COLOR_BUFFER_BIT    0x00004000
#define GL_DEPTH_BUFFER_BIT    0x00000100
#define GL_STENCIL_BUFFER_BIT  0x00000400
#define GL_FRAMEBUFFER_BINDING 0x8CA6
#define GL_DRAW_FRAMEBUFFER_BINDING 0x8CA6
#define GL_READ_FRAMEBUFFER_BINDING 0x8CAA
#define GL_CURRENT_PROGRAM     0x8B8D
#define GL_ARRAY_BUFFER        0x8892
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#define GL_ARRAY_BUFFER_BINDING 0x8894
#define GL_PIXEL_UNPACK_BUFFER 0x88EC
#define GL_PIXEL_PACK_BUFFER   0x88EB
#define GL_STREAM_DRAW         0x88E0
#define GL_STATIC_DRAW         0x88E4
#define GL_VERTEX_SHADER       0x8B31
#define GL_FRAGMENT_SHADER     0x8B30
#define GL_COMPILE_STATUS      0x8B81
#define GL_LINK_STATUS         0x8B82
#define GL_INFO_LOG_LENGTH     0x8B84
#define GL_ACTIVE_UNIFORMS     0x8B86
#define GL_ACTIVE_ATTRIBUTES   0x8B89
#define GL_VENDOR              0x1F00
#define GL_RENDERER            0x1F01
#define GL_VERSION             0x1F02
#define GL_BLEND               0x0BE2
#define GL_SCISSOR_TEST        0x0C11
#define GL_SCISSOR_BOX         0x0C10
#define GL_DEPTH_TEST          0x0B71
#define GL_CULL_FACE           0x0B44
#define GL_STENCIL_TEST        0x0B90
#define GL_TEXTURE_BINDING_2D  0x8069
#define GL_ACTIVE_TEXTURE      0x84E0
#define GL_BLEND_SRC           0x0BE1
#define GL_BLEND_DST           0x0BE0
#define GL_SRC_ALPHA           0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_ONE                 1
#define GL_ZERO                0
#define GL_MAX_TEXTURE_SIZE    0x0D33
#define GL_VIEWPORT            0x0BA2
#define GL_PACK_ALIGNMENT      0x0D05
#define GL_UNPACK_ALIGNMENT    0x0CF5
#define GL_UNSIGNED_SHORT      0x1403
#define GL_RGB                 0x1907
#define GL_LUMINANCE           0x1909
#define GL_COLOR_BUFFER_BIT_M  0x4000

/* fragment/vertex attribute type */
typedef struct ZGL {
    /* 1.1 (opengl32 / static) */
    const GLubyte* (APIENTRY* glGetString)(GLenum);
    void (APIENTRY* glGetIntegerv)(GLenum, GLint*);
    void (APIENTRY* glGetFloatv)(GLenum, GLfloat*);
    void (APIENTRY* glEnable)(GLenum);
    void (APIENTRY* glDisable)(GLenum);
    void (APIENTRY* glBlendFunc)(GLenum, GLenum);
    void (APIENTRY* glBlendFuncSeparate)(GLenum, GLenum, GLenum, GLenum);
    void (APIENTRY* glBlendEquationSeparate)(GLenum, GLenum);
    void (APIENTRY* glDepthFunc)(GLenum);
    void (APIENTRY* glDepthMask)(GLboolean);
    void (APIENTRY* glColorMask)(GLboolean, GLboolean, GLboolean, GLboolean);
    void (APIENTRY* glGetVertexAttribiv)(GLuint, GLenum, GLint*);
    void (APIENTRY* glViewport)(GLint, GLint, GLsizei, GLsizei);
    void (APIENTRY* glScissor)(GLint, GLint, GLsizei, GLsizei);
    void (APIENTRY* glClear)(GLbitfield);
    void (APIENTRY* glClearColor)(GLclampf, GLclampf, GLclampf, GLclampf);
    void (APIENTRY* glClearStencil)(GLint);
    void (APIENTRY* glGetBooleanv)(GLenum, GLboolean*);
    void (APIENTRY* glPixelStorei)(GLenum, GLint);
    void (APIENTRY* glReadPixels)(GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, void*);
    void (APIENTRY* glTexImage2D)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*);
    void (APIENTRY* glTexSubImage2D)(GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, const void*);
    void (APIENTRY* glCopyTexSubImage2D)(GLenum, GLint, GLint, GLint, GLint, GLint, GLsizei, GLsizei);
    void (APIENTRY* glTexParameteri)(GLenum, GLenum, GLint);
    void (APIENTRY* glTexParameterf)(GLenum, GLenum, GLfloat);
    void (APIENTRY* glBindTexture)(GLenum, GLuint);
    void (APIENTRY* glGenTextures)(GLsizei, GLuint*);
    void (APIENTRY* glDeleteTextures)(GLsizei, const GLuint*);
    void (APIENTRY* glGenBuffers)(GLsizei, GLuint*);
    void (APIENTRY* glDeleteBuffers)(GLsizei, const GLuint*);
    void (APIENTRY* glBindBuffer)(GLenum, GLuint);
    void (APIENTRY* glBufferData)(GLenum, GLsizeiptr, const void*, GLenum);
    void (APIENTRY* glBufferSubData)(GLenum, GLintptr, GLsizeiptr, const void*);
    void (APIENTRY* glActiveTexture)(GLenum);
    void (APIENTRY* glDrawArrays)(GLenum, GLint, GLsizei);
    void (APIENTRY* glDrawElements)(GLenum, GLsizei, GLenum, const void*);
    void (APIENTRY* glFlush)(void);
    void (APIENTRY* glFinish)(void);
    unsigned char (APIENTRY* glIsEnabled)(GLenum);
    unsigned (APIENTRY* glGetError)(void);

    /* 2.0+ core */
    GLuint (APIENTRY* glCreateShader)(GLenum);
    void   (APIENTRY* glShaderSource)(GLuint, GLsizei, const GLchar* const*, const GLint*);
    void   (APIENTRY* glCompileShader)(GLuint);
    void   (APIENTRY* glGetShaderiv)(GLuint, GLenum, GLint*);
    void   (APIENTRY* glGetShaderInfoLog)(GLuint, GLsizei, GLsizei*, GLchar*);
    void   (APIENTRY* glDeleteShader)(GLuint);
    GLuint (APIENTRY* glCreateProgram)(void);
    void   (APIENTRY* glAttachShader)(GLuint, GLuint);
    void   (APIENTRY* glLinkProgram)(GLuint);
    void   (APIENTRY* glGetProgramiv)(GLuint, GLenum, GLint*);
    void   (APIENTRY* glGetProgramInfoLog)(GLuint, GLsizei, GLsizei*, GLchar*);
    void   (APIENTRY* glUseProgram)(GLuint);
    void   (APIENTRY* glDeleteProgram)(GLuint);
    GLint  (APIENTRY* glGetUniformLocation)(GLuint, const GLchar*);
    void   (APIENTRY* glUniform1f)(GLint, GLfloat);
    void   (APIENTRY* glUniform2f)(GLint, GLfloat, GLfloat);
    void   (APIENTRY* glUniform3f)(GLint, GLfloat, GLfloat, GLfloat);
    void   (APIENTRY* glUniform4f)(GLint, GLfloat, GLfloat, GLfloat, GLfloat);
    void   (APIENTRY* glUniform1i)(GLint, GLint);
    GLint  (APIENTRY* glGetAttribLocation)(GLuint, const GLchar*);
    void   (APIENTRY* glBindAttribLocation)(GLuint, GLuint, const GLchar*);
    void   (APIENTRY* glVertexAttribPointer)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*);
    void   (APIENTRY* glEnableVertexAttribArray)(GLuint);
    void   (APIENTRY* glDisableVertexAttribArray)(GLuint);
    void   (APIENTRY* glGenVertexArrays)(GLsizei, GLuint*);
    void   (APIENTRY* glDeleteVertexArrays)(GLsizei, const GLuint*);
    void   (APIENTRY* glBindVertexArray)(GLuint);
    void   (APIENTRY* glGenFramebuffers)(GLsizei, GLuint*);
    void   (APIENTRY* glDeleteFramebuffers)(GLsizei, const GLuint*);
    void   (APIENTRY* glBindFramebuffer)(GLenum, GLuint);
    void   (APIENTRY* glFramebufferTexture2D)(GLenum, GLenum, GLenum, GLuint, GLint);
    GLenum (APIENTRY* glCheckFramebufferStatus)(GLenum);
    void   (APIENTRY* glBlitFramebuffer)(GLint, GLint, GLint, GLint, GLint, GLint, GLint, GLint, GLbitfield, GLenum);

    /* optional debug output (3.2+) */
    void   (APIENTRY* glDebugMessageCallbackARB)(GLDEBUGPROCARB, const void*);

    int ok2;   /* core 2.0 group present */
    int ok3;   /* FBO group present */
    int ok31;  /* ARB debug present  */
} ZGL;

extern ZGL zgl;
int  zgl_load(void);
int  zgl_have(void);
int  zgl_lane(void);          /* 0 = WGL, 1 = EGL/ANGLE */
void* gl_resolve(const char* name);   /* lane-correct symbol lookup */
void zgl_reload(void);

#endif /* ZLAG_GL_LOADER_H */
