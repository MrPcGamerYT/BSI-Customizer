/* =====================================================================
 *  overlay_ui.cpp  --  the panel itself.
 *
 *  ImGui 1.90 + OpenGL2 backend, all drawn inside the host's GL context.
 *  Colors follow the BP9-ish dark theme so it does not look foreign
 *  inside BlueStacks.
 * ===================================================================== */
#include "common.h"
#include "zlag_imgui.h"

#include "imgui.h"
#include "ui_es.h"
#include "menuwin.h"
/* ImGui backend lives in ui_es.cpp (GLES2/GL2 common subset). */


#include <stdio.h>
#include <stdarg.h>
#include <float.h>

ZLagInput g_in;

volatile LONG zl_pending_apply = 0;

/* ------------------------------------------------------------------ */
static bool   s_imguiInit = false;
static bool   s_helpInit = false;
static bool   s_showHelpOnce = true;
static char   s_toast[160] = {0};
static DWORD  s_toastUntil = 0;
static int    s_tab = 0;

/* panel geometry -- remembered between opens */
static float  s_posX = 120.0f, s_posY = 90.0f;
static int    s_bannerLeft = 0;     /* frames left on the "alive" marker */
static int    s_openFrames = 0;     /* frames since the panel was opened  */

/* optimizer results, filled by optimizer.c */
extern "C" void zl_apply_log_copy(char* out, size_t size);
extern volatile LONG g_applyRunning;

/* ------------------------------------------------------------------ */
static void ui_toast_impl(const char* text)
{
    lstrcpynA(s_toast, text ? text : "", sizeof(s_toast));
    s_toastUntil = GetTickCount() + 1700;
}

/* ------------------------------------------------------------------ */
static void feed_input(int lane)
{
    ImGuiIO& io = ImGui::GetIO();

    /* The event ring is the HOST's mouse and keyboard, in the host window's
     * client coordinates. The menu-window lane has its own HWND, its own
     * cursor position and its own button sampling -- draining the host's
     * ring into it overwrote the position with game-window coordinates, so
     * every click in the external window landed somewhere else and nothing
     * responded. Two surfaces, two input sources: never both. */
    if (lane == ZL_LANE_WINDOW) return;

    /* drain every event the window thread queued since the last frame */
    LONG tail = g_in.tail;
    LONG head = g_in.head;
    if (head - tail > ZL_IN_RING) tail = head - ZL_IN_RING;   /* overrun: skip */

    for (LONG i = tail; i < head; i++) {
        const ZLagEvent* e = &g_in.ring[i & (ZL_IN_RING - 1)];
        switch (e->type) {
        case ZL_EV_POS:   io.AddMousePosEvent((float)e->a, (float)e->b); break;
        case ZL_EV_BTN:   io.AddMouseButtonEvent((int)e->a, e->b != 0);  break;
        case ZL_EV_WHEEL: io.AddMouseWheelEvent(0.0f, (float)e->a);      break;
        case ZL_EV_CHAR:  io.AddInputCharacter((unsigned int)e->a);      break;
        case ZL_EV_KEY: {
            int vk = (int)e->a;
            ImGuiKey k = ImGuiKey_None;
            if (vk >= 'A' && vk <= 'Z')            k = (ImGuiKey)((int)ImGuiKey_A + (vk - 'A'));
            else if (vk >= '0' && vk <= '9')       k = (ImGuiKey)((int)ImGuiKey_0 + (vk - '0'));
            else if (vk == VK_BACK)                k = ImGuiKey_Backspace;
            else if (vk == VK_RETURN)              k = ImGuiKey_Enter;
            else if (vk == VK_TAB)                 k = ImGuiKey_Tab;
            else if (vk == VK_DELETE)              k = ImGuiKey_Delete;
            else if (vk == VK_ESCAPE)              k = ImGuiKey_Escape;
            else if (vk == VK_LEFT)                k = ImGuiKey_LeftArrow;
            else if (vk == VK_RIGHT)               k = ImGuiKey_RightArrow;
            else if (vk == VK_UP)                  k = ImGuiKey_UpArrow;
            else if (vk == VK_DOWN)                k = ImGuiKey_DownArrow;
            else if (vk == VK_HOME)                k = ImGuiKey_Home;
            else if (vk == VK_END)                 k = ImGuiKey_End;
            else if (vk == VK_SPACE)               k = ImGuiKey_Space;
            if (k != ImGuiKey_None) io.AddKeyEvent(k, e->b != 0);
            break;
        }
        default: break;
        }
    }
    InterlockedExchange(&g_in.tail, head);
}

/* ------------------------------------------------------------------ */
static void style_zlag(void)
{
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding    = 12.0f;
    s.ChildRounding     = 8.0f;
    s.FrameRounding     = 6.0f;
    s.PopupRounding     = 8.0f;
    s.ScrollbarRounding = 8.0f;
    s.GrabRounding      = 12.0f;
    /* tabs carry the rounding now that the panel has rounded corners of
     * its own; leaving these at 0 makes the tab strip look cut out of a
     * square panel */
    s.TabRounding       = 6.0f;
    s.WindowBorderSize  = 1.0f;
    s.FrameBorderSize   = 0.0f;
    s.WindowPadding     = ImVec2(16, 14);
    s.FramePadding      = ImVec2(11, 6);
    s.ItemSpacing       = ImVec2(9, 6);

    ImVec4* c = s.Colors;
    /* Neutral greys and a single blue accent: the reference UI is almost
     * monochrome, and colour is reserved for state (check = blue, active =
     * green). */
    /* Monochrome. Near-black surfaces, white as the only accent, hairline
     * borders at ~12% white. Colour is reserved for state (green live dot,
     * red error) and nothing else, which is what makes a dense panel read
     * as instrumentation instead of a toy. */
    const ImVec4 white = ImVec4(0.957f, 0.957f, 0.961f, 1.00f);

    c[ImGuiCol_WindowBg]        = ImVec4(0.035f, 0.039f, 0.059f, 1.000f);  /* #090a0f */
    c[ImGuiCol_ChildBg]         = ImVec4(0.086f, 0.094f, 0.122f, 0.900f);  /* #16181f */
    c[ImGuiCol_PopupBg]         = ImVec4(0.067f, 0.075f, 0.094f, 0.98f);
    c[ImGuiCol_Border]          = ImVec4(1.000f, 1.000f, 1.000f, 0.120f);
    c[ImGuiCol_BorderShadow]    = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_FrameBg]         = ImVec4(0.137f, 0.145f, 0.165f, 1.000f);
    c[ImGuiCol_FrameBgHovered]  = ImVec4(0.169f, 0.176f, 0.196f, 1.000f);
    c[ImGuiCol_FrameBgActive]   = ImVec4(0.200f, 0.208f, 0.227f, 1.000f);
    c[ImGuiCol_TitleBg]         = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_TitleBgActive]   = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_SliderGrab]      = white;
    c[ImGuiCol_SliderGrabActive]= white;
    c[ImGuiCol_CheckMark]       = white;
    c[ImGuiCol_Button]          = ImVec4(1.000f, 1.000f, 1.000f, 0.060f);
    c[ImGuiCol_ButtonHovered]   = ImVec4(1.000f, 1.000f, 1.000f, 0.130f);
    c[ImGuiCol_ButtonActive]    = ImVec4(1.000f, 1.000f, 1.000f, 0.200f);
    c[ImGuiCol_Header]          = ImVec4(1.000f, 1.000f, 1.000f, 0.080f);
    c[ImGuiCol_HeaderHovered]   = ImVec4(1.000f, 1.000f, 1.000f, 0.120f);
    c[ImGuiCol_HeaderActive]    = ImVec4(1.000f, 1.000f, 1.000f, 0.160f);
    c[ImGuiCol_Tab]             = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_TabHovered]      = ImVec4(1.000f, 1.000f, 1.000f, 0.080f);
    c[ImGuiCol_TabSelected]     = ImVec4(1.000f, 1.000f, 1.000f, 0.120f);
    c[ImGuiCol_Text]            = ImVec4(0.957f, 0.957f, 0.961f, 1.000f);
    c[ImGuiCol_TextDisabled]    = ImVec4(0.443f, 0.443f, 0.478f, 1.000f);  /* #71717a */
    c[ImGuiCol_Separator]       = ImVec4(1.000f, 1.000f, 1.000f, 0.090f);
    c[ImGuiCol_ScrollbarBg]     = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_ScrollbarGrab]   = ImVec4(1.000f, 1.000f, 1.000f, 0.120f);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(1.000f, 1.000f, 1.000f, 0.200f);
    c[ImGuiCol_ScrollbarGrabActive]  = ImVec4(1.000f, 1.000f, 1.000f, 0.300f);
}

/* small helpers ----------------------------------------------------- */

/* Keep fixed controls on the same row only when they fit the panel. */
static void same_line_if_fit(float width, float gap = 8.0f)
{
    float right = ImGui::GetWindowPos().x + ImGui::GetWindowWidth()
                  - ImGui::GetStyle().WindowPadding.x - ImGui::GetStyle().ScrollbarSize;
    if (ImGui::GetItemRectMax().x + gap + width <= right)
        ImGui::SameLine(0.0f, gap);
}

/* An explanatory label may move below its button and wrap on smaller screens. */
static void inline_disabled(const char* fmt, ...)
{
    char text[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(text, sizeof(text), fmt, ap);
    va_end(ap);
    text[sizeof(text) - 1] = 0;
    same_line_if_fit(ImGui::CalcTextSize(text).x);
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled));
    ImGui::TextWrapped("%s", text);
    ImGui::PopStyleColor();
}

/* A cut-corner plate, the shape every game panel is built from: two
 * opposite corners are sliced, which reads as "engine UI" rather than
 * "desktop dialog". Filled flat with a bright edge, because HUD text has
 * to win against the art behind it. */
static void plate(ImDrawList* d, ImVec2 a, ImVec2 b, float cut,
                  ImU32 fill, ImU32 edge, float thick)
{
    ImVec2 p[6];
    p[0] = ImVec2(a.x + cut, a.y);
    p[1] = ImVec2(b.x,       a.y);
    p[2] = ImVec2(b.x,       b.y - cut);
    p[3] = ImVec2(b.x - cut, b.y);
    p[4] = ImVec2(a.x,       b.y);
    p[5] = ImVec2(a.x,       a.y + cut);
    d->AddConvexPolyFilled(p, 6, fill);
    if (edge) d->AddPolyline(p, 6, edge, ImDrawFlags_Closed, thick);
}

static void upper(char* dst, size_t n, const char* src)
{
    size_t i = 0;
    for (; src[i] && i + 1 < n; i++) {
        char ch = src[i];
        dst[i] = (ch >= 'a' && ch <= 'z') ? (char)(ch - 32) : ch;
    }
    dst[i] = 0;
}
static void section(const char* label)
{
    /* White dot, upper-case label, hairline under it. No plates, no fills:
     * the separator does the grouping so the panel stays quiet. */
    char up[64];
    upper(up, sizeof(up), label);

    ImGui::Dummy(ImVec2(0, 9));
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* d = ImGui::GetWindowDrawList();
    float lh = ImGui::GetTextLineHeight();
    float tw = ImGui::CalcTextSize(up).x;

    d->AddCircleFilled(ImVec2(p.x + 3.0f, p.y + lh * 0.5f), 2.5f,
                       IM_COL32(255, 255, 255, 235), 12);
    ImGui::SetCursorScreenPos(ImVec2(p.x + 12.0f, p.y));
    ImGui::TextColored(ImVec4(0.94f, 0.94f, 0.95f, 1.0f), "%s", up);

    /* hairline, full width, fading out to the right */
    float w = ImGui::GetContentRegionAvail().x + 12.0f;
    d->AddRectFilledMultiColor(ImVec2(p.x + 12.0f, p.y + lh + 3.0f),
                               ImVec2(p.x + w, p.y + lh + 4.0f),
                               IM_COL32(255, 255, 255, 60), IM_COL32(255, 255, 255, 0),
                               IM_COL32(255, 255, 255, 0), IM_COL32(255, 255, 255, 60));
    ImGui::Dummy(ImVec2(0, 4));
    (void)tw;
}

/* Pill switch. The reference UI's whole interaction language is this one
 * control: a rounded track that fills white when on, with a thumb that
 * slides. Drawn by hand because ImGui's checkbox cannot be shaped. */
static bool zl_toggle(const char* id, bool* v)
{
    bool changed = false;
    ImGui::PushID(id);
    ImVec2 p = ImGui::GetCursorScreenPos();
    float w = 34.0f, h = 18.0f;
    ImGui::InvisibleButton("##tg", ImVec2(w, h));
    if (ImGui::IsItemClicked(0)) { *v = !*v; changed = true; }
    bool hov = ImGui::IsItemHovered();

    ImDrawList* d = ImGui::GetWindowDrawList();
    float cy = p.y + h * 0.5f;
    ImU32 track = *v ? IM_COL32(245, 245, 247, 255)
                     : (hov ? IM_COL32(58, 60, 68, 255) : IM_COL32(42, 44, 50, 255));
    d->AddRectFilled(ImVec2(p.x, cy - 7.0f), ImVec2(p.x + w, cy + 7.0f), track, 7.0f);
    d->AddRect(ImVec2(p.x, cy - 7.0f), ImVec2(p.x + w, cy + 7.0f),
               *v ? IM_COL32(255, 255, 255, 255) : IM_COL32(255, 255, 255, 40), 7.0f, 0, 1.2f);
    float tx = *v ? (p.x + w - 6.0f) : (p.x + 6.0f);
    d->AddCircleFilled(ImVec2(tx, cy), 5.2f,
                       *v ? IM_COL32(9, 10, 15, 255) : IM_COL32(140, 143, 152, 255), 20);
    if (*v)     /* glow when on */
        d->AddCircle(ImVec2(tx, cy), 7.0f, IM_COL32(255, 255, 255, 60), 20, 1.5f);

    ImGui::PopID();
    return changed;
}
static bool zl_check(const char* id, const char* label, bool* v)
{
    /* Native checkbox. The hand-drawn pill switch looked right but was an
     * InvisibleButton, and an InvisibleButton that does not receive the
     * press is a control that does nothing -- which is exactly the report.
     * A real widget owned by ImGui cannot miss a click. */
    (void)id;
    return ImGui::Checkbox(label, v);
}


/* ------------------------------------------------------------------ */
/*  zl_slider -- HUD-style slider                                      */
/*                                                                     */
/*  Hairline track, amber fill to the knob, glowing knob, value on the  */
/*  right. Sign-aware, so ranges that run 100 -> 0 draw correctly.      */
/* ------------------------------------------------------------------ */
static bool zl_slider(const char* id, float* v, float lo, float hi,
                      const char* fmt, float width, float neutral)
{
    /* Native slider. Same reason as the checkbox: it cannot miss a drag,
     * and ImGui already draws the grab, the track and the value. */
    bool changed;
    (void)neutral;
    {
        float avail = ImGui::GetContentRegionAvail().x;
        if (avail > 0.0f && width > avail) width = avail;
    }
    ImGui::SetNextItemWidth(width);
    ImGui::PushStyleColor(ImGuiCol_SliderGrab,       ImVec4(0.957f, 0.957f, 0.961f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, ImVec4(1.000f, 1.000f, 1.000f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBg,          ImVec4(0.153f, 0.153f, 0.165f, 1.0f));
    changed = ImGui::SliderFloat(id, v, lo, hi, fmt);
    ImGui::PopStyleColor(3);
    if (ImGui::IsItemClicked(ImGuiMouseButton_Right)) { *v = neutral; changed = true; }
    return changed;
}


/* The hero button: chamfered amber plate, dark label, bright edge, glow on
 * hover. Used for the actions a player actually presses, so the panel has a
 * visual hierarchy instead of forty identical grey rectangles. */
static bool hero_button(const char* label, float w, float h)
{
    ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.941f, 0.941f, 0.949f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.000f, 1.000f, 1.000f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.800f, 0.800f, 0.812f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Text,          ImVec4(0.031f, 0.039f, 0.055f, 1.0f));
    bool r = ImGui::Button(label, ImVec2(w, h));
    ImGui::PopStyleColor(4);
    return r;
}

/* a slider that reports "neutral" state */
static bool fx_slider(const char* id, const char* label, float* v,
                      float lo, float hi, const char* fmt, const char* hint)
{
    bool ch = zl_slider(id, v, lo, hi, fmt, 300.0f, 0.0f);
    if (ImGui::IsItemHovered() && hint && *hint)
        ImGui::SetTooltip("%s\nright-click resets", hint);
    ImGui::SameLine(0, 8);
    bool neutral = (fmt[0] == '%' && *v > -0.0005f && *v < 0.0005f);
    ImGui::TextColored(neutral ? ImVec4(0.42f, 0.45f, 0.51f, 1.0f)
                               : ImVec4(0.42f, 0.87f, 0.55f, 1.0f),
                       "%s", label);
    return ch;
}

/* The number the panel shows, everywhere: measured rate times the display
 * multiplier. One function so the rail card, the status bar and the LIVE
 * row can never disagree. */

/* ------------------------------------------------------------------ */
/*  FPS test                                                           */
/*                                                                     */
/*  "Did it get faster?" is answerable without trusting anybody: count  */
/*  the frames the host actually presented over a fixed window, before  */
/*  and after a change. Two samples, no estimates, no smoothing.        */
/* ------------------------------------------------------------------ */
static DWORD s_benchT0      = 0;
static LONG  s_benchFrames0 = 0;
static float s_benchBase    = 0.0f;
static float s_benchNow     = 0.0f;
static int   s_benchRuns    = 0;

static int  s_benchAuto = 0;      /* boost-and-measure sequence running */

/* A measurement pass avoids changing the guest or its files. */
static void ingame_boost_apply(void)
{
    InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_TIMER | ZL_APPLY_PRIORITY));
    zl_ui_toast("basic tuning queued: priority and timer");
}

static void bench_tick(void)
{
    DWORD el;
    LONG  frames;
    if (!s_benchT0) return;
    el = GetTickCount() - s_benchT0;
    if (el < 5000) return;

    frames = g_state.lastSwaps - s_benchFrames0;
    if (frames > 0) {
        float fps = (float)frames * 1000.0f / (float)el;
        if (s_benchRuns == 0) {
            s_benchBase = fps;
            s_benchRuns = 1;
            if (s_benchAuto) {
                /* baseline in hand: apply the bundle, then measure again
                 * from this exact moment so the two windows are comparable */
                ingame_boost_apply();
                s_benchT0      = GetTickCount();
                s_benchFrames0 = g_state.lastSwaps;
                s_benchNow     = 0.0f;
                return;
            }
        } else {
            s_benchNow  = fps;
            s_benchRuns = 2;
            s_benchAuto = 0;
        }
    }
    s_benchT0 = 0;
}

static void bench_row(void)
{
    if (s_benchT0) {
        DWORD el = GetTickCount() - s_benchT0;
        int left = (int)(5000 - el); if (left < 0) left = 0;
        ImGui::TextColored(ImVec4(0.36f, 0.60f, 0.98f, 1.0f),
                           "sampling... %d.%d s left", left / 1000, (left % 1000) / 100);
    } else {
        if (ImGui::Button(s_benchRuns == 0 ? "Sample 5 s  (baseline)"
                                           : "Sample 5 s  (again)",
                          ImVec2(200, 0))) {
            s_benchT0      = GetTickCount();
            s_benchFrames0 = g_state.lastSwaps;
        }
        if (s_benchRuns >= 2 && s_benchBase > 0.0f) {
            ImGui::SameLine(0, 12);
            float d = (s_benchNow - s_benchBase) / s_benchBase * 100.0f;
            ImVec4 col = (d > 3.0f) ? ImVec4(0.42f, 0.87f, 0.55f, 1.0f)
                       : (d < -3.0f) ? ImVec4(0.95f, 0.45f, 0.42f, 1.0f)
                                     : ImVec4(0.72f, 0.72f, 0.75f, 1.0f);
            ImGui::TextColored(col, "%.1f -> %.1f fps  (%+.1f%%)",
                               s_benchBase, s_benchNow, d);
            if (d > -3.0f && d < 3.0f)
                ImGui::TextDisabled("within noise: whatever changed did not move the rate");
        }
        if (s_benchRuns > 0) {
            ImGui::SameLine(0, 12);
            if (ImGui::SmallButton("clear"))
                { s_benchRuns = 0; s_benchBase = s_benchNow = 0.0f; }
        }
    }
}


/* ------------------------------------------------------------------ */
/*  Visual booster                                                     */
/*                                                                     */
/*  The pairing that makes sense: push texture detail as far down as    */
/*  the sampler goes, then spend the cheapest possible GPU work putting */
/*  EDGES back on the final frame. Textures cost texture-cache          */
/*  bandwidth on every tap; a 5-tap sharpen costs almost nothing by     */
/*  comparison, and the eye reads "sharp" from edge contrast far more   */
/*  than from texture resolution.                                       */
/*                                                                     */
/*  What it cannot do: bring back detail that was never sampled. Grass, */
/*  cloth weave, small print on a crate -- gone at bias 16. Edges,       */
/*  silhouettes, HUD lines, text: restored, because those are a         */
/*  post-process away. So the image reads as crisp-but-plain, not as    */
/*  the original. That is the honest description of this preset.        */
/* ------------------------------------------------------------------ */
typedef struct { float litePct, liteBias, rcas, sres, shp; int liteOn, liteSuper, master; } BoosterBak;
static BoosterBak s_bak;
static int        s_bakOk = 0;

static int booster_on(void)
{
    return s_bakOk || (g_cfg.liteOn && g_cfg.liteSuper && g_cfg.liteBias >= 16.0f &&
                       g_cfg.rcas >= 0.5f && g_cfg.sres >= 0.5f);
}

static void booster_apply(int on)
{
    if (on) {
        if (!s_bakOk) {
            s_bak.litePct   = g_cfg.litePct;
            s_bak.liteBias  = g_cfg.liteBias;
            s_bak.liteOn    = g_cfg.liteOn;
            s_bak.liteSuper = g_cfg.liteSuper;
            s_bak.rcas      = g_cfg.rcas;
            s_bak.sres      = g_cfg.sres;
            s_bak.shp       = g_cfg.shp;
            s_bak.master    = g_cfg.masterOn;
            s_bakOk = 1;
        }
        g_cfg.liteOn    = 1;
        g_cfg.liteSuper = 1;      /* protection off: everything goes coarse */
        g_cfg.litePct   = 0.0f;
        g_cfg.liteBias  = 16.0f;  /* 8x box reduction for supported uploads */
        g_cfg.rcas      = 0.85f;  /* edge restore, the cheap half of FSR    */
        g_cfg.sres      = 0.80f;  /* edge-profile reconstruction            */
        g_cfg.shp       = 0.30f;  /* a little extra bite on silhouettes     */
        g_cfg.masterOn  = 1;      /* the reconstruction needs the pass on   */
        zl_lite_apply();
        zl_ui_toast("booster on: supported new textures reduced; sharpen enabled");
    } else if (s_bakOk) {
        g_cfg.litePct   = s_bak.litePct;
        g_cfg.liteBias  = s_bak.liteBias;
        g_cfg.liteOn    = s_bak.liteOn;
        g_cfg.liteSuper = s_bak.liteSuper;
        g_cfg.rcas      = s_bak.rcas;
        g_cfg.sres      = s_bak.sres;
        g_cfg.shp       = s_bak.shp;
        g_cfg.masterOn  = s_bak.master;
        s_bakOk = 0;
        zl_lite_apply();
        zl_ui_toast("booster off: settings restored; reload textures to restore detail");
    } else {
        /* A saved booster can outlive the in-memory backup across launches. */
        g_cfg.liteOn = 0; g_cfg.liteBias = 0.0f; g_cfg.litePct = 100.0f;
        g_cfg.liteSuper = 0; g_cfg.rcas = g_cfg.sres = g_cfg.shp = 0.0f;
        zl_lite_apply();
        zl_ui_toast("booster off: reload textures to restore detail");
    }
    zl_settings_save();
}

static int fps_shown(void)
{
    /* The measured rate, unmodified. There is no display multiplier any
     * more: a number the timer counted is the only number worth drawing. */
    return (int)g_state.fps;
}

/* ------------------------------------------------------------------ */
static void tab_performance(void)
{
    bench_tick();

    section("LIVE");
    /* The number on this row is what the frame timer counted. The 1.5x
     * display multiplier is gone: it was cosmetic, it invited doubt about
     * every other number in the panel, and the measured rate is the only
     * one worth drawing. */
    {
        ImGui::Text("FPS            %d", fps_shown());
    }
    ImGui::SameLine(190);
    ImGui::Text("frame  %d ms", (int)g_state.frameMs);
    ImGui::Text("frames drawn   %ld", (long)g_state.lastSwaps);
    ImGui::SameLine(190);
    ImGui::Text("pid %lu  tid %lu", (unsigned long)g_state.pid,
                (unsigned long)g_state.threadId);

    /* One press, the whole honest bundle. Everything here is a real
     * setting on this machine and every one of them is reversible; the
     * number in LIVE above is still whatever the frame timer counted. */
    if (hero_button("OPTIMIZE NOW", 220.0f, 34.0f)) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ALL_TUNING));
        zl_ui_toast("basic tuning queued: priority and timer");
    }
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("Requests above-normal priority and a 1 ms timer for this\n"
                          "session. No guest settings or files are changed.");
    /* Keep the 1.5x display option on its own row, below OPTIMIZE NOW. */
    {
        /* Explicitly opt-in, explicitly named. The real rate stays on the
         * LIVE row above, so the two can never be confused: this changes
         * the text BlueStacks prints, and nothing else. */
        int  pct = g_cfg.fpsMulPct ? g_cfg.fpsMulPct : 150;
        bool onx = (g_cfg.fpsMulPct > 0 && g_cfg.fpsMulPct != 100);
        if (zl_check("##fpsmul", "show x1.5 in the emulator's FPS text", &onx)) {
            g_cfg.fpsMulPct = onx ? pct : 0;
            zl_fpsmul_apply();
            zl_settings_save();
            zl_ui_toast(onx ? "display x1.5 on -- cosmetic, the real rate is unchanged"
                            : "display multiplier off");
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Rewrites the number BlueStacks prints after \"FPS\".\n"
                              "It adds no frames: the LIVE row in this panel is the\n"
                              "measured rate and is never multiplied.\n\n"
                              "Off by default, live toggle, no restart.");
        if (g_cfg.fpsMulPct > 0 && g_cfg.fpsMulPct != 100) {
            ImGui::SameLine(0, 12);
            ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f),
                               "cosmetic -- real %d fps", fps_shown());
        }
    }

    section("FRAME BUDGET");
    {
        /* The only CPU this product adds: the state snapshot around the
         * grading pass. If this number is small, the frame rate is the
         * emulator's problem and no amount of tuning here will fix it. */
        long us = (long)g_state.ovMicrosAvg;
        ImVec4 col = (us < 300)  ? ImVec4(0.42f, 0.87f, 0.55f, 1.0f)
                   : (us < 1200) ? ImVec4(0.95f, 0.72f, 0.30f, 1.0f)
                                 : ImVec4(0.95f, 0.45f, 0.42f, 1.0f);
        ImGui::TextColored(col, "overlay cost   %ld us/frame  (%.2f ms)",
                           us, (float)us / 1000.0f);
        ImGui::TextDisabled("frames we touched no GL state at all: %ld",
                            (long)g_state.skippedFrames);
        if (!g_cfg.masterOn)
            ImGui::TextDisabled("effects are OFF: that is the cheapest this "
                                "overlay can be");
    }

    section("IN GAME BOOST");
    {
        if (s_benchAuto) {
            ImGui::TextColored(ImVec4(0.36f, 0.60f, 0.98f, 1.0f),
                               "measuring: baseline, then boost, then again...");
        } else {
            if (hero_button("BOOST + MEASURE  (10 s)", 260, 34)) {
                s_benchAuto    = 1;
                s_benchRuns    = 0;
                s_benchBase    = s_benchNow = 0.0f;
                s_benchT0      = GetTickCount();
                s_benchFrames0 = g_state.lastSwaps;
            }
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip("Samples 5 s, applies basic host priority and timer,\n"
                                  "then samples 5 s again. No Android changes.");
            same_line_if_fit(120.0f, 10.0f);
            if (ImGui::SmallButton("undo animations"))
                InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANIM_ON));
            same_line_if_fit(85.0f, 6.0f);
            if (ImGui::SmallButton("vsync back")) {
                g_cfg.vsyncOff = 0;
                InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_VSYNC));
            }
        }
        if (s_benchRuns >= 2 && s_benchBase > 0.0f) {
            float d = (s_benchNow - s_benchBase) / s_benchBase * 100.0f;
            ImGui::TextColored(d > 3.0f ? ImVec4(0.42f, 0.87f, 0.55f, 1.0f)
                             : d < -3.0f ? ImVec4(0.95f, 0.45f, 0.42f, 1.0f)
                                         : ImVec4(0.72f, 0.72f, 0.75f, 1.0f),
                               "before %.1f  ->  after %.1f fps  (%+.1f%%)",
                               s_benchBase, s_benchNow, d);
            if (d > -3.0f && d < 3.0f)
                ImGui::TextDisabled("no real change: this host was already at its "
                                    "limit -- the guest renderer is the ceiling");
        }
    }

    section("FPS TEST");
    {
        bench_row();
        ImGui::TextDisabled("Sample, change one thing, sample again. Two real "
                            "measurements beat any claim I can make.");
        ImGui::TextDisabled("Biggest real levers, in order: guest resolution "
                            "(75%% = ~44%% less pixel work),");
        ImGui::TextDisabled("quality settings and the effects you enable. Effects cost is measured above.");
    }

    ImGui::Text("GL vendor      %s", g_state.glVendor);
    ImGui::Text("GL renderer    %s", g_state.glRenderer);

    section("WINDOW CORNERS");
    {
        /* Same trick as the source: a rounded region on the host window,
         * cleared while it is maximised. No window-procedure subclassing --
         * a WndProc that stops returning is a freeze, not a bug report. */
        int rad = g_cfg.roundRadius;
        float frad = (float)rad;
        if (zl_slider("##round", &frad, 0.0f, 30.0f, "%.0f px", 200.0f, 0.0f)) {
            g_cfg.roundRadius = (int)(frad + 0.5f);
            if (g_cfg.roundRadius > 0 && g_cfg.roundRadius < 4) g_cfg.roundRadius = 4;
            zl_settings_save_soon();
        }
        inline_disabled("emulator window  (0 = square, applied live)");
        if (g_cfg.roundRadius == 0) {
            same_line_if_fit(55.0f);
            if (ImGui::SmallButton("reset")) zl_round_reset();
        }
    }

    section("PRESENTATION");
    bool v = g_cfg.vsyncOff != 0;
    if (zl_check("##vsyncoff", "Force vsync off (uncap FPS)", &v)) {
        g_cfg.vsyncOff = v ? 1 : 0;
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_VSYNC));
        zl_ui_toast(v ? "vsync off -- applied now, no restart"
                      : "vsync restored -- applied now");
    }
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("Hooks wglSwapIntervalEXT / eglSwapInterval, and sets the\n"
                          "new interval on the live context the moment you tick it.\n"
                          "No restart, no reboot.");

    section("FPS CAP");
    {
        /* Left = uncapped (the emulator's own limit applies, and BlueStacks
         * has its own 60 fps setting), right = 240. A cap can only ever
         * hold the rate down; it is here so a heavy scene cannot spin a
         * laptop fan, not because it adds frames. */
        float cap = (float)g_cfg.fpsCap;
        if (zl_slider("##fpscap", &cap, 0.0f, 240.0f, "%.0f", 320.0f, 0.0f)) {
            int n = (int)(cap + 0.5f);
            if (n < 2) n = 0;                     /* 0 or 1 means "no cap" */
            g_cfg.fpsCap = n;
            zl_settings_save_soon();
        }
        ImGui::SameLine(0, 8);
        if (g_cfg.fpsCap > 0)
            ImGui::TextColored(ImVec4(0.42f, 0.87f, 0.55f, 1.0f), "cap %d fps", g_cfg.fpsCap);
        else
            ImGui::TextDisabled("uncapped");
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("A cap never adds frames -- it only stops the\n"
                              "renderer from running faster than the screen.\n"
                              "Left end = let the emulator decide.");
    }

    section("HOST");
    ImGui::TextWrapped("binary   %s", g_state.exeName[0] ? g_state.exeName : "(unknown)");
    ImGui::TextWrapped("hooks    wgl=%s  egl=%s",
                       g_state.hookedWgl ? "on" : "off",
                       g_state.hookedEgl ? "on" : "off");
    if (ImGui::Button("Re-scan presentation hooks"))
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_RESETHOOKS));
}

/* ------------------------------------------------------------------ */
static void tab_visuals(void)
{
    section("VISUAL BOOSTER");
    {
        bool on = booster_on() != 0;
        if (hero_button(on ? "BOOSTER: ON  (click to undo)" : "VISUAL BOOSTER", 260, 34)) {
            booster_apply(!on);
        }
        ImGui::TextWrapped("Reduces supported new texture uploads and adds sharpening. "
                           "Turning it off restores settings; reload textures to restore detail.");
    }

    section("EDGE ENHANCEMENT");
    {
        bool on = g_cfg.sres > 0.001f;
        if (zl_check("##sreson", "Edge enhancement (sharpen only)", &on)) {
            g_cfg.sres = on ? 0.60f : 0.0f;
            zl_settings_save();
            zl_ui_toast(on ? "edge enhancement on" : "edge enhancement off");
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("A spatial sharpening filter on the current frame.\n"
                              "It does not increase rendering resolution or add detail.");
        if (on) {
            float v = g_cfg.sres;
            if (zl_slider("##sres", &v, 0.05f, 1.0f, "%.2f", 260.0f, 0.60f)) {
                g_cfg.sres = v;
                zl_settings_save_soon();
            }
            inline_disabled("strength");
        }
    }

    section("LITE GRAPHICS");
    {
        bool on = g_cfg.liteOn != 0;
        if (zl_check("##liteon", "Lite graphics (coarser supported textures)", &on)) {
            g_cfg.liteOn = on ? 1 : 0;
            if (on && g_cfg.liteBias < 3.0f) g_cfg.liteBias = 3.0f;
            zl_lite_apply();
            zl_settings_save();
            zl_ui_toast(on ? "lite on: affects supported new uploads"
                           : "lite off: reload textures to restore detail");
        }
        ImGui::TextWrapped("Box-averages supported uploads, not nearest-neighbor pixelation. "
                           "Already-loaded textures may need a scene reload to change or restore.");
        if (on) {
            float bias = g_cfg.liteBias;
            int level = bias >= 16.0f ? 3 : (bias >= 8.0f ? 2 : (bias >= 3.0f ? 1 : 0));
            static const float biases[] = {0.0f, 3.0f, 8.0f, 16.0f};
            static const char* levels[] = {"no reduction", "2x reduction", "4x reduction", "8x reduction"};
            ImGui::Text("Texture reduction: %s", levels[level]);
            ImGui::SetNextItemWidth(260.0f);
            if (ImGui::SliderInt("##potato-level", &level, 0, 3, "level %d / 3")) {
                g_cfg.liteBias = biases[level];
                if (level == 0) g_cfg.litePct = 100.0f;
                zl_lite_apply();
                zl_settings_save_soon();
            }
            ImGui::TextDisabled("Applies on the next supported texture upload.");
            ImGui::TextDisabled("GL: %ld uploads, %ld resized", (long)zl_lite_uploads,
                                (long)zl_lite_scaled);
            ImGui::TextDisabled("D3D11: %ld textures, %ld resized", (long)zl_d3d_seen,
                                (long)zl_d3d_scaled);
            ImGui::TextDisabled("Renderer: %s", zl_backend_name());
            ImGui::TextWrapped("Compressed textures, Vulkan and D3D12 are not supported.");

            bool all = g_cfg.liteSuper != 0;
            if (zl_check("##superman", "Ignore texture-size protection", &all)) {
                g_cfg.liteSuper = all ? 1 : 0;
                zl_lite_apply();
                zl_settings_save();
            }
            if (!all) {
                static const int opts[4] = {0, 512, 1024, 2048};
                static const char* names[4] = {"protect none", "protect 512px and up",
                                                "protect 1024px and up", "protect 2048px and up"};
                int cur = 0;
                for (int i = 0; i < 4; i++) if (opts[i] == g_cfg.liteProtect) cur = i;
                ImGui::SetNextItemWidth(260.0f);
                if (ImGui::Combo("##protect", &cur, names, 4)) {
                    g_cfg.liteProtect = opts[cur];
                    zl_lite_apply();
                    zl_settings_save();
                }
            }
        }
    }

    section("CONTRAST-ADAPTIVE SHARPEN");
    {
        float v = g_cfg.rcas;
        if (zl_slider("##rcas", &v, 0.0f, 1.0f, "%.2f", 320.0f, 0.0f)) {
            g_cfg.rcas = v;
            zl_settings_save_soon();
        }
        inline_disabled("spatial sharpening");
        ImGui::TextWrapped("Post-processing only; not DLSS or full FSR and does not upscale the game.");
    }

    section("IMAGE");
    bool any = false;
    any |= fx_slider("##sat",  "saturation", &g_cfg.sat,  -1.0f, 1.0f, "%.2f", "0 = untouched. Negative desaturates, +1 doubles colour.");
    any |= fx_slider("##con",  "contrast",   &g_cfg.con,  -1.0f, 1.0f, "%.2f", "Pivot-locked at 0.5 grey.");
    any |= fx_slider("##shp",  "sharpen",    &g_cfg.shp,  -1.0f, 1.0f, "%.2f", "Unsharp on a 1-texel cross, clamped to +-0.08.");
    any |= fx_slider("##warm", "warmth",     &g_cfg.warm, -1.0f, 1.0f, "%.2f", "Red up / blue down. Neutral at 0.");
    any |= fx_slider("##hdr",  "hdr pop",    &g_cfg.hdr,  -1.0f, 1.0f, "%.2f", "S-curve pivoted at 0.35 luma; shadows dip, highlights rise.");
    any |= fx_slider("##lift", "shadow lift",&g_cfg.lift,  0.0f, 1.0f, "%.2f", "Gamma on the toe only.");
    any |= fx_slider("##amb",  "ambient",    &g_cfg.amb,   0.0f, 1.0f, "%.2f", "Moon-blue floor weighted to (1-luma)^2.");
    any |= fx_slider("##vig",  "vignette",   &g_cfg.vig,   0.0f, 1.0f, "%.2f", "Darkens the corners, 0.36-0.82 radius.");

    section("BLOOM");
    any |= fx_slider("##blm",  "bloom",      &g_cfg.blm,   0.0f, 1.0f, "%.2f", "Bright-pass 0.34 then two half-res gaussian taps.");

    section("MOTION");
    any |= fx_slider("##mblur","motion blur", &g_cfg.mblur, 0.0f, 1.0f, "%.2f", "Camera-locked smear driven by the flow estimator.");
    any |= fx_slider("##flow", "flow gain",   &g_cfg.flow,  0.0f, 1.0f, "%.2f", "How much confidence the estimator needs.\n1.0 = trust it fully.");
    any |= fx_slider("##fxaa", "aa / fxaa",  &g_cfg.fxaa,  0.0f, 1.0f, "%.2f", "FXAA-3.11 style directional blend, 0.84 bite.");

    (void)any;
    ImGui::Dummy(ImVec2(0, 6));
    if (ImGui::Button("Reset image to neutral", ImVec2(200, 0))) {
        g_cfg.sat = g_cfg.con = g_cfg.shp = 0; g_cfg.warm = g_cfg.hdr = 0;
        g_cfg.lift = g_cfg.blm = g_cfg.amb = g_cfg.vig = 0;
        g_cfg.mblur = 0; g_cfg.fxaa = 0; g_cfg.flow = 1.0f;
        zl_ui_toast("image reset -- frame is bit-exact again");
    }
    inline_disabled("(right-click any slider = zero)");
}

/* ------------------------------------------------------------------ */
static void tab_presets(void)
{
    section("ONE-CLICK LOOKS");
    int n = zl_preset_count();
    for (int i = 0; i < n; i++) {
        const ZLagPreset* p = zl_preset_get(i);
        if (!p) break;
        ImGui::PushID(i);
        if (ImGui::Button(p->name, ImVec2(180, 0))) {
            zl_apply_preset(i);
            char t[96];
            _snprintf(t, sizeof(t), "preset applied: %s", p->name);
            zl_ui_toast(t);
        }
        ImGui::SameLine(200);
        ImGui::TextDisabled("%s", p->blurb ? p->blurb : "");
        ImGui::PopID();
    }
    ImGui::Dummy(ImVec2(0, 6));
    ImGui::TextWrapped("Presets only move the sliders -- nothing is written to "
                       "the game or the emulator config.");
}


/* The result panes show the tail of the action log. Command echoes
 * (indented four spaces) are useful in the Log tab and noise in a status
 * box, so they are filtered out here -- the outcome lines are what the
 * button is being judged on. */
static const char* ui_safe_log_line(const char* input)
{
    if (!input) return "";
    char lower[1024];
    size_t i = 0;
    for (; input[i] && i + 1 < sizeof(lower); ++i) {
        char c = input[i];
        lower[i] = c >= 'A' && c <= 'Z' ? (char)(c + ('a' - 'A')) : c;
    }
    lower[i] = 0;
    const char* blocked[] = {"init.sh", "build.prop", "/data/", "/vendor/",
                             "/system/", "/proc/", "/sys/", "/dev/", "/sdcard/",
                             ":/", "\\", NULL};
    for (int j = 0; blocked[j]; ++j)
        if (strstr(lower, blocked[j])) return "[i] internal detail hidden";
    return input;
}

static void draw_result_tail(const char* id, const char* text, float h, int maxLines)
{
    if (ImGui::BeginChild(id, ImVec2(0, h), true)) {
        if (!text[0]) { ImGui::TextDisabled("(nothing run yet)"); ImGui::EndChild(); return; }
        /* collect the printable lines, then show the last N */
        const char* starts[64]; int lens[64]; int n = 0;
        const char* p = text;
        while (*p) {
            const char* e = strchr(p, '\n');
            int len = e ? (int)(e - p) : (int)strlen(p);
            if (len > 0 && !(len >= 4 && p[0] == ' ' && p[1] == ' ' && p[2] == ' ' && p[3] == ' ')) {
                if (n == 64) {
                    memmove(starts, starts + 1, 63 * sizeof(starts[0]));
                    memmove(lens, lens + 1, 63 * sizeof(lens[0]));
                    --n;
                }
                starts[n] = p; lens[n] = len; n++;
            }
            if (!e) break;
            p = e + 1;
        }
        int from = n > maxLines ? n - maxLines : 0;
        for (int i = from; i < n; i++) {
            char buf[256];
            int c = lens[i] < 255 ? lens[i] : 255;
            memcpy(buf, starts[i], c); buf[c] = 0;
            ImGui::TextUnformatted(ui_safe_log_line(buf));
        }
    }
    ImGui::EndChild();
}

/* ------------------------------------------------------------------ */
static void tab_optimize(void)
{

    section("LIVE STATUS");
    {
        /* Every knob in this panel takes effect while the emulator runs.
         * Exactly one needs the emulator to start again, and none needs the
         * machine to reboot -- said here so nobody goes looking for a
         * restart button that does not exist. */
        struct { const char* what; const char* when; } rows[] = {
            { "effects, sliders, RCAS",        "live" },
            { "lite graphics + protection",    "next texture upload" },
            { "FPS cap",                       "live" },
            { "vsync",                         "live (set on this context)" },
            { "priority / thread boost",       "live" },
            { "EcoQoS opt-out",                "live" },
            { "guest tweaks (adb)",            "live" },
            { "discrete GPU preference",       "emulator restart" },
        };
        unsigned k;
        for (k = 0; k < sizeof(rows) / sizeof(rows[0]); k++) {
            bool restart = strstr(rows[k].when, "restart") != NULL;
            ImGui::TextColored(restart ? ImVec4(0.95f, 0.72f, 0.30f, 1.0f)
                                       : ImVec4(0.42f, 0.87f, 0.55f, 1.0f),
                               "%-30s %s", rows[k].what, rows[k].when);
        }
        ImGui::TextDisabled("no PC reboot needed; removing older persistent overrides may "
                            "also require an emulator restart");
    }

    section("PROCESSOR / ADAPTER");
    {
        int pref = g_cfg.gpuPref ? zl_gpu_pref_get() : 0;
        bool wantGpu = g_cfg.gpuPref != 0;
        if (zl_check("##gpupref", "Prefer the discrete GPU", &wantGpu)) {
            if (zl_gpu_pref_set(wantGpu ? 1 : 0)) {
                g_cfg.gpuPref = wantGpu ? 1 : 0;
                zl_settings_save();
                zl_ui_toast(wantGpu ? "Windows will use the fast adapter on next start"
                                    : "GPU preference cleared");
            } else {
                zl_ui_toast("could not write the per-user GPU preference");
            }
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Writes the per-user Windows GPU preference for this\n"
                              "executable (HKCU, no admin). Takes effect when the\n"
                              "emulator next starts. On a hybrid laptop this moves\n"
                              "RENDERING from the integrated GPU to the real one.");
        if (g_cfg.gpuPref)
            ImGui::TextDisabled("registered: %s",
                                pref == 2 ? "high performance" : "not set yet");

        /* The one that is immediate, and the one people never try. */
        static bool noThrottle = false;
        if (zl_check("##ecqos", "Refuse Windows power throttling (EcoQoS)", &noThrottle)) {
            if (zl_gpu_nothrottle(noThrottle ? 1 : 0))
                zl_ui_toast(noThrottle ? "process opted out of EcoQoS"
                                       : "process back to default scheduling");
            else
                zl_ui_toast("SetProcessInformation unavailable on this Windows");
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Windows 11 caps the scheduling class of processes it\n"
                              "considers background work. This opts this process out.\n"
                              "Immediate, reversible, no restart.");

        ImGui::TextDisabled("renderer %s", g_state.glRenderer[0] ? g_state.glRenderer
                                                                : "(not reported)");
        ImGui::TextDisabled("vendor   %s", g_state.glVendor[0] ? g_state.glVendor
                                                              : "(not reported)");
        ImGui::TextColored(ImVec4(0.72f, 0.72f, 0.75f, 1.0f),
                           "no switch moves ARM translation onto the GPU: that is");
        ImGui::TextColored(ImVec4(0.72f, 0.72f, 0.75f, 1.0f),
                           "CPU work by the emulator's design. This moves rendering.");
    }
    /* Two buttons, plain names, no internals. Everything underneath still
     * exists for anyone who wants it item by item, but the page no longer
     * asks the user to know what a boot script or a property key is in
     * order to press the obvious thing. */
    section("ONE PRESS");
    if (hero_button("OPTIMIZE  TURBO", 215, 38)) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_TURBO));
        zl_ui_toast("basic host tuning queued");
    }
    same_line_if_fit(215.0f);
    if (hero_button("ALL IN ONE", 215, 38)) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ALLINONE));
        zl_ui_toast("basic tuning and read-only instance checks queued");
    }
    ImGui::TextDisabled("turbo = process priority and timer for this session");
    ImGui::TextDisabled("all in one = turbo + read-only checks; no guest changes");

    section("DISPLAY RESOLUTION");

    /* host display resolution */
    {
        static const int res[][2] = {
            {800,600},{1024,768},{1280,720},{1280,800},{1366,768},{1440,900},
            {1600,900},{1680,1050},{1920,1080},{1920,1200},{2560,1440},{3840,2160}
        };
        static int sel = 8;
        char cur[32];
        _snprintf(cur, sizeof(cur), "%dx%d", res[sel][0], res[sel][1]);
        ImGui::SetNextItemWidth(150);
        if (ImGui::BeginCombo("##hostres", cur)) {
            for (int i = 0; i < (int)(sizeof(res) / sizeof(res[0])); i++) {
                char t[32];
                _snprintf(t, sizeof(t), "%dx%d", res[i][0], res[i][1]);
                if (ImGui::Selectable(t, i == sel)) sel = i;
            }
            ImGui::EndCombo();
        }
        same_line_if_fit(80.0f);
        if (ImGui::Button("Apply", ImVec2(80, 0))) {
            zl_pick_res_w = res[sel][0];
            zl_pick_res_h = res[sel][1];
            InterlockedExchange((LONG*)&zl_android_cmd, 13);
            InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
            zl_ui_toast(cur);
        }
        same_line_if_fit(130.0f);
        if (ImGui::Button("Back to native", ImVec2(130, 0))) {
            InterlockedExchange((LONG*)&zl_android_cmd, 14);
            InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
            zl_ui_toast("going back to your Windows resolution");
        }
        same_line_if_fit(140.0f);
        if (ImGui::Button("Restart Explorer", ImVec2(140, 0))) {
            InterlockedExchange((LONG*)&zl_android_cmd, 15);
            InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
            zl_ui_toast("restarting Explorer");
        }
        ImGui::TextDisabled("this changes your Windows desktop mode, not the guest");
    }

    section("OPTIONAL WINDOWS TUNING");
    ImGui::TextWrapped("These actions run only when pressed. Priority and timer "
                       "are session-only; power, registry and GPU preferences "
                       "can persist and are separate choices.");

    ImGui::Dummy(ImVec2(0, 4));
    if (ImGui::Button("Boost power plan", ImVec2(220, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_POWER));
        zl_ui_toast("asking Windows for the ultimate performance plan");
    }
    inline_disabled("needs an admin BlueStacks; falls back to high perf");

    if (ImGui::Button("Apply gaming registry flags", ImVec2(220, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_REGS));
        zl_ui_toast("HKCU gaming flags written (GameDVR off, Game Mode on)");
    }
    inline_disabled("HKCU only -- no admin, no services touched");

    if (ImGui::Button("Emulator process priority", ImVec2(220, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_PRIORITY));
        zl_ui_toast("requesting above-normal process priority");
    }
    inline_disabled("above normal for this session");

    if (ImGui::Button("Trim working set", ImVec2(220, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_TRIM));
        zl_ui_toast("working set trimmed");
    }
    inline_disabled("EmptyWorkingSet on the emulator process");

    if (ImGui::Button("1 ms timer resolution", ImVec2(220, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_TIMER));
        zl_ui_toast("timer resolution raised to 1 ms");
    }
    inline_disabled("stops 15.6 ms scheduler batching -- frame pacing");

    if (ImGui::Button("High-performance GPU", ImVec2(220, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_GPUPREF));
        zl_ui_toast("this exe now asks for the discrete GPU");
    }
    inline_disabled("HKCU per-app GPU preference, no admin");

    ImGui::Dummy(ImVec2(0, 6));
    if (ImGui::Button("BASIC TUNING", ImVec2(220, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ALL_TUNING));
        zl_ui_toast("requesting priority and timer for this session");
    }
    inline_disabled("priority and timer only; no guest writes");

    /* Results, right here. The log tab had them all along, but a button
     * that reports nothing looks like a button that did nothing -- which
     * is exactly how this page was described. */
    ImGui::Dummy(ImVec2(0, 4));
    char applyLogSnapshot[4096];
    zl_apply_log_copy(applyLogSnapshot, sizeof(applyLogSnapshot));
    if (g_applyRunning)
        ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f), "running...");
    else if (applyLogSnapshot[0])
        ImGui::TextColored(ImVec4(0.61f, 0.94f, 0.31f, 1.0f), "last pass finished");
    draw_result_tail("##optres", applyLogSnapshot, 130, 8);

    section("ANDROID SPEED");
    ImGui::TextWrapped("Connect the selected instance in ADB first. Animation "
                       "tuning is cosmetic and saves the previous values.");
    if (ImGui::Button("Faster animations", ImVec2(170, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANIM_OFF));
        zl_ui_toast("applying gentle animation speed");
    }
    same_line_if_fit(210.0f);
    if (ImGui::Button("Restore animations", ImVec2(210, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANIM_ON));
        zl_ui_toast("restoring saved animation settings");
    }
    if (ImGui::Button("Close background apps", ImVec2(215, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_KILLBG));
        zl_ui_toast("requesting background apps to close");
    }
    inline_disabled("may interrupt background work");

    if (ImGui::Button("Inspect app in front", ImVec2(215, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_GAMEBOOST));
        zl_ui_toast("checking the foreground app");
    }
    inline_disabled("read-only; CPU and memory policy unchanged");

    if (ImGui::Button("Resume Play services", ImVec2(215, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_GMS_RESUME));
        zl_ui_toast("requesting services to resume");
    }
    inline_disabled("for recovery from older settings");

    if (ImGui::Button("GENTLE ANDROID TUNE", ImVec2(240, 30))) {
        InterlockedExchange((LONG*)&zl_android_cmd, 1);
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
        zl_ui_toast("applying gentle animation speed");
    }
    same_line_if_fit(200.0f);
    if (ImGui::Button("Remove startup profile", ImVec2(200, 30))) {
        InterlockedExchange((LONG*)&zl_android_cmd, 2);
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
        zl_ui_toast("removing the startup profile");
    }
    ImGui::TextWrapped("Older changes without a saved value may need separate recovery.");

    section("MORE FPS");
    ImGui::TextDisabled("guest resolution -- the biggest real lever, softer picture");
    struct { const char* label; int code; } resbtn[] = {
        { "100%", 5 }, { "85%", 6 }, { "75%", 7 }, { "60%", 8 }
    };
    for (int i = 0; i < 4; i++) {
        if (i) ImGui::SameLine();
        if (ImGui::Button(resbtn[i].label, ImVec2(70, 0))) {
            InterlockedExchange((LONG*)&zl_android_cmd, resbtn[i].code);
            InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
            char t[48];
            _snprintf(t, sizeof(t), "rendering at %s", resbtn[i].label);
            zl_ui_toast(t);
        }
    }
    inline_disabled("75%% is ~44%% less pixel work");

    if (ImGui::Button("Raise the drawing threads", ImVec2(215, 0))) {
        InterlockedExchange((LONG*)&zl_android_cmd, 9);
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
        zl_ui_toast("raising the emulator's own threads");
    }
    inline_disabled("scheduler priority inside HD-Player");

    if (ImGui::Button("Keep awake", ImVec2(110, 0))) {
        InterlockedExchange((LONG*)&zl_android_cmd, 10);
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
        zl_ui_toast("display and CPU stay awake");
    }
    ImGui::SameLine();
    if (ImGui::Button("Allow sleep", ImVec2(110, 0))) {
        InterlockedExchange((LONG*)&zl_android_cmd, 11);
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
        zl_ui_toast("normal sleep restored");
    }
    inline_disabled("stops the display powering down mid-match");

    section("FREE FIRE");
    if (g_ffPkg[0])
        ImGui::TextColored(ImVec4(0.61f, 0.94f, 0.31f, 1.0f), "game: %s", g_ffPkg);
    else
        ImGui::TextDisabled("game: not detected yet -- press Detect");
    if (ImGui::Button("Detect", ImVec2(90, 0))) {
        InterlockedExchange((LONG*)&zl_android_cmd, 3);
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
        zl_ui_toast("looking for the Free Fire package");
    }
    ImGui::SameLine();
    if (ImGui::Button("GAME + GENTLE ANIMATIONS", ImVec2(230, 0))) {
        InterlockedExchange((LONG*)&zl_android_cmd, 4);
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_ANDROID_CMD));
        zl_ui_toast("detecting the game and applying gentle animations");
    }
    inline_disabled("does not edit game files or CPU policy");
    ImGui::TextWrapped("Detects the installed game; animation changes are cosmetic, "
                       "not a game-specific FPS increase.");

    section("STARTUP");
    bool autoo = g_cfg.autoOpen != 0;
    if (zl_check("##autoopen", "Open panel when the emulator starts", &autoo)) {
        g_cfg.autoOpen = autoo ? 1 : 0;
        zl_settings_save();
        zl_ui_toast(autoo ? "panel will open at startup" : "panel stays closed at startup");
    }
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("The panel shows itself as soon as the emulator has\n"
                          "drawn its first frames. Turn this off to start minimised.");

    section("OPTIONAL ANDROID STARTUP");
    ImGui::TextWrapped("The safe profile changes UI animation speed only. It does "
                       "not force renderer, thermal, CPU, memory, network or service "
                       "settings. Automatic startup depends on instance support.");
    if (ImGui::Button("Install safe startup profile", ImVec2(240, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_INITSH));
        zl_ui_toast("installing the safe startup profile");
    }
    inline_disabled("optional; saves previous animation values");
    if (ImGui::Button("Run safe profile now", ImVec2(240, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_INITSH_RUN));
        zl_ui_toast("running the safe animation profile");
    }
    inline_disabled("no restart needed");
    if (ImGui::Button("Remove boot tweaks", ImVec2(240, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_INITSH_OFF));
        zl_ui_toast("removing the startup profile");
    }
    inline_disabled("restores saved animation values when available");
    if (ImGui::Button("Check startup profile", ImVec2(240, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_INITSH_CHECK));
        zl_ui_toast("checking the startup profile");
    }
    inline_disabled("read-only");

    section("OLDER PROPERTY OVERRIDES");
    ImGui::TextWrapped("New vendor and system overrides are disabled. Older marked "
                       "overrides can be checked or removed explicitly. Read-only "
                       "partitions are left untouched; no automatic remount is attempted.");
    if (ImGui::Button("Check older overrides", ImVec2(240, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_PROP_DIFF));
        zl_ui_toast("checking older overrides");
    }
    inline_disabled("read-only");
    if (ImGui::Button("Revert properties", ImVec2(240, 0))) {
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_PROP_REVERT));
        zl_ui_toast("checking and removing marked overrides");
    }
    inline_disabled("only if writable; a backup is kept");
    ImGui::TextWrapped("Older unsaved changes may remain. A successful cleanup may "
                       "need an emulator restart to take effect.");

    section("CLEANUP");
    if (hero_button("CLEAN OLD EMULATOR LOGS", 240.0f, 32.0f)) {
        InterlockedExchange((volatile LONG*)&zl_pending_tempclean, 1);
        InterlockedOr(&zl_pending_apply, (LONG)(ZL_APPLY_CLEAN_WAKE));
        zl_ui_toast("cleaning old emulator logs");
    }
    inline_disabled("only logs older than seven days");
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("Only old emulator log files are eligible.\n"
                          "Recent logs, guest data, Windows temp and saved\n"
                          "settings are not touched. Locked files are skipped.");

    section("STATUS");
    if (g_applyRunning) ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f), "running...");
    {
        DWORD lastTick = zl_last_apply_tick;
        if (!lastTick)
            ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f),
                               "no tuning pass has run yet -- press one of the buttons above");
        else
            ImGui::TextDisabled("last tuning pass: %lu s ago", (unsigned long)((GetTickCount() - lastTick) / 1000));
    }
    draw_result_tail("##applylog", applyLogSnapshot, 150, 12);
}

/* ------------------------------------------------------------------ */
/* ADB debloater: inspection first, then a separately confirmed change.
 * Preset user-0 removal is distinct from reversible manual disabling. */
static bool db_queue(LONG action, LONG presetCommand = 0)
{
    if (action == ZL_APPLY_DB_PRESET && presetCommand != 1 && presetCommand != 2) return false;
    if (InterlockedCompareExchange(&g_dbRunning, 1, 0) != 0) return false;
    if (action == ZL_APPLY_DB_PRESET) InterlockedExchange(&g_dbPresetCommand, presetCommand);
    InterlockedExchange(&g_dbDone, 0);
    InterlockedExchange(&g_dbTotal, 0);
    InterlockedExchange(&g_dbOk, 0);
    InterlockedExchange(&g_dbFail, 0);
    InterlockedOr(&zl_pending_apply, action);
    return true;
}

static bool contains_ascii_casefold(const char* text, const char* filter)
{
    if (!filter || !filter[0]) return true;
    for (; *text; ++text) {
        const char* a = text;
        const char* b = filter;
        while (*a && *b) {
            char x = (*a >= 'A' && *a <= 'Z') ? (char)(*a + ('a' - 'A')) : *a;
            char y = (*b >= 'A' && *b <= 'Z') ? (char)(*b + ('a' - 'A')) : *b;
            if (x != y) break;
            ++a; ++b;
        }
        if (!*b) return true;
    }
    return false;
}

static void tab_adb(void)
{
    section("ADB DEBLOATER");
    ImGui::TextWrapped("Scan this instance first, then choose manual disabling or "
                       "the separately confirmed requested-app removal below.");
    if (g_dbDevice[0])
        ImGui::TextColored(ImVec4(0.61f, 0.94f, 0.31f, 1.0f), "connected: %s", g_dbDevice);
    else
        ImGui::TextColored(ImVec4(1.0f, 0.62f, 0.30f, 1.0f), "not connected -- enter the instance ADB port");

    bool busy = g_dbRunning != 0;
    if (busy) ImGui::BeginDisabled();
    ImGui::TextDisabled("port");
    ImGui::SameLine();
    static char portBuf[8] = {0};
    static bool portInitialized = false;
    if (!portInitialized) {
        _snprintf(portBuf, sizeof(portBuf), "%d", g_cfg.adbPort > 0 ? g_cfg.adbPort : 5555);
        portInitialized = true;
    }
    ImGui::SetNextItemWidth(90);
    if (ImGui::InputText("##adbport", portBuf, sizeof(portBuf), ImGuiInputTextFlags_CharsDecimal)) {
        int v = atoi(portBuf);
        if (v > 0 && v <= 65535 && v != g_cfg.adbPort) {
            g_cfg.adbPort = v;
            g_dbDevice[0] = 0;
            zl_db_forget_scan();
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Connect")) {
        int v = atoi(portBuf);
        if (v < 1 || v > 65535) zl_ui_toast("enter a port from 1 to 65535");
        else {
            g_cfg.adbPort = v;
            zl_settings_save();
            if (db_queue(ZL_APPLY_DB_CONNECT)) zl_ui_toast("connecting to the selected instance");
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Disconnect")) {
        if (db_queue(ZL_APPLY_DB_DISCONNECT)) zl_ui_toast("requesting disconnect");
    }
    if (busy) ImGui::EndDisabled();
    ImGui::TextWrapped("Enable Android debugging in BlueStacks and use this instance's port. "
                       "Only a verified local instance is targeted.");

    if (g_dbRunning) {
        ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.30f, 1.0f),
                           "working: %ld / %ld   completed %ld   not completed %ld",
                           (long)g_dbDone, (long)g_dbTotal, (long)g_dbOk, (long)g_dbFail);
        if (g_dbTotal > 0)
            ImGui::ProgressBar((float)g_dbDone / (float)g_dbTotal, ImVec2(-1, 0));
    }

    section("APPS");
    busy = g_dbRunning != 0;
    const bool cannotConnectAction = busy || !g_dbDevice[0];
    if (cannotConnectAction) ImGui::BeginDisabled();
    if (ImGui::Button("Scan apps", ImVec2(160, 0))) {
        if (db_queue(ZL_APPLY_DB_CHECK)) zl_ui_toast("scanning apps; nothing is changed");
    }
    same_line_if_fit(185.0f);
    if (ImGui::Button("Restore my changes", ImVec2(185, 0))) {
        if (db_queue(ZL_APPLY_DB_RESTORE)) zl_ui_toast("restoring saved app states");
    }
    if (cannotConnectAction) ImGui::EndDisabled();
    ImGui::TextWrapped("Restore my changes reverses only saved manual disables, "
                       "not app removals.");

    section("REQUESTED APP REMOVAL");
    ImGui::TextColored(ImVec4(1.0f, 0.48f, 0.28f, 1.0f), "WARNING: includes launcher and core providers");
    ImGui::TextWrapped("Removing these apps for Android user 0 can break the home screen, "
                       "contacts, storage, or the instance. This is not the protected manual-disable list.");
    ImGui::TextWrapped("Android is asked to keep app data, but recovery is not guaranteed. "
                       "Android may delete a downloaded app's installed APK. "
                       "System-image files and download-folder files are NOT deleted by this build.");
    if (!g_dbChecked) {
        ImGui::TextDisabled("Scan apps to preview requested matches.");
    } else if (!g_dbRunning) {
        ImGui::Text("%d matched apps; %d of %d exact IDs present",
                    zl_db_requested_count(), zl_db_requested_exact_found(), zl_db_requested_total());
        if (!zl_db_scan_bound())
            ImGui::TextColored(ImVec4(1.0f, 0.55f, 0.30f, 1.0f),
                               "Instance identity changed or could not be bound; rescan before removal.");
        if (ImGui::CollapsingHeader("Review matched and unmatched targets")) {
            if (ImGui::BeginChild("##db-requested-preview", ImVec2(0, 205), true,
                                  ImGuiWindowFlags_HorizontalScrollbar)) {
                ImGui::TextDisabled("Packages to be removed for user 0:");
                for (int i = 0, n = zl_db_app_count(); i < n; ++i)
                    if (zl_db_app_requested(i)) ImGui::BulletText("%s", zl_db_app_name(i));
                if (!zl_db_requested_count()) ImGui::TextDisabled("No matching packages.");
                ImGui::Separator();
                ImGui::TextDisabled("Exact requested IDs not found:");
                int missing = zl_db_requested_total() - zl_db_requested_exact_found();
                if (!missing) ImGui::TextDisabled("None.");
                for (int i = 0; i < missing; ++i) ImGui::BulletText("%s", zl_db_requested_missing(i));
                ImGui::Separator();
                ImGui::TextDisabled("Requested system-folder matches:");
                if (!zl_db_folders_checked()) ImGui::TextDisabled("Folder matches could not be verified.");
                else for (int i = 0; i < 8; ++i)
                    ImGui::BulletText("%s: %s", zl_db_folder_name(i), zl_db_folder_found(i) ? "matched" : "unmatched");
            }
            ImGui::EndChild();
        }
    }
    static bool confirmRemoveBackup = false;
    static bool confirmRemoveRisk = false;
    bool presetReady = !g_dbRunning && g_dbDevice[0] && g_dbChecked &&
                       zl_db_scan_bound() && zl_db_requested_count() > 0;
    if (!presetReady) { confirmRemoveBackup = false; confirmRemoveRisk = false; }
    if (!presetReady) ImGui::BeginDisabled();
    ImGui::Checkbox("I have a restorable backup of this instance", &confirmRemoveBackup);
    ImGui::Checkbox("I accept that core apps may stop working and recovery may fail", &confirmRemoveRisk);
    bool cannotRemove = !presetReady || !confirmRemoveBackup || !confirmRemoveRisk;
    if (cannotRemove) ImGui::BeginDisabled();
    if (ImGui::Button("Remove matched requested apps", ImVec2(260, 0))) {
        if (db_queue(ZL_APPLY_DB_PRESET, 1)) {
            confirmRemoveBackup = confirmRemoveRisk = false;
            zl_ui_toast("removing matched packages for this instance's user 0");
        }
    }
    if (cannotRemove) ImGui::EndDisabled();
    if (!presetReady) ImGui::EndDisabled();

    ImGui::TextWrapped("Recovery below only tries to reinstall previously removed packages "
                       "still available to Android. It is not a backup or guaranteed undo.");
    bool cannotRecover = g_dbRunning || !g_dbDevice[0];
    if (cannotRecover) ImGui::BeginDisabled();
    if (ImGui::Button("Try to recover removed apps", ImVec2(260, 0))) {
        if (db_queue(ZL_APPLY_DB_PRESET, 2)) zl_ui_toast("trying to recover saved removals");
    }
    if (cannotRecover) ImGui::EndDisabled();

    section("MANUAL DISABLE (SEPARATE)");
    if (g_dbChecked && !g_dbRunning) {
        static char filter[80] = {0};
        ImGui::SetNextItemWidth(240);
        ImGui::InputTextWithHint("##dbfilter", "Search package name", filter, sizeof(filter));
        same_line_if_fit(115.0f);
        if (ImGui::Button("Clear selection")) zl_db_clear_selection();
        ImGui::Text("%ld apps found; %d selected (up to 10 per pass)",
                    (long)g_dbPresent, zl_db_selected_count());
        if (ImGui::BeginChild("##dblist", ImVec2(0, 210), true,
                              ImGuiWindowFlags_HorizontalScrollbar)) {
            int shown = 0;
            for (int i = 0, n = zl_db_app_count(); i < n; ++i) {
                const char* name = zl_db_app_name(i);
                if (!contains_ascii_casefold(name, filter)) continue;
                ++shown;
                const bool protectedApp = zl_db_app_protected(i) != 0;
                const bool enabled = zl_db_app_state(i) == 1;
                const bool unavailable = protectedApp || !enabled;
                bool selected = zl_db_app_selected(i) != 0;
                ImGui::PushID(i);
                if (unavailable) ImGui::BeginDisabled();
                if (ImGui::Checkbox(name, &selected) && !zl_db_select_app(i, selected ? 1 : 0))
                    zl_ui_toast("choose up to 10 eligible apps per pass");
                if (unavailable) ImGui::EndDisabled();
                if (protectedApp || !enabled) {
                    ImGui::SameLine();
                    ImGui::TextDisabled(protectedApp ? "(protected for manual disable)" : "(already disabled)");
                }
                ImGui::PopID();
            }
            if (!shown) ImGui::TextDisabled("No matching apps.");
        }
        ImGui::EndChild();
        ImGui::TextWrapped("Some core packages are protected from manual disabling. "
                           "The requested removal above is separate and may include them.");
        static bool confirmDisable = false;
        ImGui::Checkbox("I understand the selected apps will stop working", &confirmDisable);
        const bool cannotDisable = !confirmDisable || !zl_db_selected_count() || !zl_db_scan_bound();
        if (cannotDisable) ImGui::BeginDisabled();
        if (ImGui::Button("Disable selected", ImVec2(185, 0))) {
            if (db_queue(ZL_APPLY_DB_DISABLE)) {
                confirmDisable = false;
                zl_ui_toast("checking and disabling the selected apps");
            }
        }
        if (cannotDisable) ImGui::EndDisabled();
    }

    if (ImGui::CollapsingHeader("Recovery from older versions")) {
        ImGui::TextWrapped("This older recovery attempts to reinstall and re-enable listed apps. "
                           "It cannot recover deleted data and may enable apps you disabled yourself.");
        static bool confirmLegacy = false;
        ImGui::Checkbox("I understand the legacy recovery", &confirmLegacy);
        bool cannot = g_dbRunning || !g_dbDevice[0] || !confirmLegacy;
        if (cannot) ImGui::BeginDisabled();
        if (ImGui::Button("Recover older listed apps", ImVec2(230, 0))) {
            if (db_queue(ZL_APPLY_DB_REMOVE)) {
                confirmLegacy = false;
                zl_ui_toast("requesting legacy app recovery");
            }
        }
        if (cannot) ImGui::EndDisabled();
    }
    section("RESULTS");
    char applyLogSnapshot[4096];
    zl_apply_log_copy(applyLogSnapshot, sizeof(applyLogSnapshot));
    draw_result_tail("##dbout", applyLogSnapshot, 170, 10);
    ImGui::TextDisabled("Results also appear in the event log.");
}

/* ------------------------------------------------------------------ */
static void tab_log(void)
{
    section("EVENT LOG");
    ImGui::TextDisabled("Recent session events");
    ImGui::BeginChild("##logscroll", ImVec2(0, 300), true);
    int n = zl_log_ring_count();
    for (int i = n - 1; i >= 0; i--) {
        const char* l = zl_log_ring_get(n - 1 - i);
        ImVec4 col(0.82f, 0.84f, 0.88f, 1.0f);
        if (l[0] == '[') {
            if (l[2] == '+') col = ImVec4(0.42f, 0.87f, 0.55f, 1.0f);
            if (l[2] == '!') col = ImVec4(1.00f, 0.78f, 0.30f, 1.0f);
            if (l[2] == 'x') col = ImVec4(1.00f, 0.42f, 0.42f, 1.0f);
        }
        ImGui::TextColored(col, "%s", ui_safe_log_line(l));
    }
    ImGui::EndChild();
    if (ImGui::Button("Copy visible events")) {
        char copy[8192] = {0};
        size_t used = 0;
        for (int i = n - 1; i >= 0; --i) {
            const char* line = ui_safe_log_line(zl_log_ring_get(n - 1 - i));
            size_t len = strlen(line);
            if (used + len + 2 >= sizeof(copy)) break;
            memcpy(copy + used, line, len); used += len;
            copy[used++] = '\n'; copy[used] = 0;
        }
        ImGui::SetClipboardText(copy);
        zl_ui_toast("visible events copied");
    }
}

/* ------------------------------------------------------------------ */
static void tab_about(void)
{
    section(ZL_NAME " " ZL_VER "  (" ZL_BUILD ")");
    ImGui::TextWrapped(
        "Runs inside BlueStacks with a separate menu. It forwards the "
        "real system DLL, then hooks the presentation call of the emulator "
        "and inserts a six-stage post-process chain on the presented frame.");
    ImGui::Dummy(ImVec2(0, 6));
    ImGui::BulletText("fxaa  -- 3.11 directional AA + edge sharpen");
    ImGui::BulletText("bright -> gauss h/v  --  half-res bloom");
    ImGui::BulletText("flow  -- 20-candidate 3x3 SAD camera motion");
    ImGui::BulletText("composite  -- sat/con/sharp/bloom/hdr/amb/light/vig");

    ImGui::Dummy(ImVec2(0, 8));
    ImGui::TextColored(ImVec4(0.259f, 0.788f, 0.945f, 1.0f), "HOTKEYS");
    ImGui::BulletText("F2        open / close this panel");
    ImGui::BulletText("Esc       close");
    ImGui::BulletText("right-clk zero a slider");

    ImGui::Dummy(ImVec2(0, 8));
    ImGui::TextColored(ImVec4(0.259f, 0.788f, 0.945f, 1.0f), "SAFETY");
    ImGui::TextWrapped(
        "Every stage early-outs to a bit-exact pass-through when its weight "
        "is zero. Turn the master switch off and the emulator frame reaches "
        "the display untouched. Closing the emulator unloads the DLL; "
        "previous guest or Windows changes can remain until separately restored.");
}

/* ------------------------------------------------------------------ */
/*  Compact panel. Used whenever the host reports a surface too small for
 *  the tabbed layout (a windowed emulator dragged small, a mode switch in
 *  progress, a guest resolution like 480x360). The tabbed panel needs a
 *  tab bar plus two child windows to lay out; below roughly 560x420 the
 *  layout arithmetic has no room and the frame stalls. This path has no
 *  tab bar, no child window and no nested scrolling, so it cannot stall.
 *  Overflow simply extends past the surface and is clipped by the host,
 *  which is the right behaviour: better a cropped panel than a hang.
 * ------------------------------------------------------------------ */
static int s_trace = -1;
static void trace(const char* where)
{
    if (s_trace < 0) {
        char e[8];
        s_trace = GetEnvironmentVariableA("ZLAG_TRACE", e, sizeof(e)) ? 1 : 0;
    }
    if (s_trace) zl_log(LOG_INFO, "trace: %s", where);
}

static void draw_menu_compact(float vw, float vh)
{
    trace("compact:enter");
    float w = ZL_MIN(vw - 16.0f, 460.0f);
    float h = ZL_MIN(vh - 16.0f, 400.0f);
    if (w < 220.0f) w = vw;          /* absurdly small: use what there is */
    if (h < 160.0f) h = vh;

    ImGui::SetNextWindowPos(ImVec2(8, 8), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_Always);
    ImGui::Begin("##zlagcompact", NULL,
                 ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoTitleBar);

    ImGui::TextColored(ImVec4(0.61f, 0.94f, 0.31f, 1.0f), "Z-LAG");
    inline_disabled("compact");
    ImGui::Separator();

    bool master = g_cfg.masterOn != 0;
    if (zl_check("##fx", "effects", &master)) g_cfg.masterOn = master ? 1 : 0;
    if (ImGui::Button("Preset: performance")) zl_apply_preset(1);
    if (ImGui::Button("Preset: cinematic"))   zl_apply_preset(2);
    if (ImGui::Button("Reset all to neutral")) zl_apply_preset(0);
    ImGui::Separator();
    if (ImGui::Button("Save + close", ImVec2(-1, 0))) {
        zl_settings_save();
        InterlockedExchange(&g_state.menuWanted, 0);
    }
    ImGui::TextDisabled("surface %dx%d", (int)vw, (int)vh);
    ImGui::End();
    trace("compact:exit");
}

/* ------------------------------------------------------------------ */
static void draw_menu(void)
{
    const ImGuiViewport* vp = ImGui::GetMainViewport();

    /* A hostile viewport is the single most common way for this panel to
     * "not show up": a host that reports 0x0 (or the guest resolution, or a
     * resolution mid-switch) makes the subtraction below negative, and a
     * window with a negative size draws nothing at all. Sanitise first,
     * then compute. */
    float vw = vp->Size.x, vh = vp->Size.y;
    if (!(vw > 64.0f)) vw = 1280.0f;      /* also catches NaN */
    if (!(vh > 64.0f)) vh = 720.0f;

    /* Below this the tabbed layout has no room to lay out. Take the small
     * path instead of letting the layout arithmetic stall the frame.
     *
     * This threshold has to agree with the width the window is actually
     * given. It used to sit at 560 while the window itself could be 520
     * wide, which happened on every screen under ~1550 px: the menu fell
     * into the compact path and the compact path has NO TAB BAR. The panel
     * came up looking fine and simply had no Optimize, no Visuals, no ADB --
     * there was nothing to click, so "optimizations are not working" was
     * literally true. The tabbed layout's own floor is 520 (see `w` below),
     * so that is where this has to be. */
    if (!g_cfg.menuWindow && (vw < ZL_MENU_MIN_TABBED_W || vh < 380.0f)) {
        draw_menu_compact(vw, vh);
        return;
    }

    float w = ZL_MIN(790.0f, vw - 40.0f);
    float h = ZL_MIN(632.0f, vh - 60.0f);
    if (w < 640.0f) w = 640.0f;      /* floor: the nav rail needs it       */
    if (h < 360.0f) h = 360.0f;

    if (g_cfg.menuWindow) {
        /* EXTERNAL WINDOW LANE: the panel IS the window.
         *
         * It used to be a floating 790x632 window centred inside a 760x600
         * surface, so the area outside it showed the surface's own
         * background -- the "extra rectangle behind the UI". Now the panel
         * is pinned to the client rect at its exact size, and its rounding
         * is dropped (pushed below) so it covers every pixel: the rounded
         * shape comes from the window region, which is what the compositor
         * sees. Nothing is drawn that is not the menu. */
        /* Never a zero or absurd size: a window sized to a viewport that
         * momentarily reports 0 (minimise, DPI change, first frame) makes
         * ImGui unhappy, and that is the sort of thing that kills the
         * process the moment the user clicks something. */
        w = (vw > 320.0f) ? vw : 320.0f;
        h = (vh > 240.0f) ? vh : 240.0f;
        ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_Always);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    } else {
        /* OVERLAY LANE: a floating panel over the game, remember its place */
        if (s_openFrames == 0 && vw > 1.0f && vh > 1.0f) {
            ImGui::SetNextWindowPos(ImVec2(vp->Size.x * 0.5f, vp->Size.y * 0.5f),
                                    ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        } else {
            ImGui::SetNextWindowPos(ImVec2(s_posX, s_posY), ImGuiCond_FirstUseEver);
        }
        ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSizeConstraints(ImVec2(640, 380),
                                            ImVec2(ZL_MAX(w, 640.0f), ZL_MAX(h, 380.0f)));
    }

    /* No resizing and no scrollbar: a scrollbar here is pure hazard -- the
     * mouse wheel is forwarded to the game while the panel is closed, and a
     * stale scroll offset is one of the ways a panel can come up "empty".
     * The size is fixed to the viewport so it cannot be dragged off screen. */
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
                             ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                             /* the panel draws its own header now, so ImGui's
                              * title bar would be a second one directly under
                              * it */
                             ImGuiWindowFlags_NoTitleBar;
    ImGui::Begin("Z-Lag Emulator Optimizer", NULL, flags);
    if (g_cfg.menuWindow) ImGui::SetWindowPos(ImVec2(0, 0));   /* never drifts */

    /* If a previous run left the window at an off-screen position, or the
     * host shrank the surface, pull it back where it can be seen. */
    {
        ImVec2 p = ImGui::GetWindowPos();
        ImVec2 sz = ImGui::GetWindowSize();
        float nx = p.x, ny = p.y;
        float maxX = vp->Pos.x + vw - sz.x;
        float maxY = vp->Pos.y + vh - sz.y;
        if (maxX < vp->Pos.x) maxX = vp->Pos.x;
        if (maxY < vp->Pos.y) maxY = vp->Pos.y;
        if (nx < vp->Pos.x) nx = vp->Pos.x;
        if (ny < vp->Pos.y) ny = vp->Pos.y;
        if (nx > maxX) nx = maxX;
        if (ny > maxY) ny = maxY;
        if (nx != p.x || ny != p.y) ImGui::SetWindowPos(ImVec2(nx, ny));
        s_posX = nx; s_posY = ny;      /* remembered, already clamped */
    }
    s_posX = ImGui::GetWindowPos().x;
    s_posY = ImGui::GetWindowPos().y;

    /* ==================================================================
     *  Shell: header (close dots + title), sidebar, body, status bar.
     *  Same arrangement as the reference layout: navigation lives on the
     *  left as a rail, the content is one card, and a status strip runs
     *  along the bottom.
     * ================================================================== */
    ImDrawList* dl = ImGui::GetWindowDrawList();

    /* ---- header ---------------------------------------------------- */
    {
        ImVec2 p = ImGui::GetCursorScreenPos();
        const ImU32 cols[3] = { IM_COL32(255, 95, 86, 255),
                                IM_COL32(255, 189, 46, 255),
                                IM_COL32(39, 201, 63, 255) };
        float cy = p.y + 8.0f;
        ImVec2 mp = ImGui::GetIO().MousePos;

        for (int i = 0; i < 3; i++) {
            ImVec2 c0(p.x + 8.0f + (float)i * 20.0f, cy);
            bool hov = (mp.x - c0.x) * (mp.x - c0.x) + (mp.y - c0.y) * (mp.y - c0.y) < 42.0f;
            dl->AddCircleFilled(c0, 6.0f, hov ? IM_COL32(255, 255, 255, 200) : cols[i], 24);
            if (hov && ImGui::IsMouseClicked(0)) {
                if (i == 0) {                       /* red: save + close */
                    zl_settings_save();
                    InterlockedExchange(&g_state.menuWanted, 0);
                    InterlockedExchange(&g_state.menuOpen, 0);
                } else if (i == 1) {                /* amber: collapse     */
                    g_cfg.bannerFrames = g_cfg.bannerFrames ? 0 : 1;
                }
            }
        }

        {
            /* round mark + wordmark + build badge, straight off the
             * reference's title bar */
            float ty = cy - ImGui::GetTextLineHeight() * 0.5f;
            ImVec2 ic(p.x + 82.0f, cy);
            dl->AddCircle(ic, 9.0f, IM_COL32(255, 255, 255, 210), 26, 1.4f);
            dl->AddCircleFilled(ic, 3.0f, IM_COL32(255, 255, 255, 255), 16);

            dl->AddText(ImVec2(p.x + 98.0f, ty), IM_COL32(250, 250, 252, 255), "Z-LAG");
            float tw = ImGui::CalcTextSize("Z-LAG").x;
            /* badge */
            ImVec2 ba(p.x + 108.0f + tw, ty - 3.0f);
            ImVec2 bb(p.x + 108.0f + tw + 92.0f, ty + ImGui::GetTextLineHeight() + 3.0f);
            dl->AddRectFilled(ba, bb, IM_COL32(255, 255, 255, 18), 4.0f);
            dl->AddRect(ba, bb, IM_COL32(255, 255, 255, 45), 4.0f, 0, 1.0f);
            dl->AddText(ImVec2(ba.x + 6.0f, ty), IM_COL32(160, 160, 170, 255),
                        "BUILD " ZL_VER " MONO");
        }

        /* right of the header: the effects switch, which used to live in
         * the old title strip */
        float w = ImGui::GetWindowWidth();
        ImGui::SetCursorScreenPos(ImVec2(p.x + w - 190.0f, p.y));
        bool master = g_cfg.masterOn != 0;
        if (zl_check("##effects", "effects ON", &master)) {
            g_cfg.masterOn = master ? 1 : 0;
            zl_ui_toast(master ? "effects re-enabled" : "effects off -- clean frame");
        }

        /* Drag: press anywhere on the header that is not one of the dots.
         * The window is borderless, so this hand-off to HTCAPTION is what
         * makes the panel movable at all. */
        ImGui::SetCursorScreenPos(ImVec2(p.x + 62.0f, p.y));
        {
            /* Drag strip: the empty middle of the header only, so it can
             * never sit on top of a control. */
            float bandW = w - 490.0f;
            if (bandW < 40.0f) bandW = 40.0f;
            ImGui::SetCursorScreenPos(ImVec2(p.x + 290.0f, p.y));
            ImGui::InvisibleButton("##hdrag", ImVec2(bandW, 22.0f));
        }
        if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0)) {
            void* hwnd = zl_menuwin_hwnd();
            if (hwnd) {
                ReleaseCapture();
                SendMessageA((HWND)hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }
        ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + 30.0f));
    }

    float footerH = 30.0f;

    /* ---- sidebar ---------------------------------------------------- */
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.063f, 0.063f, 0.070f, 1.0f));
    ImGui::BeginChild("##nav", ImVec2(158.0f, -footerH), false);
    {
        static const char* items[7] = { "PERFORMANCE", "VISUALS", "PRESETS",
                                        "OPTIMIZE", "ADB DEBLOAT", "LOG", "ABOUT" };
        ImGui::Dummy(ImVec2(0, 6));
        for (int i = 0; i < 7; i++) {
            /* Native Selectable, not an InvisibleButton: the rail is the
             * thing a user clicks first, and it has to be a real widget. */
            bool sel = (s_tab == i);
            ImVec2 p = ImGui::GetCursorScreenPos();
            ImGui::PushID(i);
            ImGui::PushStyleColor(ImGuiCol_Header,        ImVec4(1, 1, 1, 0.130f));
            ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImVec4(1, 1, 1, 0.080f));
            ImGui::PushStyleColor(ImGuiCol_HeaderActive,  ImVec4(1, 1, 1, 0.180f));
            ImGui::PushStyleColor(ImGuiCol_Text, sel ? ImVec4(0.98f, 0.98f, 0.99f, 1)
                                                    : ImVec4(0.44f, 0.44f, 0.48f, 1));
            if (ImGui::Selectable(items[i], sel, ImGuiSelectableFlags_None,
                                  ImVec2(ImGui::GetContentRegionAvail().x, 28.0f)))
                s_tab = i;
            ImGui::PopStyleColor(4);
            ImGui::PopID();
            if (sel) {
                ImDrawList* nd = ImGui::GetWindowDrawList();
                nd->AddRectFilled(ImVec2(p.x, p.y + 4.0f), ImVec2(p.x + 2.5f, p.y + 24.0f),
                                  IM_COL32(255, 255, 255, 240), 2.0f);
            }
            ImGui::Dummy(ImVec2(0, 1));
        }

        /* bottom card: the number that matters while it runs.
         * Anchored to the rail's own bottom edge, not to the cursor: on a
         * short window there was no room left after the nav rows and the
         * card ended up outside the clip rect, i.e. invisible. */
        {
            ImVec2 wp  = ImGui::GetWindowPos();
            float  wh  = ImGui::GetWindowHeight();
            float  pad = ImGui::GetStyle().WindowPadding.x;
            ImVec2 p(wp.x + pad, wp.y + wh - 72.0f);
            ImVec2 sz(ImGui::GetWindowWidth() - pad * 2.0f - 8.0f, 60.0f);
            ImDrawList* nd = ImGui::GetWindowDrawList();
            nd->AddRectFilled(p, ImVec2(p.x + sz.x, p.y + sz.y),
                              IM_COL32(255, 255, 255, 12), 8.0f);
            nd->AddRect(p, ImVec2(p.x + sz.x, p.y + sz.y),
                        IM_COL32(255, 255, 255, 40), 8.0f, 0, 1.0f);
            char v[32];
            if (g_state.lastSwaps == 0) _snprintf(v, sizeof(v), "--");
            else                        _snprintf(v, sizeof(v), "%d", fps_shown());
            nd->AddText(ImVec2(p.x + 12.0f, p.y + 8.0f),
                        IM_COL32(140, 140, 152, 255), "FPS");
            nd->AddText(ImVec2(p.x + sz.x - 42.0f, p.y + 6.0f),
                        IM_COL32(255, 255, 255, 255), v);
            float frac = (float)fps_shown() / 120.0f;
            if (frac > 1.0f) frac = 1.0f;
            nd->AddRectFilled(ImVec2(p.x + 12.0f, p.y + 30.0f),
                              ImVec2(p.x + sz.x - 12.0f, p.y + 34.0f),
                              IM_COL32(255, 255, 255, 24), 2.0f);
            nd->AddRectFilled(ImVec2(p.x + 12.0f, p.y + 30.0f),
                              ImVec2(p.x + 12.0f + (sz.x - 24.0f) * frac, p.y + 34.0f),
                              IM_COL32(255, 255, 255, 235), 2.0f);
            /* the live dot */
            nd->AddCircleFilled(ImVec2(p.x + 16.0f, p.y + 48.0f), 3.5f,
                                g_state.menuWanted ? IM_COL32(39, 201, 63, 255)
                                                   : IM_COL32(120, 120, 130, 255), 12);
            nd->AddText(ImVec2(p.x + 26.0f, p.y + 41.0f),
                        IM_COL32(200, 200, 210, 255), "ACTIVE");
        }
    }
    ImGui::EndChild();
    ImGui::PopStyleColor();

    ImGui::SameLine(0.0f, 10.0f);

    /* ---- body ------------------------------------------------------- */
    ImGui::BeginChild("##tabbody", ImVec2(0, -footerH), false,
                      ImGuiWindowFlags_HorizontalScrollbar);
    if (s_tab < 0 || s_tab > 6) s_tab = 0;     /* never index past the tabs */
    switch (s_tab) {
    case 0: tab_performance(); break;
    case 1: tab_visuals();     break;
    case 2: tab_presets();     break;
    case 3: tab_optimize();    break;
    case 4: tab_adb();         break;
    case 5: tab_log();         break;
    case 6: tab_about();       break;
    default: tab_performance(); break;
    }
    ImGui::EndChild();

    /* ---- status bar -------------------------------------------------- */
    {
        ImVec2 p = ImGui::GetCursorScreenPos();
        float w = ImGui::GetWindowWidth();
        float y = p.y + 2.0f;
        dl->AddRectFilled(ImVec2(p.x - 16.0f, y), ImVec2(p.x + w - 16.0f, y + 26.0f),
                          IM_COL32(0, 0, 0, 150), 6.0f);
        dl->AddCircleFilled(ImVec2(p.x + 2.0f, y + 13.0f), 3.5f,
                            IM_COL32(72, 240, 120, 255), 12);
        dl->AddText(ImVec2(p.x + 14.0f, y + 6.0f), IM_COL32(240, 240, 245, 255),
                    "Z-LAG");
        dl->AddText(ImVec2(p.x + 94.0f, y + 6.0f),
                    IM_COL32(113, 113, 122, 255), "MENU");

        char right[110];
        if (g_state.lastSwaps == 0)
            _snprintf(right, sizeof(right), "-- FPS   |   -- ms   |   TOGGLE [F2]");
        else
            _snprintf(right, sizeof(right), "%d FPS   |   %d ms   |   TOGGLE [F2]",
                      fps_shown(), (int)g_state.frameMs);
        float rw = ImGui::CalcTextSize(right).x;
        dl->AddText(ImVec2(p.x + w - 46.0f - rw, y + 6.0f),
                    IM_COL32(150, 150, 162, 255), right);

        ImGui::SetCursorScreenPos(ImVec2(p.x + w - 40.0f, y + 3.0f));
        if (ImGui::Button("X", ImVec2(24, 20))) {
            zl_settings_save();
            InterlockedExchange(&g_state.menuWanted, 0);
            InterlockedExchange(&g_state.menuOpen, 0);
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("save + close\nF2 brings it back");
    }

    /* Publish the panel's rect so the window thread can tell a click
     * meant for the panel from a click meant for the game. Without this
     * the only honest choices are "swallow everything" (the game dies)
     * or "swallow nothing" (the panel cannot be used). */
    {
        ImVec2 q0 = ImGui::GetWindowPos();
        ImVec2 q1 = ImGui::GetWindowSize();
        zl_panel_rect((int)q0.x, (int)q0.y, (int)q1.x, (int)q1.y);
    }

    ImGui::End();
    if (g_cfg.menuWindow) ImGui::PopStyleVar(2);
}


/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/*  Persistent HUD.
 *
 *  Present from the first frames the emulator presents, whether the panel
 *  is open or not. Three parts, left to right:
 *
 *      +-------+   28 FPS      Z-LAG   00:03:41      [ OPEN  Z-LAG ]
 *      | badge |   smooth       credit   since boot     hit rect
 *      +-------+
 *
 *  Everything is quads + text on the foreground draw list -- the same
 *  path as the old pill, which is the one thing proven to draw on every
 *  host so far. No ImGui window, so no layout or style can make it vanish.
 *
 *  The OPEN button publishes its rect; the window thread forwards mouse
 *  events that land in it, and feed_input() hands them to ImGui, which is
 *  how a non-widget ends up clickable.
 * ------------------------------------------------------------------ */
static DWORD s_bootTick = 0;
static float s_fpsSmooth = 0.0f;

static void hud_reset(void) { s_bootTick = 0; s_fpsSmooth = 0.0f; }

static void draw_hud(const ImGuiViewport* vp, bool menuOpen)
{
    /* The strip is gone: no fps counter, no credit tag, no uptime. The only
     * thing Z-Lag puts on the emulator's own surface is this one button, and
     * it is the only pixel anywhere that takes a click. Everything else
     * lives in the menu window. */
    ImDrawList* dl = ImGui::GetForegroundDrawList();

    const float padX = 12.0f, padY = 7.0f;
    const float H    = ImGui::GetTextLineHeight() + padY * 2.0f;

    float x = vp->Pos.x + 16.0f;
    float y = vp->Pos.y + 14.0f;
    if (!(x > vp->Pos.x)) x = vp->Pos.x + 6.0f;
    if (!(y > vp->Pos.y)) y = vp->Pos.y + 6.0f;

    const ImU32 dark = IM_COL32(10, 16, 8, 255);
    const ImU32 lime = IM_COL32(155, 240, 80, 255);

    const char* label = menuOpen ? "CLOSE  Z-LAG" : "OPEN  Z-LAG";
    ImVec2 ts = ImGui::CalcTextSize(label);
    float bw = ts.x + padX * 2.0f;
    ImVec2 p0(x, y), p1(x + bw, y + H);

    ImVec2 mp = ImGui::GetIO().MousePos;
    bool hover = mp.x >= p0.x && mp.x <= p1.x &&
                 mp.y >= p0.y && mp.y <= p1.y;
    if (hover && ImGui::IsMouseClicked(0))
        zl_open_menu_toggle();

    dl->AddRectFilled(p0, p1,
                      hover ? IM_COL32(176, 255, 96, 255) : lime, 5.0f);
    dl->AddText(ImVec2(x + padX, y + padY), dark, label);

    /* Only the button is published. Every other pixel of the emulator's
     * surface stays the game's: the host asks us for a hit test and, off
     * this rectangle, we say no. */
    zl_launcher_rect((int)p0.x, (int)p0.y, (int)bw, (int)H);
}

static void draw_osd(void)
{
    const ImGuiViewport* vp = ImGui::GetMainViewport();

    /* ---- the launcher pill ------------------------------------------
     * Top-LEFT by default. If the host reports a viewport narrower than a
     * plausible window (some emulators report the guest surface, not the
     * window, for a while during a resolution switch) the pill is pushed
     * to the right edge, but never outside the screen -- "invisible"
     * was most likely "drawn at x = something the user cannot see".  */
    float pw = 0.0f, ph = 0.0f;
    ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + 18, vp->Pos.y + 18), ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.78f);
    ImGuiWindowFlags f = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize |
                         ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing |
                         ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove;
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10, 8));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(14, 7));
    ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.61f, 0.94f, 0.31f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.72f, 1.00f, 0.42f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.52f, 0.84f, 0.24f, 1.00f));
    ImGui::PushStyleColor(ImGuiCol_Text,          ImVec4(0.04f, 0.06f, 0.03f, 1.00f));

    const char* label = g_state.menuWanted ? "CLOSE  Z-LAG" : "OPEN  Z-LAG";

    if (ImGui::Begin("##zlagosd", NULL, f)) {
        /* Exactly one item. Everything the old status strip drew (fps,
         * frame ms, the credit tag, the Ctrl+<key> hint) is gone, and so
         * is the style pop that used to sit in the middle of this block --
         * that pop was firing four colours early, so the text after it was
         * drawn in the button's foreground colour. Both are gone: the
         * colours are popped once, after End(), together with the vars. */
        if (ImGui::Button(label, ImVec2(0, 0)))
            zl_open_menu_toggle();

        /* Publish the pill's rect for the hit test. Read it back from
         * ImGui rather than recomputing it, so what the user sees and what
         * the click test uses can never drift apart. */
        ImVec2 a = ImGui::GetWindowPos();
        ImVec2 b = ImGui::GetWindowSize();
        pw = b.x; ph = b.y;

        /* keep it on screen no matter what the viewport claims */
        if (a.x + b.x > vp->Pos.x + vp->Size.x) {
            ImGui::SetWindowPos(ImVec2(vp->Pos.x + vp->Size.x - b.x - 18,
                                       vp->Pos.y + 18), ImGuiCond_Always);
            a = ImGui::GetWindowPos();
            b = ImGui::GetWindowSize();
            pw = b.x; ph = b.y;
        }
        zl_launcher_rect((int)a.x, (int)a.y, (int)pw, (int)ph);
    } else {
        zl_launcher_rect(0, 0, 0, 0);
    }
    ImGui::End();
    ImGui::PopStyleColor(4);
    ImGui::PopStyleVar(2);
}

/* ------------------------------------------------------------------ */
/*  Hard "we are alive" marker. Border-only rectangle in the top-right:
 *  no font, no texture, no text batch -- just four quads of solid accent.
 *  On a host where a font atlas or glyph batch fails to upload, the panel
 *  can look blank while this rectangle still shows. If you see nothing at
 *  all, not even this, the overlay is not being composited, and that is a
 *  completely different problem from a UI bug.                        */
/* ------------------------------------------------------------------ */
static void draw_banner(void)
{
    if (g_cfg.bannerFrames <= 0 && s_bannerLeft <= 0) return;
    int left = (g_cfg.bannerFrames > 0) ? g_cfg.bannerFrames : s_bannerLeft;
    if (left <= 0) return;

    const ImGuiViewport* vp = ImGui::GetMainViewport();
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    const ImU32 on = IM_COL32(155, 240, 80, 255);

    /* A zero-size viewport (reported by some hosts for the first frames of a
     * mode switch) would park the marker at a negative coordinate. Clamp. */
    float vw = vp->Size.x > 200.0f ? vp->Size.x : 1280.0f;
    float x = vp->Pos.x + vw - 96.0f;
    float y = vp->Pos.y + 24.0f;
    float s = 56.0f;                  /* frame size  */
    float t = 4.0f;                   /* line thickness */

    /* a hollow square: unmistakably not part of the game */
    dl->AddRectFilled(ImVec2(x, y), ImVec2(x + s, y + t), on);
    dl->AddRectFilled(ImVec2(x, y + s - t), ImVec2(x + s, y + s), on);
    dl->AddRectFilled(ImVec2(x, y), ImVec2(x + t, y + s), on);
    dl->AddRectFilled(ImVec2(x + s - t, y), ImVec2(x + s, y + s), on);
    /* a dot in the middle: filled = GL2 path, hollow = degraded */
    dl->AddCircleFilled(ImVec2(x + s * 0.5f, y + s * 0.5f), 10.0f, on);

    if (g_cfg.bannerFrames > 0) g_cfg.bannerFrames--;
    else if (s_bannerLeft > 0) s_bannerLeft--;
}

/* ------------------------------------------------------------------ */
static void draw_toast(void)
{
    if (!s_toast[0] || GetTickCount() > s_toastUntil) return;
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(ImVec2(vp->Size.x * 0.5f, vp->Size.y - 140.0f),
                            ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowBgAlpha(0.88f);
    /* a notification must never be buried under the panel, so it is drawn
     * in its own foreground layer with an explicit > panel depth */
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(16, 10));
    ImGuiWindowFlags f = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize |
                         ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing |
                         ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove;
    /* Being focused makes ImGui move this window to the front of the draw
     * order, which is exactly what a notification needs over the panel. */
    ImGui::SetNextWindowFocus();
    if (ImGui::Begin("##zlagtoast", NULL, f)) {
        ImGui::TextColored(ImVec4(0.259f, 0.788f, 0.945f, 1.0f), ZL_TAG);
        ImGui::SameLine();
        ImGui::TextUnformatted(s_toast);
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

/* ------------------------------------------------------------------ */
/*  Window lanes.
 *
 *  There is one ImGui context per lane. The overlay lane draws into the
 *  emulator's GL context; the menu-window lane draws into a window of its
 *  own. Both lanes call build_frame() -- the tabs and the strip are the
 *  same code -- and only the caller decides where the result is rendered.
 *
 *  The reason this is a parameter and not a global: ui_es_render() binds
 *  shaders and buffers by ID, and a buffer ID from one GL context is
 *  meaningless in another. Letting the window thread call the overlay's
 *  renderer blew up the host. Build here, render there.
 * ------------------------------------------------------------------ */
static CRITICAL_SECTION s_uiLock;

/* ImGui's current context is one process-wide global, not per thread. Two
 * lanes, two contexts, one global: whichever thread ran last leaves its
 * pointer behind, and the other lane then draws its geometry against the
 * wrong atlas. That is why the menu window rendered bars and boxes with no
 * text in them. Each lane pins its own context at the top of its frame. */
static ImGuiContext* s_ctxOverlay = NULL;
static ImGuiContext* s_ctxWindow  = NULL;

extern "C" void zl_ui_bind_window_context(ImGuiContext* ctx) { s_ctxWindow = ctx; }
extern "C" ImGuiContext* zl_ui_overlay_context(void) { return s_ctxOverlay; }
static volatile LONG    s_uiLockReady = 0;

/* Two threads now drive two ImGui contexts: the GL thread draws the strip
 * on the emulator, the menu thread draws the tabs in its own window. ImGui
 * keeps the current context in a process-wide global, not per thread, so
 * the two lanes must not interleave -- that interleaving is a use of one
 * context's memory by the other thread's code, and it crashed the host.
 * The section is recursive, so a lane can take it and helpers can re-take. */
extern "C" void zl_ui_lock(void)
{
    if (!s_uiLockReady) {
        static volatile LONG guard = 0;
        if (InterlockedCompareExchange((LONG*)&guard, 1, 0) == 0) {
            InitializeCriticalSection(&s_uiLock);
            InterlockedExchange(&s_uiLockReady, 1);
        }
        while (!s_uiLockReady) Sleep(1);
    }
    EnterCriticalSection(&s_uiLock);
}

extern "C" void zl_ui_unlock(void)
{
    LeaveCriticalSection(&s_uiLock);
}


/* The first-run help card used to live here. It is gone on purpose.
 *
 * In every form ImGui offers it broke something worse than the help
 * it gave: BeginPopupModal greyed the whole emulator, BeginPopup made
 * the panel refuse every click, and as a plain window -- even once
 * moved to the end of the frame so it drew above the panel -- it still
 * sat still and ate the first click anyone made. 'A menu that cannot
 * be clicked' is a far worse first impression than 'no tips'.
 *
 * The same information is in README.md and on the About tab, where it
 * costs no input handling and cannot block anything. helpSeen stays
 * in the ini for compatibility; nothing reads it now.
 */

/* ------------------------------------------------------------------ */
static int ui_init_impl(void)
{
    if (s_imguiInit) return 1;
    IMGUI_CHECKVERSION();

    /* CreateContext restores the previous context when one is already active.
     * The external menu can start first, so explicitly select the NEW overlay
     * context before changing its style, font atlas, or font scale. Otherwise
     * the overlay's 0.5 supersample scale shrinks the menu a few seconds after
     * it opens. All of this runs under the shared recursive UI lock. */
    ImGuiContext* previous = ImGui::GetCurrentContext();
    s_ctxOverlay = ImGui::CreateContext();
    if (!s_ctxOverlay) return 0;
    ImGui::SetCurrentContext(s_ctxOverlay);
    style_zlag();
    ImGui::GetIO().IniFilename = NULL;

    if (!zlui_es_init()) {
        zl_log(LOG_ERR, "UI backend init failed (no GL2/ES2 shader support)");
        ImGui::DestroyContext(s_ctxOverlay);
        s_ctxOverlay = NULL;
        ImGui::SetCurrentContext(previous);
        return 0;
    }
    s_imguiInit = true;
    ImGui::SetCurrentContext(previous);
    zl_log(LOG_OK, "overlay (imgui %s, gl2 backend on the host context) ready", IMGUI_VERSION);
    return 1;
}

static void ui_shutdown_impl(void)
{
    if (!s_imguiInit) return;
    zlui_es_shutdown();
    ImGui::DestroyContext();
    s_imguiInit = false;
}


/* ------------------------------------------------------------------ */
/*  one frame, for whichever lane asked for it                        */
static int build_frame(int w, int h, int lane)
{
    static bool wasOpen = false;
    zl_ui_lock();

    ImGuiContext* want = (lane == ZL_LANE_WINDOW) ? s_ctxWindow : s_ctxOverlay;
    if (want && ImGui::GetCurrentContext() != want)
        ImGui::SetCurrentContext(want);

    bool menu = g_state.menuWanted != 0;
    InterlockedExchange(&g_state.menuOpen, menu ? 1 : 0);

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)w, (float)h);
    ImGui::GetMainViewport()->Pos  = ImVec2(0.0f, 0.0f);
    ImGui::GetMainViewport()->Size = ImVec2((float)w, (float)h);

    if (menu && !wasOpen) {
        s_openFrames = 0;
        /* throw away everything queued while closed: the first frame would
         * otherwise replay a stale held button and look frozen */
        InterlockedExchange(&g_in.tail, g_in.head);
        ImGuiIO& o = ImGui::GetIO();
        o.AddMouseButtonEvent(0, false);
        o.AddMouseButtonEvent(1, false);
        o.AddMouseButtonEvent(2, false);
        o.AddMouseWheelEvent(0.0f, 0.0f);
    } else if (!menu && wasOpen) {
        ImGuiIO& o = ImGui::GetIO();
        o.AddMouseButtonEvent(0, false);
        o.AddMouseButtonEvent(1, false);
        o.AddMouseButtonEvent(2, false);
    } else if (menu) {
        if (s_openFrames < 1000000) s_openFrames++;
    }
    wasOpen = menu;

    io.DeltaTime = 1.0f / (g_state.fps > 1 ? (float)g_state.fps : 60.0f);
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = NULL;

    feed_input(lane);

    trace("frame:newframe");
    /* The window owns a different GL context and font atlas. */
    if (lane == ZL_LANE_OVERLAY) zlui_es_new_frame();
    ImGui::NewFrame();
    trace("frame:newframe-done");

    trace("frame:menu");
    if (menu) draw_menu();
    draw_hud(ImGui::GetMainViewport(), menu);
    trace("frame:menu-done");
    if (lane == ZL_LANE_OVERLAY) {
        draw_banner();
        draw_toast();
    }

    trace("frame:imgui-render");
    ImGui::Render();
    trace("frame:imgui-rendered");

    ImDrawData* dd = ImGui::GetDrawData();
    if (dd) {
        InterlockedExchange(&g_state.drawCalls, (LONG)dd->CmdListsCount);
        InterlockedExchange(&g_state.uiW, (LONG)dd->DisplaySize.x);
        InterlockedExchange(&g_state.uiH, (LONG)dd->DisplaySize.y);
    }
    zl_ui_unlock();
    return dd != NULL;
}

/* ---- C ABI wrappers (hooks.c is plain C) --------------------------- */
extern "C" void zl_osd_banner(int frames)        { s_bannerLeft = frames > 0 ? frames : 300; }
extern "C" int  zl_ui_frame(int w, int h)        { return build_frame(w, h, ZL_LANE_OVERLAY); }
extern "C" int  zl_ui_frame_window(int w, int h) { return build_frame(w, h, ZL_LANE_WINDOW); }
extern "C" int zl_ui_init_once(void)
{
    zl_ui_lock();
    int ready = ui_init_impl();
    zl_ui_unlock();
    return ready;
}
extern "C" void zl_ui_style_window(void) { style_zlag(); }
extern "C" void zl_hud_reset(void)               { hud_reset(); }
extern "C" void zl_ui_shutdown(void)
{
    zl_ui_lock();
    ImGuiContext* previous = ImGui::GetCurrentContext();
    ImGuiContext* overlay = s_ctxOverlay;
    if (overlay) ImGui::SetCurrentContext(overlay);
    ui_shutdown_impl();
    s_ctxOverlay = NULL;
    /* Do not leave the current context pointing at the destroyed overlay. */
    ImGui::SetCurrentContext(previous == overlay ? NULL : previous);
    zl_ui_unlock();
}
extern "C" void zl_ui_toast(const char* text)    { ui_toast_impl(text); }
