/* ------------------------------------------------------------------
 *  selftest.c  --  "is it actually alive?" without looking at the screen
 *
 *  When the overlay is invisible the question is never "is the shader
 *  pretty", it is one of:
 *     a) the DLL is not in this process at all
 *     b) it is loaded but the presentation hook never fired
 *     c) the hook fires but the GL chain failed to build
 *     d) everything works and the user still cannot see it
 *
 *  This writes zlag-selftest.txt next to the DLL on every hotkey press
 *  and once at boot. It is deliberately plain C, no GL, no ImGui: the GL
 *  thread writes the counters, this reads them. It also probes the
 *  configured hotkey from outside the process.
 * ------------------------------------------------------------------ */
#include "common.h"
#include <stdio.h>

static void write_line(FILE* f, const ZLagSettings* c, const ZLagState* st)
{
    fprintf(f, "Z-Lag self-test  build %s\n", ZL_BUILD_ID);
    fprintf(f, "-------------------------------------------------------\n");
    fprintf(f, "process        : %s (pid %lu, %s)\n",
            st->exeName[0] ? st->exeName : "?",
            (unsigned long)GetCurrentProcessId(),
            sizeof(void*) == 8 ? "64-bit" : "32-bit");
    fprintf(f, "hook           : wgl=%ld egl=%ld   present frames=%ld\n",
            (long)st->hookedWgl, (long)st->hookedEgl, (long)st->swFrames);
    fprintf(f, "GL             : %s / %s / %s\n",
            st->glVendor[0] ? st->glVendor : "?",
            st->glRenderer[0] ? st->glRenderer : "?",
            st->glVersion[0] ? st->glVersion : "?");
    fprintf(f, "overlay frames : %ld drawn, %ld skipped\n",
            (long)st->uiFrames, (long)st->uiFails);
    fprintf(f, "overlay size   : %ld x %ld px reported to ImGui\n",
            (long)st->uiW, (long)st->uiH);
    fprintf(f, "draw lists     : %ld in the last frame\n", (long)st->drawCalls);
    fprintf(f, "menu           : wanted=%ld open=%ld\n",
            (long)st->menuWanted, (long)st->menuOpen);
#ifdef ZL_DEFAULT_MENUWINDOW
    fprintf(f, "hotkey         : F2 (0x%02X)\n", (unsigned)ZL_TOGGLE_VK);
#else
    fprintf(f, "hotkey         : %s%s (0x%02X)\n",
            c->hotkeyCtrl ? "Ctrl + " : "", "KEY",
            (unsigned)c->hotkeyVk);
#endif
    fprintf(f, "launcher rect  : %ld,%ld %ldx%ld\n",
            (long)st->launcherX, (long)st->launcherY,
            (long)st->launcherW, (long)st->launcherH);
    fprintf(f, "-------------------------------------------------------\n");

    if (!st->hookedWgl && !st->hookedEgl)
        fprintf(f, "VERDICT: the DLL is loaded but no presentation hook fired.\n"
                   "         The host draws through a lane we do not hook.\n");
    else if (st->swFrames < 2)
        fprintf(f, "VERDICT: hook installed, but the host has not presented yet.\n");
    else if (st->uiFrames < 2)
        fprintf(f, "VERDICT: frames are presented but the overlay never drew --\n"
                   "         the GL chain or the UI backend failed. Check zlag.log\n"
                   "         for 'post-process chain' and 'UI backend ready'.\n");
    else if (st->drawCalls < 1)
        fprintf(f, "VERDICT: the overlay runs but produced no draw lists.\n");
    else
        fprintf(f, "VERDICT: the overlay IS rendering (%ld frames, %ld draw lists).\n"
                   "         If the screen shows nothing, the compositor is dropping\n"
                   "         our quads, not the UI code.\n",
                (long)st->uiFrames, (long)st->drawCalls);
}

extern "C" void zl_selftest(void)
{
    char path[MAX_PATH];
    zl_cfg_ini_path(path, MAX_PATH);              /* ...\zlag.ini        */
    char* p = strrchr(path, '\\');
    if (p) lstrcpynA(p + 1, "zlag-selftest.txt",
                     MAX_PATH - (int)(p - path));
    else  lstrcpynA(path, "zlag-selftest.txt", MAX_PATH);

    FILE* f = fopen(path, "w");
    if (!f) { zl_log(LOG_WARN, "self-test could not write %s", path); return; }
    write_line(f, &g_cfg, &g_state);
    fclose(f);
    zl_log(LOG_OK, "self-test written to %s", path);
}
