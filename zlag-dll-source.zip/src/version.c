/* =====================================================================
 *  version.c  --  the proxy body.
 *
 *  Every export of version.dll is forwarded to the system copy by name
 *  through a runtime GetProcAddress table (forwarder entries in the .def
 *  would be cleaner, but mingw's ld cannot express "forward to
 *  system32\version.dll" -- so we do the same thing with one
 *  indirection, and every export stays a real function in our image).
 *
 *  DllMain does NOTHING but spawn a worker thread:
 *    - LoadLibrary inside DllMain is a loader-lock deadlock waiting to
 *      happen on some Windows builds, so all module loading happens on
 *      that worker.
 *    - The worker resolves the real version.dll, loads the settings,
 *      starts the log, then waits for HD-Player to create a GL context,
 *      where hooks.c takes over.
 * ===================================================================== */
#include "common.h"
#include "strings.h"

#pragma GCC diagnostic ignored "-Wcast-function-type"

/* every real entry point, resolved once */
typedef struct VerApi {
    HMODULE mod;
    FARPROC GetFileVersionInfoA;
    FARPROC GetFileVersionInfoW;
    FARPROC GetFileVersionInfoExA;
    FARPROC GetFileVersionInfoExW;
    FARPROC GetFileVersionInfoByHandle;
    FARPROC GetFileVersionInfoSizeA;
    FARPROC GetFileVersionInfoSizeW;
    FARPROC GetFileVersionInfoSizeExA;
    FARPROC GetFileVersionInfoSizeExW;
    FARPROC VerFindFileA;
    FARPROC VerFindFileW;
    FARPROC VerInstallFileA;
    FARPROC VerInstallFileW;
    FARPROC VerLanguageNameA;
    FARPROC VerLanguageNameW;
    FARPROC VerQueryValueA;
    FARPROC VerQueryValueW;
} VerApi;

static VerApi s_api;
static char   s_sysdir[MAX_PATH];

/* ------------------------------------------------------------------ */
static void zlag_apply_runtime_fixes(void);

static DWORD WINAPI zlag_worker(LPVOID param)
{
    (void)param;

    /* 1. log first so every later step is visible */
    zl_log_init();
    zl_log(LOG_OK, "%s -- %s", ZL_BANNER, ZL_MSG_ATTACH);

    /* 2. load settings (creates zlag.ini on first run) */
    zl_settings_load();
    zl_lite_apply();     /* honour a saved detail level from the first frame */

    /* 3. who are we hosted by? */
    char exe[MAX_PATH] = {0};
    GetModuleFileNameA(NULL, exe, MAX_PATH);
    char* leaf = strrchr(exe, '\\');
    lstrcpynA(g_state.exeName, leaf ? leaf + 1 : exe, sizeof(g_state.exeName));
    g_state.pid = GetCurrentProcessId();
    g_state.tAttachMs = GetTickCount();
    zl_log(LOG_INFO, "host: %s (pid %lu, %s-bit)",
           g_state.exeName, (unsigned long)g_state.pid,
           sizeof(void*) == 8 ? "64" : "32");

    /* 4. hook the presentation lane. Safe here: not under loader lock,
     *    and the GL context does not exist yet -> our first call into
     *    the swap chain is on the emulator's own render thread.         */
    zl_hooks_install();

    /* 5. everything else the optimizer can do once */
    zlag_apply_runtime_fixes();

    return 0;
}

/* ------------------------------------------------------------------ */
/*  system32\version.dll, explicitly, never our own directory        */
/* ------------------------------------------------------------------ */
static int load_real_version(void)
{
    /* ALWAYS by absolute path. A bare LoadLibraryA("version.dll") would
     * resolve back to THIS module (the app dir is searched first) and we
     * would forward every call to ourselves -> stack overflow. */
    GetSystemDirectoryA(s_sysdir, MAX_PATH);
    char path[MAX_PATH];
    _snprintf(path, sizeof(path), "%s\\version.dll", s_sysdir);
    path[sizeof(path) - 1] = 0;

    {
        char tb[512];
        _snprintf(tb, sizeof(tb), "sysdir path = %s", path);
    }
#if defined(ZLAG_TEST_ALLOW_BUILTIN)
    /* -DZLAG_TEST_ALLOW_BUILTIN builds only (Wine/CI): allow the OS builtin.
     * A shipped build never takes this path. */
    s_api.mod = LoadLibraryA("version.dll");
    {
        HMODULE selfprobe = NULL;
        GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)&load_real_version, &selfprobe);
        if (s_api.mod == selfprobe) s_api.mod = NULL;
    }
#endif
    s_api.mod = LoadLibraryExA(path, NULL, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!s_api.mod) {
        char tb[256];
        _snprintf(tb, sizeof(tb), "LoadLibraryEx failed err=%lu, trying plain", GetLastError());
        s_api.mod = LoadLibraryA(path);   /* pre-KB2533623 */
    }
    if (!s_api.mod) {
        char tb[128];
        _snprintf(tb, sizeof(tb), "plain LoadLibrary failed err=%lu", GetLastError());
    }

    /* self-guard: never forward to our own image */
    HMODULE self = NULL;
    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCSTR)&load_real_version, &self);
#if defined(ZLAG_TEST_ALLOW_BUILTIN)
    if (!s_api.mod) s_api.mod = LoadLibraryA("version.dll");
#endif
    if (!s_api.mod || s_api.mod == self) {
        s_api.mod = NULL;
        return 0;
    }

    s_api.GetFileVersionInfoA        = GetProcAddress(s_api.mod, "GetFileVersionInfoA");
    s_api.GetFileVersionInfoW        = GetProcAddress(s_api.mod, "GetFileVersionInfoW");
    s_api.GetFileVersionInfoExA      = GetProcAddress(s_api.mod, "GetFileVersionInfoExA");
    s_api.GetFileVersionInfoExW      = GetProcAddress(s_api.mod, "GetFileVersionInfoExW");
    s_api.GetFileVersionInfoByHandle = GetProcAddress(s_api.mod, "GetFileVersionInfoByHandle");
    s_api.GetFileVersionInfoSizeA    = GetProcAddress(s_api.mod, "GetFileVersionInfoSizeA");
    s_api.GetFileVersionInfoSizeW    = GetProcAddress(s_api.mod, "GetFileVersionInfoSizeW");
    s_api.GetFileVersionInfoSizeExA  = GetProcAddress(s_api.mod, "GetFileVersionInfoSizeExA");
    s_api.GetFileVersionInfoSizeExW  = GetProcAddress(s_api.mod, "GetFileVersionInfoSizeExW");
    s_api.VerFindFileA               = GetProcAddress(s_api.mod, "VerFindFileA");
    s_api.VerFindFileW               = GetProcAddress(s_api.mod, "VerFindFileW");
    s_api.VerInstallFileA            = GetProcAddress(s_api.mod, "VerInstallFileA");
    s_api.VerInstallFileW            = GetProcAddress(s_api.mod, "VerInstallFileW");
    s_api.VerLanguageNameA           = GetProcAddress(s_api.mod, "VerLanguageNameA");
    s_api.VerLanguageNameW           = GetProcAddress(s_api.mod, "VerLanguageNameW");
    s_api.VerQueryValueA             = GetProcAddress(s_api.mod, "VerQueryValueA");
    s_api.VerQueryValueW             = GetProcAddress(s_api.mod, "VerQueryValueW");
    return s_api.mod != NULL;
}


/* ------------------------------------------------------------------ */
/*  lazy resolution of the real version.dll                           */
/* ------------------------------------------------------------------ */
/*  History: only the proxy-only build called load_real_version(), from
 *  its own DllMain. The merged build (#ifdef ZL_MERGED) compiles that
 *  DllMain OUT and nothing else ever called it -- so s_api stayed all
 *  NULL and every exported version API returned 0 / FALSE. Measured:
 *  GetFileVersionInfoSizeW -> 0 for a file that exists. Any program
 *  that imports version.dll from the emulator folder would silently get
 *  "no version information" instead of a crash, which is worse because
 *  nothing reports it.
 *
 *  Now the real module is resolved exactly once, on whichever happens
 *  first: an exported call, or the worker thread that both lanes start.
 *  InitOnceExecuteOnce makes that race-free without a mutex.
 */
static INIT_ONCE g_apiOnce = INIT_ONCE_STATIC_INIT;
static BOOL CALLBACK version_api_once(PINIT_ONCE o, PVOID a, PVOID* b)
{ (void)o; (void)a; (void)b; load_real_version(); return TRUE; }

void zl_version_api_ready(void)   /* called from the worker thread */
{
    InitOnceExecuteOnce(&g_apiOnce, version_api_once, NULL, NULL);
}

static void zl_ensure_real(void)  /* called from every exported stub */
{
    if (s_api.mod) return;
    InitOnceExecuteOnce(&g_apiOnce, version_api_once, NULL, NULL);
}

/* ------------------------------------------------------------------ */
/*  exported proxy functions                                          */
/* ------------------------------------------------------------------ */
#pragma GCC diagnostic ignored "-Wunused-parameter"

ZLAG_EXPORT BOOL WINAPI GetFileVersionInfoA(LPCSTR a, DWORD b, DWORD c, LPVOID d)
{ zl_ensure_real(); return s_api.GetFileVersionInfoA ? ((BOOL(WINAPI*)(LPCSTR,DWORD,DWORD,LPVOID))s_api.GetFileVersionInfoA)(a,b,c,d) : FALSE; }

ZLAG_EXPORT BOOL WINAPI GetFileVersionInfoW(LPCWSTR a, DWORD b, DWORD c, LPVOID d)
{ zl_ensure_real(); return s_api.GetFileVersionInfoW ? ((BOOL(WINAPI*)(LPCWSTR,DWORD,DWORD,LPVOID))s_api.GetFileVersionInfoW)(a,b,c,d) : FALSE; }

ZLAG_EXPORT BOOL WINAPI GetFileVersionInfoExA(DWORD e, LPCSTR a, DWORD b, DWORD c, LPVOID d)
{ zl_ensure_real(); return s_api.GetFileVersionInfoExA ? ((BOOL(WINAPI*)(DWORD,LPCSTR,DWORD,DWORD,LPVOID))s_api.GetFileVersionInfoExA)(e,a,b,c,d) : FALSE; }

ZLAG_EXPORT BOOL WINAPI GetFileVersionInfoExW(DWORD e, LPCWSTR a, DWORD b, DWORD c, LPVOID d)
{ zl_ensure_real(); return s_api.GetFileVersionInfoExW ? ((BOOL(WINAPI*)(DWORD,LPCWSTR,DWORD,DWORD,LPVOID))s_api.GetFileVersionInfoExW)(e,a,b,c,d) : FALSE; }

ZLAG_EXPORT BOOL WINAPI GetFileVersionInfoByHandle(DWORD f, HANDLE h, DWORD a, DWORD b, LPVOID c)
{ zl_ensure_real(); return s_api.GetFileVersionInfoByHandle ? ((BOOL(WINAPI*)(DWORD,HANDLE,DWORD,DWORD,LPVOID))s_api.GetFileVersionInfoByHandle)(f,h,a,b,c) : FALSE; }

ZLAG_EXPORT DWORD WINAPI GetFileVersionInfoSizeA(LPCSTR a, LPDWORD b)
{ zl_boot_if_deferred(); zl_ensure_real();
  return s_api.GetFileVersionInfoSizeA ? ((DWORD(WINAPI*)(LPCSTR,LPDWORD))s_api.GetFileVersionInfoSizeA)(a,b) : 0; }

ZLAG_EXPORT DWORD WINAPI GetFileVersionInfoSizeW(LPCWSTR a, LPDWORD b)
{ zl_ensure_real(); return s_api.GetFileVersionInfoSizeW ? ((DWORD(WINAPI*)(LPCWSTR,LPDWORD))s_api.GetFileVersionInfoSizeW)(a,b) : 0; }

ZLAG_EXPORT DWORD WINAPI GetFileVersionInfoSizeExA(DWORD e, LPCSTR a, LPDWORD b)
{ zl_ensure_real(); return s_api.GetFileVersionInfoSizeExA ? ((DWORD(WINAPI*)(DWORD,LPCSTR,LPDWORD))s_api.GetFileVersionInfoSizeExA)(e,a,b) : 0; }

ZLAG_EXPORT DWORD WINAPI GetFileVersionInfoSizeExW(DWORD e, LPCWSTR a, LPDWORD b)
{ zl_ensure_real(); return s_api.GetFileVersionInfoSizeExW ? ((DWORD(WINAPI*)(DWORD,LPCWSTR,LPDWORD))s_api.GetFileVersionInfoSizeExW)(e,a,b) : 0; }

ZLAG_EXPORT DWORD WINAPI VerFindFileA(DWORD a, LPSTR b, LPSTR c, LPSTR d, LPSTR e, PUINT f, LPSTR g, PUINT h)
{ zl_ensure_real(); return s_api.VerFindFileA ? ((DWORD(WINAPI*)(DWORD,LPSTR,LPSTR,LPSTR,LPSTR,PUINT,LPSTR,PUINT))s_api.VerFindFileA)(a,b,c,d,e,f,g,h) : ERROR_CALL_NOT_IMPLEMENTED; }

ZLAG_EXPORT DWORD WINAPI VerFindFileW(DWORD a, LPWSTR b, LPWSTR c, LPWSTR d, LPWSTR e, PUINT f, LPWSTR g, PUINT h)
{ zl_ensure_real(); return s_api.VerFindFileW ? ((DWORD(WINAPI*)(DWORD,LPWSTR,LPWSTR,LPWSTR,LPWSTR,PUINT,LPWSTR,PUINT))s_api.VerFindFileW)(a,b,c,d,e,f,g,h) : ERROR_CALL_NOT_IMPLEMENTED; }

ZLAG_EXPORT DWORD WINAPI VerInstallFileA(DWORD a, LPSTR b, LPSTR c, LPSTR d, LPSTR e, LPSTR f, LPSTR g, PUINT h)
{ zl_ensure_real(); return s_api.VerInstallFileA ? ((DWORD(WINAPI*)(DWORD,LPSTR,LPSTR,LPSTR,LPSTR,LPSTR,LPSTR,PUINT))s_api.VerInstallFileA)(a,b,c,d,e,f,g,h) : ERROR_CALL_NOT_IMPLEMENTED; }

ZLAG_EXPORT DWORD WINAPI VerInstallFileW(DWORD a, LPWSTR b, LPWSTR c, LPWSTR d, LPWSTR e, LPWSTR f, LPWSTR g, PUINT h)
{ zl_ensure_real(); return s_api.VerInstallFileW ? ((DWORD(WINAPI*)(DWORD,LPWSTR,LPWSTR,LPWSTR,LPWSTR,LPWSTR,LPWSTR,PUINT))s_api.VerInstallFileW)(a,b,c,d,e,f,g,h) : ERROR_CALL_NOT_IMPLEMENTED; }

ZLAG_EXPORT DWORD WINAPI VerLanguageNameA(DWORD a, LPSTR b, DWORD c)
{ zl_ensure_real(); return s_api.VerLanguageNameA ? ((DWORD(WINAPI*)(DWORD,LPSTR,DWORD))s_api.VerLanguageNameA)(a,b,c) : 0; }

ZLAG_EXPORT DWORD WINAPI VerLanguageNameW(DWORD a, LPWSTR b, DWORD c)
{ zl_ensure_real(); return s_api.VerLanguageNameW ? ((DWORD(WINAPI*)(DWORD,LPWSTR,DWORD))s_api.VerLanguageNameW)(a,b,c) : 0; }

ZLAG_EXPORT BOOL WINAPI VerQueryValueA(LPCVOID a, LPCSTR b, LPVOID* c, PUINT d)
{ zl_boot_if_deferred(); zl_ensure_real();
  return s_api.VerQueryValueA ? ((BOOL(WINAPI*)(LPCVOID,LPCSTR,LPVOID*,PUINT))s_api.VerQueryValueA)(a,b,c,d) : FALSE; }

ZLAG_EXPORT BOOL WINAPI VerQueryValueW(LPCVOID a, LPCWSTR b, LPVOID* c, PUINT d)
{ zl_ensure_real(); return s_api.VerQueryValueW ? ((BOOL(WINAPI*)(LPCVOID,LPCWSTR,LPVOID*,PUINT))s_api.VerQueryValueW)(a,b,c,d) : FALSE; }

/* ------------------------------------------------------------------ */
/*  build-id probe: lets `version.dll --buildid` (or any PE reader)   */
/*  show exactly which build an injected copy is. Harmless in-process */
/*  because nothing calls it.                                         */
/* ------------------------------------------------------------------ */
ZLAG_EXPORT const char* ZLagBuildId(void) { return ZL_EMBEDDED_BUILD_ID; }
ZLAG_EXPORT const char* ZLagVersion(void) { return ZL_VER; }

/* ------------------------------------------------------------------ */
/*  Last-resort breadcrumb. If everything else fails there is no log to  */
/*  read, so this is what proves the DLL loaded at all.                  */
/* ------------------------------------------------------------------ */
static void write_load_beacon(const char* why)
{
    char path[MAX_PATH];
    zl_cfg_ini_path(path, MAX_PATH);              /* ...\zlag.ini        */
    char* p = strrchr(path, '\\');
    if (p) lstrcpynA(p + 1, "zlag-loaded.txt", MAX_PATH - (int)(p - path));
    else   lstrcpynA(path, "zlag-loaded.txt", MAX_PATH);

    FILE* f = fopen(path, "a");
    if (!f) return;
    fprintf(f, "[%lu] loaded  pid=%lu  %s  build=%s\r\n",
            (unsigned long)GetTickCount(),
            (unsigned long)GetCurrentProcessId(), why ? why : "", ZL_BUILD_ID);
    fclose(f);
}

/* Deferred start: called from the first proxied API call instead of
 * DllMain, for the hosts where CreateThread under the loader lock fails. */
void zl_boot_if_deferred(void)
{
    static LONG started = 0;
    if (!g_state.deferredStart) return;
    if (InterlockedExchange(&started, 1)) return;
    HANDLE h = CreateThread(NULL, 0, zlag_worker, NULL, 0, NULL);
    if (h) { CloseHandle(h); write_load_beacon("worker started from API call"); }
}

/* ------------------------------------------------------------------ */
/*  DllMain -- spawn and leave                                       */
/* ------------------------------------------------------------------ */
#ifndef ZL_MERGED
/* In the merged build DllMain lives in menuown.cpp: it has to distinguish
 * "the loader imported me" (proxy lane: start the overlay immediately) from
 * "Z-Lag.exe injected me" (external lane: wait for zlag_attach). Two
 * DllMains cannot link, and the proxy one cannot make that distinction. */
BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID reserved)
{
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
        /* NOTE: we never return FALSE here. Refusing the load would take the
         * *host process* down with us -- an emulator that fails to find
         * version.dll cannot even start. Worst case we serve neutral
         * return values (0 / FALSE) and the emulator keeps running. */
        write_load_beacon("DllMain");
        if (!load_real_version())
            write_load_beacon("WARNING: system version.dll not resolved");

        /* CreateThread from DllMain is legal, but the loader lock is held
         * and a thread that touches the loader before the process finishes
         * initialising can deadlock on some Windows builds. If the thread
         * cannot be created, fall back to starting from the first real API
         * call the host makes -- version.dll is imported for GetFileVersion
         * / VerQueryValue, so that happens immediately. */
        HANDLE h = CreateThread(NULL, 0, zlag_worker, NULL, 0, NULL);
        if (h) { CloseHandle(h); }
        else {
            write_load_beacon("CreateThread failed -- deferred start armed");
            InterlockedExchange(&g_state.deferredStart, 1);
        }
    } else if (reason == DLL_PROCESS_DETACH) {
        InterlockedExchange(&g_state.shuttingDown, 1);
    }
    return TRUE;
}
#endif /* !ZL_MERGED */

/* ------------------------------------------------------------------ */
/*  optional startup tweaks - kept deliberately small and reversible  */
/* ------------------------------------------------------------------ */
static void zlag_apply_runtime_fixes(void)
{
    /* If the host is running the classic Windows "timer resolution" ...
       no: not touching global timers. Just report. */
    zl_log(LOG_INFO, "%s", ZL_MSG_COPYRIGHT);
}
