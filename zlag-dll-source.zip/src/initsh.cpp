/* Optional, bounded Android animation tuning. The embedded script never
 * sources vendor code. Every guest command is scoped to a verified local
 * BlueStacks instance, and legacy scripts are never executed for restore. */
#include "common.h"
#include "init_sh.h"
#include "safe_adb.h"
#include <stdio.h>

#define ZL_DEV_SCRIPT  "/data/local/tmp/zlag_init.sh"
#define ZL_DEV_RESTORE "/data/local/tmp/zlag_safe_restore.sh"
#define ZL_DEV_BACKUP  "/data/local/tmp/zlag_safe_animation_v1"
#define ZL_DEV_HOOKDIR "/data/adb/service.d"
#define ZL_DEV_HOOK    ZL_DEV_HOOKDIR "/zlag_init.sh"

typedef struct ScriptResult {
    int applied, restored, noSnapshot, failed, hookOk, removed, deployOk;
    int hookPresent, safeScript, snapshotPresent;
} ScriptResult;

static void script_line(const char* line, void* opaque)
{
    ScriptResult* r = (ScriptResult*)opaque;
    if (strstr(line, "ZL-APPLIED")) r->applied = 1;
    if (strstr(line, "ZL-RESTORED")) r->restored = 1;
    if (strstr(line, "ZL-NO-SNAPSHOT")) r->noSnapshot = 1;
    if (strstr(line, "ZL-APPLY-FAILED") || strstr(line, "ZL-RESTORE-FAILED") ||
        strstr(line, "ZL-SNAPSHOT-FAILED") || strstr(line, "ZL-INVALID-SNAPSHOT") ||
        strstr(line, "ZL-BUSY")) r->failed = 1;
    if (strstr(line, "ZL-HOOK-OK")) r->hookOk = 1;
    if (strstr(line, "ZL-REMOVED")) r->removed = 1;
    if (strstr(line, "ZL-DEPLOY-OK")) r->deployOk = 1;
    if (strstr(line, "ZL-HOOK-PRESENT")) r->hookPresent = 1;
    if (strstr(line, "ZL-SAFE-SCRIPT")) r->safeScript = 1;
    if (strstr(line, "ZL-SNAPSHOT-PRESENT")) r->snapshotPresent = 1;
}

static int stage_script(char* host, DWORD size)
{
    char dir[MAX_PATH] = {0}, file[MAX_PATH] = {0};
    DWORD n = GetTempPathA(MAX_PATH, dir);
    if (!n || n >= MAX_PATH || !GetTempFileNameA(dir, "zls", 0, file)) {
        apply_log("[!!] could not prepare the temporary profile");
        return 0;
    }
    FILE* f = fopen(file, "wb");
    if (!f) { DeleteFileA(file); apply_log("[!!] could not prepare the profile"); return 0; }
    size_t written = fwrite(ZL_INITSH_TEXT, 1, ZL_INITSH_BYTES, f);
    int closeOk = fclose(f) == 0;
    if (written != ZL_INITSH_BYTES || !closeOk) {
        DeleteFileA(file);
        apply_log("[!!] profile preparation failed; nothing was sent");
        return 0;
    }
    lstrcpynA(host, file, size);
    return 1;
}

static int push_safe_script(const char* adb, const char* serial, const char* destination)
{
    char host[MAX_PATH] = {0}, args[768], next[256];
    int n = _snprintf(next, sizeof(next), "%s.new", destination);
    if (n < 0 || n >= (int)sizeof(next) || !stage_script(host, MAX_PATH)) return 0;
    n = _snprintf(args, sizeof(args), "push \"%s\" %s", host, next);
    int rc = (n < 0 || n >= (int)sizeof(args)) ? -4 :
             zl_safe_adb_call(adb, serial, args, NULL, NULL);
    DeleteFileA(host);
    if (rc != 0) {
        apply_log("[!!] could not send the safe profile; previous settings are unchanged");
        return 0;
    }
    n = _snprintf(args, sizeof(args),
        "shell \"test -s %s && mv -f %s %s && echo ZL-DEPLOY-OK\"",
        next, next, destination);
    ScriptResult r = {0};
    rc = (n < 0 || n >= (int)sizeof(args)) ? -4 :
         zl_safe_adb_call(adb, serial, args, script_line, &r);
    if (rc != 0 || !r.deployOk) {
        apply_log("[!!] could not confirm profile deployment; check instance permissions");
        return 0;
    }
    return 1;
}

static int apply_safe_script(const char* adb, const char* serial)
{
    ScriptResult r = {0};
    int rc = zl_safe_adb_call(adb, serial, "shell sh " ZL_DEV_SCRIPT " run", script_line, &r);
    if (rc == 0 && r.applied && !r.failed) {
        apply_log("[ok] UI animation scales set to 0.5x; original values were saved");
        return 1;
    }
    apply_log("[!!] animation tuning did not complete; check instance permissions");
    if (r.restored) apply_log("[i] saved animation values were restored after the failure");
    return 0;
}

static void restore_safe_script(const char* adb, const char* serial)
{
    if (!push_safe_script(adb, serial, ZL_DEV_RESTORE)) {
        apply_log("[!!] saved animation values could not be restored");
        return;
    }
    ScriptResult r = {0};
    int rc = zl_safe_adb_call(adb, serial, "shell sh " ZL_DEV_RESTORE " restore", script_line, &r);
    if (rc == 0 && r.restored && !r.failed)
        apply_log("[ok] the saved animation values were restored");
    else if (r.noSnapshot)
        apply_log("[i] no saved animation values; older settings were not guessed");
    else
        apply_log("[!!] animation restore failed; the saved values were kept");
    zl_safe_adb_call(adb, serial, "shell rm -f " ZL_DEV_RESTORE, NULL, NULL);
}

extern "C" void zl_initsh_run(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    apply_log("--- Gentle Android animation tuning ---");
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, sizeof(serial))) return;
    /* Never run a legacy script already on the instance. */
    if (!push_safe_script(adb, serial, ZL_DEV_SCRIPT)) return;
    apply_safe_script(adb, serial);
}

extern "C" void zl_initsh_install(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    apply_log("--- Optional animation profile at startup ---");
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, sizeof(serial))) return;
    if (!push_safe_script(adb, serial, ZL_DEV_SCRIPT)) return;
    if (!apply_safe_script(adb, serial)) return;

    /* Do not manufacture a service directory on an unsupported image.
     * Write a temporary file first so an existing hook is not truncated. */
    const char* command =
        "shell \"[ -d " ZL_DEV_HOOKDIR " ] && "
        "printf '#!/system/bin/sh\\nsh " ZL_DEV_SCRIPT " bootcomplete\\n' > " ZL_DEV_HOOK ".new && "
        "chmod 0755 " ZL_DEV_HOOK ".new && mv -f " ZL_DEV_HOOK ".new " ZL_DEV_HOOK " && "
        "echo ZL-HOOK-OK\"";
    ScriptResult r = {0};
    int rc = zl_safe_adb_call(adb, serial, command, script_line, &r);
    if (rc == 0 && r.hookOk)
        apply_log("[ok] startup hook written; automatic execution depends on instance support");
    else
        apply_log("[!!] startup hook was not installed; the current-session change still applies");
}

extern "C" void zl_initsh_restore_session(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    apply_log("--- Restore saved animation settings ---");
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, sizeof(serial))) return;
    restore_safe_script(adb, serial);
    apply_log("[i] an installed startup profile may reapply at the next instance start");
}

extern "C" void zl_initsh_uninstall(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    apply_log("--- Remove Android startup profile ---");
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, sizeof(serial))) return;
    restore_safe_script(adb, serial);
    ScriptResult r = {0};
    int rc = zl_safe_adb_call(adb, serial,
        "shell \"rm -f " ZL_DEV_HOOK " " ZL_DEV_HOOK ".new " ZL_DEV_SCRIPT
        " " ZL_DEV_RESTORE " && echo ZL-REMOVED\"", script_line, &r);
    if (rc == 0 && r.removed)
        apply_log("[ok] owned startup files removed");
    else
        apply_log("[!!] some startup files could not be removed; check permissions");
    apply_log("[i] older unsaved settings or property overrides are not automatically restored");
}

extern "C" void zl_initsh_status(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    apply_log("--- Android startup profile status ---");
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, sizeof(serial))) return;
    ScriptResult r = {0};
    int rc = zl_safe_adb_call(adb, serial,
        "shell \"if [ -f " ZL_DEV_HOOK " ]; then echo ZL-HOOK-PRESENT; fi; "
        "if grep -q ZL-APPLIED " ZL_DEV_SCRIPT " 2>/dev/null; then echo ZL-SAFE-SCRIPT; fi; "
        "if [ -f " ZL_DEV_BACKUP " ]; then echo ZL-SNAPSHOT-PRESENT; fi\"", script_line, &r);
    if (rc != 0) { apply_log("[!!] status could not be read"); return; }
    if (r.hookPresent && r.safeScript)
        apply_log("[i] safe startup hook is present; execution depends on instance support");
    else if (r.hookPresent)
        apply_log("[!!] an older startup hook may be present; remove or replace it explicitly");
    else
        apply_log("[i] no startup hook found");
    apply_log(r.snapshotPresent ? "[i] saved animation values are available" :
                                 "[i] no saved animation values found");
}
