/* =====================================================================
 *  roundwin.cpp -- rounded corners on the emulator's own window
 *
 *  Approach taken from the source: a rounded window region via
 *  CreateRoundRectRgn + SetWindowRgn, and no region at all while the
 *  window is maximised (rounding a full-screen surface only clips four
 *  corners of the game).
 *
 *  "Make it work regardless" is why this file looks like it does:
 *
 *  A host that draws into a child surface, or that sets its own region
 *  back whenever it changes state, will ignore a single one-shot call on
 *  the top-level frame. So this applies the same shape to every window
 *  that can carry it -- the root frame AND the render child, when that
 *  child is a real window of its own -- and re-asserts the region on a
 *  slow tick, because the host is free to reset it.
 *
 *  Still no WndProc subclassing. A window procedure that stops returning
 *  is the emulator freezing, and that is not a trade worth making for a
 *  cosmetic corner.
 * ===================================================================== */
#include <windows.h>
#include "common.h"
#include "dpi_scope.h"

#define RW_SLOTS 3

typedef struct {
    HWND hwnd;
    int  radius;
    int  w, h;
} rw_slot;

static rw_slot s_slot[RW_SLOTS];
static DWORD   s_lastReassert = 0;
static int     s_cleared = 0;
/* The host swap thread and the menu heartbeat can arrive concurrently. */
static volatile LONG s_busy = 0;
static int s_nativeDpi = 0; /* only accessed while s_busy is held */

class RoundGuard {
    bool acquired_;
public:
    RoundGuard() : acquired_(InterlockedCompareExchange(&s_busy, 1, 0) == 0) {}
    ~RoundGuard() { if (acquired_) InterlockedExchange(&s_busy, 0); }
    bool acquired() const { return acquired_; }
private:
    RoundGuard(const RoundGuard&);
    RoundGuard& operator=(const RoundGuard&);
};

/* GetWindowRect is DPI-virtualized for the calling thread, while a window
 * region is in device pixels. zl_round_tick normally enters a temporary
 * per-monitor-aware context before querying, so both sizes match. On older
 * Windows without per-thread awareness, use the per-window conversion when
 * available. The host's process DPI setting is never changed. */
static BOOL window_rect_pixels(HWND h, RECT* r)
{
    if (!GetWindowRect(h, r)) return FALSE;
    if (!s_nativeDpi) {
        typedef BOOL (WINAPI *ConvertPointFn)(HWND, LPPOINT);
        static ConvertPointFn convert = (ConvertPointFn)(void*)GetProcAddress(
            GetModuleHandleA("user32.dll"), "LogicalToPhysicalPointForPerMonitorDPI");
        if (!convert || r->right <= r->left || r->bottom <= r->top)
            return FALSE; /* do not risk clipping on an unknown DPI */
        /* Use interior points because some Windows builds reject points
         * exactly outside the rectangle's exclusive bottom/right. */
        POINT a = {r->left, r->top};
        POINT b = {r->right - 1, r->bottom - 1};
        if (!convert(h, &a) || !convert(h, &b)) return FALSE;
        r->left = a.x; r->top = a.y;
        r->right = b.x + 2; r->bottom = b.y + 2;
    }
    return TRUE;
}

static void slot_forget(int i)
{
    s_slot[i].hwnd   = NULL;
    s_slot[i].radius = 0;
    s_slot[i].w      = 0;
    s_slot[i].h      = 0;
}

static int slot_find(HWND h)
{
    int i;
    for (i = 0; i < RW_SLOTS; i++)
        if (s_slot[i].hwnd == h) return i;
    return -1;
}

static int slot_free(void)
{
    int i;
    for (i = 0; i < RW_SLOTS; i++)
        if (!s_slot[i].hwnd) return i;
    /* none free: take the oldest */
    return 0;
}

static void clear_all(void)
{
    int i;
    for (i = 0; i < RW_SLOTS; i++) {
        if (s_slot[i].hwnd && IsWindow(s_slot[i].hwnd))
            SetWindowRgn(s_slot[i].hwnd, NULL, TRUE);
        slot_forget(i);
    }
}

/* Apply (or re-apply) one window. Returns 1 when the shape is in place. */
static int shape_one(HWND h, int radius)
{
    RECT r;
    int  cw, ch, i;
    HRGN rgn;

    if (!h || !IsWindow(h) || !IsWindowVisible(h)) return 0;

    if (IsZoomed(h) || IsIconic(h)) {
        i = slot_find(h);
        if (i >= 0) { SetWindowRgn(h, NULL, TRUE); slot_forget(i); }
        return 0;
    }

    if (!window_rect_pixels(h, &r)) {
        /* Drop any stale region rather than clip a window at unknown DPI. */
        i = slot_find(h);
        if (i >= 0) { SetWindowRgn(h, NULL, TRUE); slot_forget(i); }
        return 0;
    }
    cw = r.right - r.left;
    ch = r.bottom - r.top;
    if (cw <= 0 || ch <= 0 || cw > 16384 || ch > 16384) return 0;

    /* +1 on each side: CreateRoundRectRgn excludes the right/bottom edge,
     * and one pixel short leaves a hairline of the old square corner. */
    rgn = CreateRoundRectRgn(0, 0, cw + 1, ch + 1, radius, radius);
    if (!rgn) return 0;
    if (!SetWindowRgn(h, rgn, TRUE)) { DeleteObject(rgn); return 0; }

    i = slot_find(h);
    if (i < 0) i = slot_free();
    s_slot[i].hwnd   = h;
    s_slot[i].radius = radius;
    s_slot[i].w      = cw;
    s_slot[i].h      = ch;
    return 1;
}

/* Is this child worth shaping? Only if it is the surface we render into,
 * or big enough that it is the picture rather than a toolbar. */
static int child_is_surface(HWND child, HWND dcwin)
{
    RECT cr, rr;
    if (!child || !IsWindow(child)) return 0;
    if (child == dcwin) return 1;
    if (!window_rect_pixels(child, &cr)) return 0;
    if (!window_rect_pixels(GetAncestor(child, GA_ROOT), &rr)) return 0;
    {
        int cwid = cr.right - cr.left, chgt = cr.bottom - cr.top;
        int rwid = rr.right - rr.left, rhgt = rr.bottom - rr.top;
        if (cwid <= 0 || chgt <= 0 || rwid <= 0 || rhgt <= 0) return 0;
        /* at least 40% of the frame in both directions: that is the game */
        return (cwid * 10 >= rwid * 4) && (chgt * 10 >= rhgt * 4);
    }
}

/* ------------------------------------------------------------------ */
/*  finding the host window when there is no DC to ask                */
/*                                                                     */
/*  The EGL lane has no HDC at all -- eglSwapBuffers is handed a display */
/*  and a surface -- so asking WindowFromDC there returns nothing and   */
/*  the corners never went on. BlueStacks runs ANGLE, so that was the   */
/*  normal case, not the exception. The host is found by enumeration    */
/*  instead: biggest visible top-level window owned by this process,    */
/*  with BlueStacks' own class preferred and our panel excluded.        */
/* ------------------------------------------------------------------ */
typedef struct { HWND best; HWND bestBS; long bestArea; long bestBSArea; } host_scan;

static BOOL CALLBACK host_enum(HWND h, LPARAM lp)
{
    host_scan* sc = (host_scan*)lp;
    DWORD pid = 0;
    char  cls[128];
    RECT  r;
    long  area;

    GetWindowThreadProcessId(h, &pid);
    if (pid != GetCurrentProcessId()) return TRUE;
    if (!IsWindowVisible(h)) return TRUE;
    if (GetWindow(h, GW_OWNER)) return TRUE;          /* owned popups */
    GetClassNameA(h, cls, sizeof(cls));
    if (strstr(cls, "ZLag")) return TRUE;             /* our own panel */
    if (strstr(cls, "Z-Lag") || strstr(cls, "ZLAG")) return TRUE;

    if (!window_rect_pixels(h, &r)) return TRUE;
    area = (long)(r.right - r.left) * (long)(r.bottom - r.top);
    if (area <= 0) return TRUE;

    if (strstr(cls, "BlueStacks") || strstr(cls, "HD-Player") || strstr(cls, "HDPlayer")) {
        if (area > sc->bestBSArea) { sc->bestBSArea = area; sc->bestBS = h; }
    }
    if (area > sc->bestArea) { sc->bestArea = area; sc->best = h; }
    return TRUE;
}

static HWND find_host(void)
{
    static HWND s_cached = NULL;
    static DWORD s_when = 0;
    DWORD now = GetTickCount();

    if (s_cached && IsWindow(s_cached) && IsWindowVisible(s_cached) &&
        s_when && now - s_when < 1500)
        return s_cached;

    {
        host_scan sc;
        sc.best = sc.bestBS = NULL;
        sc.bestArea = sc.bestBSArea = 0;
        EnumWindows(host_enum, (LPARAM)&sc);
        s_cached = sc.bestBS ? sc.bestBS : sc.best;
        s_when = now;
    }
    return s_cached;
}

void zl_round_tick(HDC hdc)
{
    RoundGuard guard;
    if (!guard.acquired()) return; /* never block the emulator render thread */

    HWND w, root, kid;
    int radius = g_cfg.roundRadius;
    int need = 0, i;
    DWORD now;

    if (radius < 0) radius = 0;
    if (radius > 40) radius = 40;
    if (radius > 0 && radius < 4) radius = 4;
    if (radius == 0) {
        if (!s_cleared) {
            clear_all(); s_cleared = 1;
            zl_log(LOG_INFO, "window corners: off");
        }
        return;
    }
    s_cleared = 0;

    /* Both the menu heartbeat and the render tick use exactly the same
     * physical coordinate system. The render thread's previous DPI context
     * is restored on return; no process-wide awareness is modified. */
    ZLNativeDpiScope dpi;
    s_nativeDpi = dpi.active() ? 1 : 0;
    w = hdc ? WindowFromDC(hdc) : NULL;
    if (!w) w = find_host();
    root = w ? GetAncestor(w, GA_ROOT) : NULL;
    if (!root) root = w;
    if (!root) {
        clear_all(); /* never leave a stale clipping region behind */
        static int warned = 0;
        if (!warned) { warned = 1; zl_log(LOG_WARN, "window corners: no host window found yet"); }
        return;
    }

    /* A maximized/minimized host must not be cropped at the corners. */
    if (IsZoomed(root) || IsIconic(root)) {
        clear_all();
        return;
    }

    /* The top-level frame. */
    i = slot_find(root);
    if (i < 0 || s_slot[i].radius != radius) need = 1;
    else {
        RECT r;
        if (!window_rect_pixels(root, &r) ||
            s_slot[i].w != r.right - r.left || s_slot[i].h != r.bottom - r.top)
            need = 1;
    }

    /* The renderer may be a separate child HWND. */
    kid = NULL;
    if (w && w != root) kid = w;
    else {
        HWND c = GetWindow(root, GW_CHILD);
        while (c) {
            if (child_is_surface(c, w)) { kid = c; break; }
            c = GetWindow(c, GW_HWNDNEXT);
        }
    }
    if (kid && kid != root && IsWindowVisible(kid)) {
        RECT r;
        i = slot_find(kid);
        if (i < 0 || s_slot[i].radius != radius ||
            !window_rect_pixels(kid, &r) ||
            s_slot[i].w != r.right - r.left || s_slot[i].h != r.bottom - r.top)
            need = 1;
    }

    /* Reapply if BlueStacks resets its window region. */
    now = GetTickCount();
    if (!s_lastReassert || now - s_lastReassert > 2000) {
        s_lastReassert = now;
        need = 1;
    }
    if (need) {
        shape_one(root, radius);
        if (kid && kid != root) shape_one(kid, radius);
        if (slot_find(root) < 0)
            zl_log(LOG_WARN, "window corners: host did not accept the region");
    }
}

void zl_round_reset(void)
{
    g_cfg.roundRadius = 0;
    RoundGuard guard;
    if (guard.acquired()) { clear_all(); s_cleared = 1; }
    /* If another thread is shaping right now, its next tick clears it. */
    zl_log(LOG_INFO, "window corners: reset to square");
}
