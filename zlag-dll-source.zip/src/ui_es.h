/* ui_es.h -- ImGui renderer for GLES2/GL2. works in ANGLE and native GLES. */
#ifndef ZLAG_UI_ES_H
#define ZLAG_UI_ES_H
#include "imgui.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Font size, one knob.
 *
 * The stock ImGui font is a 7 px bitmap. Scaled up it goes to mush, so the
 * atlas is rasterised larger and the shader scales it back: same glyphs,
 * more samples, legible at 1080p and above.
 *
 * Set ZL_FONT_SUPERSAMPLE to 1.0f for the old tiny font. */
#define ZL_FONT_SUPERSAMPLE 2.0f
#define ZL_FONT_BASE_PX     13.0f

int  zlui_es_init(void);
void zlui_es_new_frame(void);
void zlui_es_render(ImDrawData* dd);
void zlui_es_shutdown(void);
#ifdef __cplusplus
}
#endif
#endif
