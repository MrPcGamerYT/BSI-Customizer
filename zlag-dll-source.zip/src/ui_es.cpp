/* =====================================================================
 *  ui_es.cpp  --  ImGui renderer that works in *every* BlueStacks context.
 *
 *  The stock ImGui OpenGL2 backend uses fixed-function pipeline calls
 *  (glMatrixMode, glOrtho, glVertexPointer, glEnableClientState,
 *  glTexEnvi, glPolygonMode). BlueStacks renders through ANGLE / native
 *  GLES, where NONE of those exist -- which is exactly why the panel
 *  could not draw inside the emulator even though the post-process
 *  shaders worked.
 *
 *  This backend is written against the GLES2 / GL2.0 common subset:
 *    - one shader pair (aPos/aUV/aCol -> vCol * texture2D)
 *    - vertex arrays via glVertexAttribPointer (no client states)
 *    - a dynamic VBO + index buffer (no glBegin/glEnd)
 *    - clip rects via scissor
 *  It therefore runs unchanged on:
 *    desktop GL 2.0+  |  ANGLE  |  native GLES2  |  Mesa softpipe
 *
 *  Shaders deliberately carry no "#version" and use the GL_ES precision
 *  guard, exactly like the post-process chain.
 * ===================================================================== */
extern "C" {
#include "common.h"
}
#include "imgui.h"
#include "ui_es.h"

extern "C" {
#include "gl_loader.h"
}

#include <string.h>

/* ------------------------------------------------------------------ */
static GLuint s_prog = 0, s_vbo = 0, s_ibo = 0, s_fontTex = 0;
static GLint  s_uTex = -1, s_uScale = -1, s_uOffset = -1;
static GLint  s_aPos = -1, s_aUV = -1, s_aCol = -1;
static int    s_vboCap = 0, s_iboCap = 0;
static int    s_inited = 0;

static const char* UI_VS =
"#ifdef GL_ES\n"
"precision highp float;\n"
"#endif\n"
"attribute vec2 aPos;\n"
"attribute vec2 aUV;\n"
"attribute vec4 aCol;\n"
"uniform vec2 uScale;\n"
"uniform vec2 uOffset;\n"
"varying vec2 vUV;\n"
"varying vec4 vCol;\n"
"void main(){\n"
"  vUV = aUV;\n"
"  vCol = aCol;\n"
"  gl_Position = vec4(aPos * uScale + uOffset, 0.0, 1.0);\n"
"}\n";

static const char* UI_FS =
"#ifdef GL_ES\n"
"precision mediump float;\n"
"#endif\n"
"uniform sampler2D uTex;\n"
"varying vec2 vUV;\n"
"varying vec4 vCol;\n"
"void main(){\n"
"  gl_FragColor = vCol * texture2D(uTex, vUV);\n"
"}\n";

/* ------------------------------------------------------------------ */
static GLuint comp(GLenum type, const char* src)
{
    GLuint sh = zgl.glCreateShader(type);
    if (!sh) return 0;
    zgl.glShaderSource(sh, 1, &src, NULL);
    zgl.glCompileShader(sh);
    GLint ok = 0;
    zgl.glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024] = {0};
        zgl.glGetShaderInfoLog(sh, sizeof(log) - 1, NULL, log);
        zl_log(LOG_ERR, "ui shader failed: %s", log);
        zgl.glDeleteShader(sh);
        return 0;
    }
    return sh;
}

int zlui_es_init(void)
{
    if (s_inited) return 1;
    if (!zgl_have()) return 0;

    GLuint vs = comp(GL_VERTEX_SHADER, UI_VS);
    GLuint fs = comp(GL_FRAGMENT_SHADER, UI_FS);
    if (!vs || !fs) return 0;

    s_prog = zgl.glCreateProgram();
    zgl.glAttachShader(s_prog, vs);
    zgl.glAttachShader(s_prog, fs);
    zgl.glBindAttribLocation(s_prog, 0, "aPos");
    zgl.glBindAttribLocation(s_prog, 1, "aUV");
    zgl.glBindAttribLocation(s_prog, 2, "aCol");
    zgl.glLinkProgram(s_prog);
    GLint ok = 0;
    zgl.glGetProgramiv(s_prog, GL_LINK_STATUS, &ok);
    zgl.glDeleteShader(vs);
    zgl.glDeleteShader(fs);
    if (!ok) {
        char log[1024] = {0};
        zgl.glGetProgramInfoLog(s_prog, sizeof(log) - 1, NULL, log);
        zl_log(LOG_ERR, "ui program link failed: %s", log);
        return 0;
    }

    s_uTex    = zgl.glGetUniformLocation(s_prog, "uTex");
    s_uScale  = zgl.glGetUniformLocation(s_prog, "uScale");
    s_uOffset = zgl.glGetUniformLocation(s_prog, "uOffset");
    s_aPos    = 0; s_aUV = 1; s_aCol = 2;

    /* The ImGui font atlas is a fixed 7 px bitmap font. Scaled up it turns
     * to mush, which is why the small labels are hard to read at 1080p and
     * up. Rasterise the atlas at a larger size once and let the shader's
     * existing scale put it back to 1 UI unit: same code path, glyphs that
     * survive being made bigger. */
    {
        ImGuiIO& io = ImGui::GetIO();
        const float k = ZL_FONT_SUPERSAMPLE;
        if (k > 1.01f) {
            ImFontConfig cfg;
            cfg.SizePixels  = ZL_FONT_BASE_PX * k;
            cfg.OversampleH = 2;
            cfg.OversampleV = 2;
            cfg.PixelSnapH  = false;
            io.Fonts->AddFontDefault(&cfg);
            io.FontGlobalScale = 1.0f / k;   /* draw at the original size */
            zl_log(LOG_INFO, "font atlas rasterised at %.0f px (x%.1f supersample)",
                   ZL_FONT_BASE_PX * k, k);
        }
    }

    zgl.glGenBuffers(1, &s_vbo);
    zgl.glGenBuffers(1, &s_ibo);

    /* font texture is created later by create_font_texture() */
    s_inited = 1;
    zl_log(LOG_OK, "UI backend ready (GLES2/GL2 shader path, no fixed-function)");
    return 1;
}

/* ------------------------------------------------------------------ */
int zlui_es_create_font_texture(void)
{
    if (!s_inited) return 0;
    unsigned char* px = NULL;
    int w = 0, h = 0;
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->GetTexDataAsRGBA32(&px, &w, &h);
    if (!px || !w || !h) return 0;

    zgl.glGenTextures(1, &s_fontTex);
    zgl.glBindTexture(GL_TEXTURE_2D, s_fontTex);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    zgl.glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    zgl.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                     GL_UNSIGNED_BYTE, px);
    io.Fonts->SetTexID((ImTextureID)(intptr_t)s_fontTex);
    io.Fonts->ClearTexData();
    return 1;
}

/* ------------------------------------------------------------------ */
void zlui_es_new_frame(void)
{
    ImGuiIO& io = ImGui::GetIO();
    if (!s_fontTex) zlui_es_create_font_texture();
    (void)io;
}

/* ------------------------------------------------------------------ */
static void grow_buffers(int vtxBytes, int idxBytes)
{
    if (vtxBytes > s_vboCap) {
        zgl.glBindBuffer(GL_ARRAY_BUFFER, s_vbo);
        zgl.glBufferData(GL_ARRAY_BUFFER, vtxBytes, NULL, GL_STREAM_DRAW);
        s_vboCap = vtxBytes;
    }
    if (idxBytes > s_iboCap) {
        zgl.glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, s_ibo);
        zgl.glBufferData(GL_ELEMENT_ARRAY_BUFFER, idxBytes, NULL, GL_STREAM_DRAW);
        s_iboCap = idxBytes;
    }
}

void zlui_es_render(ImDrawData* dd)
{
    if (!s_inited || !dd || dd->CmdListsCount <= 0) return;
    if (!s_fontTex && !zlui_es_create_font_texture()) return;
    int drewSomething = 0;

    ImGuiIO& io = ImGui::GetIO();
    int fbW = (int)(dd->DisplaySize.x * dd->FramebufferScale.x);
    int fbH = (int)(dd->DisplaySize.y * dd->FramebufferScale.y);
    if (fbW <= 0 || fbH <= 0) return;

    /* --- save the host state we are about to stomp on ---------------- */
    GLint lastProg = 0, lastTex = 0, lastVp[4] = {0}, lastScissor[4] = {0};
    zgl.glGetIntegerv(GL_CURRENT_PROGRAM, &lastProg);
    zgl.glActiveTexture(GL_TEXTURE0);
    zgl.glGetIntegerv(GL_TEXTURE_BINDING_2D, &lastTex);
    zgl.glGetIntegerv(GL_VIEWPORT, lastVp);
    zgl.glGetIntegerv(0x0C10 /*GL_SCISSOR_BOX*/, lastScissor);
    unsigned char blend   = zgl.glIsEnabled(GL_BLEND);
    unsigned char cull    = zgl.glIsEnabled(GL_CULL_FACE);
    unsigned char depth   = zgl.glIsEnabled(GL_DEPTH_TEST);
    unsigned char scissor = zgl.glIsEnabled(GL_SCISSOR_TEST);

    zgl.glEnable(GL_BLEND);
    zgl.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    zgl.glDisable(GL_CULL_FACE);
    zgl.glDisable(GL_DEPTH_TEST);

    /* Scissor OFF for the whole surface before anything is drawn. The
     * per-command scissor below enables it again where it is needed; if the
     * host left a small scissor rect behind, ImGui's commands would be
     * clipped into that rect and the overlay would be invisible while every
     * counter said it was rendering. */
    zgl.glDisable(GL_SCISSOR_TEST);
    zgl.glViewport(0, 0, fbW, fbH);
    zgl.glUseProgram(s_prog);
    if (s_uTex >= 0) zgl.glUniform1i(s_uTex, 0);
    float L = dd->DisplayPos.x,  T = dd->DisplayPos.y;
    float R = L + dd->DisplaySize.x, B = T + dd->DisplaySize.y;
    if (s_uScale >= 0)  zgl.glUniform2f(s_uScale, 2.0f / (R - L), 2.0f / (T - B));
    if (s_uOffset >= 0) zgl.glUniform2f(s_uOffset, (R + L) / (L - R), (T + B) / (B - T));
    zgl.glActiveTexture(GL_TEXTURE0);
    zgl.glBindTexture(GL_TEXTURE_2D, s_fontTex);

    for (int n = 0; n < dd->CmdListsCount; n++) {
        const ImDrawList* cl = dd->CmdLists[n];
        int vtxBytes = (int)(cl->VtxBuffer.Size * (int)sizeof(ImDrawVert));
        int idxBytes = (int)(cl->IdxBuffer.Size * (int)sizeof(ImDrawIdx));
        grow_buffers(vtxBytes, idxBytes);

        zgl.glBindBuffer(GL_ARRAY_BUFFER, s_vbo);
        zgl.glBufferSubData(GL_ARRAY_BUFFER, 0, vtxBytes, cl->VtxBuffer.Data);
        zgl.glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, s_ibo);
        zgl.glBufferSubData(GL_ELEMENT_ARRAY_BUFFER, 0, idxBytes, cl->IdxBuffer.Data);

        zgl.glEnableVertexAttribArray(s_aPos);
        zgl.glEnableVertexAttribArray(s_aUV);
        zgl.glEnableVertexAttribArray(s_aCol);
        zgl.glVertexAttribPointer(s_aPos, 2, GL_FLOAT, GL_FALSE,
                                  sizeof(ImDrawVert), (void*)offsetof(ImDrawVert, pos));
        zgl.glVertexAttribPointer(s_aUV, 2, GL_FLOAT, GL_FALSE,
                                  sizeof(ImDrawVert), (void*)offsetof(ImDrawVert, uv));
        zgl.glVertexAttribPointer(s_aCol, 4, GL_UNSIGNED_BYTE, GL_TRUE,
                                  sizeof(ImDrawVert), (void*)offsetof(ImDrawVert, col));

        for (int c = 0; c < cl->CmdBuffer.Size; c++) {
            const ImDrawCmd* cmd = &cl->CmdBuffer[c];
            if (cmd->UserCallback) { cmd->UserCallback(cl, cmd); continue; }
            if (cmd->ElemCount == 0) continue;

            float cx = cmd->ClipRect.x - L, cy = cmd->ClipRect.y - T;
            float cw = cmd->ClipRect.z - cmd->ClipRect.x;
            float ch = cmd->ClipRect.w - cmd->ClipRect.y;
            if (cw <= 0.0f || ch <= 0.0f) continue;
            zgl.glScissor((GLint)cx, (GLint)(fbH - (cy + ch)), (GLsizei)cw, (GLsizei)ch);

            zgl.glDrawElements(GL_TRIANGLES, (GLsizei)cmd->ElemCount,
                               GL_UNSIGNED_SHORT,
                               (void*)(intptr_t)(cmd->IdxOffset * sizeof(ImDrawIdx)));
            drewSomething = 1;
        }
        zgl.glDisableVertexAttribArray(s_aPos);
        zgl.glDisableVertexAttribArray(s_aUV);
        zgl.glDisableVertexAttribArray(s_aCol);
    }

    /* Nothing was drawn: say so instead of reporting a healthy frame.
     * This is how "it renders but nobody sees it" gets caught. */
    if (!drewSomething) {
        InterlockedIncrement(&g_state.uiFails);
        if (g_state.uiFailLog < 40) {
            zl_log(LOG_WARN, "overlay produced no vertices (empty or fully clipped)");
            g_state.uiFailLog++;
        }
    }

    /* --- give the context back exactly as we found it ---------------- */
    zgl.glUseProgram((GLuint)lastProg);
    zgl.glBindTexture(GL_TEXTURE_2D, (GLuint)lastTex);
    zgl.glBindBuffer(GL_ARRAY_BUFFER, 0);
    zgl.glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    zgl.glViewport(lastVp[0], lastVp[1], lastVp[2], lastVp[3]);
    zgl.glScissor(lastScissor[0], lastScissor[1], lastScissor[2], lastScissor[3]);
    if (!blend)   zgl.glDisable(GL_BLEND);        else zgl.glEnable(GL_BLEND);
    if (cull)     zgl.glEnable(GL_CULL_FACE);     else zgl.glDisable(GL_CULL_FACE);
    if (depth)    zgl.glEnable(GL_DEPTH_TEST);    else zgl.glDisable(GL_DEPTH_TEST);
    if (!scissor) zgl.glDisable(GL_SCISSOR_TEST); else zgl.glEnable(GL_SCISSOR_TEST);
    zgl.glActiveTexture(GL_TEXTURE0);
    (void)io;
}

void zlui_es_shutdown(void)
{
    if (!s_inited) return;
    if (s_vbo) { zgl.glDeleteBuffers(1, &s_vbo); s_vbo = 0; }
    if (s_ibo) { zgl.glDeleteBuffers(1, &s_ibo); s_ibo = 0; }
    if (s_fontTex) { zgl.glDeleteTextures(1, &s_fontTex); s_fontTex = 0; }
    if (s_prog) { zgl.glDeleteProgram(s_prog); s_prog = 0; }
    s_inited = 0; s_vboCap = s_iboCap = 0;
}
