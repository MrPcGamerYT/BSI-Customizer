/* ==================================================================
 *  fpsmul.c -- the cosmetic display multiplier
 *
 *  WHAT THIS IS
 *  A hook on ucrtbase's __stdio_common_vsprintf. When the caller is
 *  formatting a string that contains "FPS" followed by a number, the
 *  number in the OUTPUT is rewritten. Nothing else is touched.
 *
 *  WHY THE DECOMPILED VERSION IS NOT USED
 *  It rewrote the va_list itself:
 *      orig(opts, buf, n, fmt, loc, reinterpret_cast<va_list>(&one_int))
 *  On x64 a va_list is a pointer to the caller's argument area, not an
 *  int. Handing it the address of a single int means the very next
 *  conversion in that format string reads whatever follows on the stack
 *  -- a %s there is a garbage pointer, and that is a crash. It also
 *  never restored the original argument, so every later read was wrong.
 *
 *  This version calls the original with the caller's real argument list
 *  and edits the finished text instead. The only thing that can go
 *  wrong is a number being written wrong, never a bad pointer read.
 *
 *  WHAT IT DOES NOT DO
 *  It does not add frames. The frame timer in this panel counts real
 *  swaps and is never passed through this path: that number stays true
 *  whatever this setting says.
 * ================================================================== */
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "common.h"
#include "MinHook.h"

typedef int (__cdecl *fn_scvs)(unsigned __int64 options, char* buffer,
                               size_t count, const char* format,
                               void* locale, va_list arglist);

static fn_scvs o_scvs = NULL;
static int s_installed = 0;

/* Our own logging formats strings too. Without this, writing the log
 * line that says "multiplier on" would re-enter the hook.
 *
 * GCC ignores __declspec(thread) -- it warns and hands back a plain
 * global, which is exactly the sort of silent downgrade this project
 * keeps getting bitten by -- so the compiler decides. */
#if defined(_MSC_VER)
#  define ZL_TLS __declspec(thread)
#else
#  define ZL_TLS __thread
#endif
static ZL_TLS int s_busy = 0;

/* ------------------------------------------------------------------ */
/*  the text edit                                                      */
/* ------------------------------------------------------------------ */
static int digits_of(long v)
{
    int n = 1;
    while (v >= 10) { v /= 10; n++; }
    return n;
}

static void scale_in_place(char* buf, size_t cap, int pct)
{
    char* p = buf;

    while (p && *p) {
        char* hit = NULL;
        char  c1 = 0;

        /* case-insensitive search for "fps" without pulling in a locale */
        {
            char* q = p;
            while (*q) {
                if ((q[0] == 'F' || q[0] == 'f') &&
                    (q[1] == 'P' || q[1] == 'p') &&
                    (q[2] == 'S' || q[2] == 's')) { hit = q; break; }
                q++;
            }
        }
        if (!hit) return;
        c1 = hit[3];
        (void)c1;

        /* the number: first run of digits within the next few characters,
         * allowing "FPS: 60", "FPS 60", "fps=60", "FPS 60%", "(60 FPS)" is
         * not matched by this scan and is left alone on purpose -- editing
         * a number that appears BEFORE the word is how you rewrite a
         * resolution or a frame time by mistake. */
        {
            char* q = hit + 3;
            int   hops = 0;
            while (*q && hops < 6 && !(*q >= '0' && *q <= '9')) { q++; hops++; }

            if (*q >= '0' && *q <= '9') {
                char* end = q;
                long  v, nv;
                int   need, have;

                while (*end >= '0' && *end <= '9') end++;
                v = strtol(q, NULL, 10);

                if (v > 0 && v < 100000) {
                    nv = (long)((v * (long)pct + 50) / 100);
                    need = digits_of(nv);
                    have = (int)(end - q);

                    if (need <= have) {
                        /* shorter or equal: write padded, keep the tail */
                        char tmp[16];
                        int  w = _snprintf(tmp, sizeof(tmp), "%ld", nv);
                        int  i;
                        for (i = 0; i < have; i++)
                            q[i] = (i < w) ? tmp[i] : ' ';
                    } else if (strlen(buf) + (size_t)(need - have) + 1 < cap) {
                        /* longer: shift the tail right first */
                        size_t tail = strlen(end) + 1;
                        memmove(q + need, end, tail);
                        {
                            char tmp[16];
                            int  w = _snprintf(tmp, sizeof(tmp), "%ld", nv);
                            int  i;
                            for (i = 0; i < w && i < need; i++) q[i] = tmp[i];
                        }
                    }
                }
                p = end;
                continue;
            }
        }
        p = hit + 3;
    }
}

/* ------------------------------------------------------------------ */
/*  hook                                                               */
/* ------------------------------------------------------------------ */
static int __cdecl hk_scvs(unsigned __int64 options, char* buffer,
                           size_t count, const char* format,
                           void* locale, va_list arglist)
{
    int pct = (int)g_cfg.fpsMulPct;
    int r;

    if (s_busy || !o_scvs) {
        if (!o_scvs) return 0;
        return o_scvs(options, buffer, count, format, locale, arglist);
    }

    r = o_scvs(options, buffer, count, format, locale, arglist);

    /* Only post-process when it worked, when there is a buffer, and when
     * the caller asked for a multiplier at all. */
    if (pct > 0 && pct != 100 && r > 0 && buffer && count > 0 &&
        format && (strstr(format, "FPS") || strstr(format, "fps") ||
                   strstr(format, "Fps"))) {
        s_busy = 1;
        scale_in_place(buffer, count, pct);
        s_busy = 0;
    }
    return r;
}

/* ------------------------------------------------------------------ */
/*  install / uninstall                                                */
/* ------------------------------------------------------------------ */
void zl_fpsmul_install(void)
{
    HMODULE h;
    FARPROC target;

    if (s_installed) return;
    if (!g_cfg.fpsMulPct || g_cfg.fpsMulPct == 100) return;

    MH_Initialize();          /* already-initialised is fine and expected */

    h = GetModuleHandleA("ucrtbase.dll");
    if (!h) h = GetModuleHandleA("msvcrt.dll");
    if (!h) return;

    target = GetProcAddress(h, "__stdio_common_vsprintf");
    if (!target) return;

    if (MH_CreateHook((void*)target, (void*)&hk_scvs, (void**)&o_scvs) == MH_OK &&
        MH_EnableHook((void*)target) == MH_OK) {
        s_installed = 1;
        zl_log(LOG_WARN, "display multiplier %d%% installed -- cosmetic only, "
                         "the panel's own counter is untouched", g_cfg.fpsMulPct);
    } else {
        zl_log(LOG_ERR, "display multiplier: hook refused");
    }
}

void zl_fpsmul_remove(void)
{
    HMODULE h;
    FARPROC target;

    if (!s_installed) return;
    h = GetModuleHandleA("ucrtbase.dll");
    if (!h) h = GetModuleHandleA("msvcrt.dll");
    if (h) {
        target = GetProcAddress(h, "__stdio_common_vsprintf");
        if (target) MH_DisableHook((void*)target);
    }
    s_installed = 0;
    zl_log(LOG_INFO, "display multiplier off");
}

/* Applied from the panel: turn it on or off without a restart. */
void zl_fpsmul_apply(void)
{
    if (g_cfg.fpsMulPct > 0 && g_cfg.fpsMulPct != 100) zl_fpsmul_install();
    else                                                    zl_fpsmul_remove();
}

int zl_fpsmul_state(void) { return s_installed; }
