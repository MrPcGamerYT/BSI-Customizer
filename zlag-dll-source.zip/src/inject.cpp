/* =====================================================================
 *  inject.cpp  --  Z-Lag.exe
 *
 *  There is no proxy DLL any more. This program finds the emulator, puts
 *  Z-Lag.dll inside it, and asks it to attach. Nothing is written to the
 *  emulator's folder and nothing is renamed.
 *
 *    Z-Lag.exe               attach to a running emulator
 *    Z-Lag.exe --wait        start with BlueStacks and wait for it
 *    Z-Lag.exe --launch      start the emulator first, then attach
 * ===================================================================== */
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

static const char* kTargets[] = {
    "HD-Player.exe",     /* BlueStacks 5 */
    "HD-Player.exe ",
    "MEmu.exe", "Nox.exe", "LdVBox.exe", NULL
};

static void say(const char* fmt, ...) __attribute__((format(printf,1,2)));
static FILE* s_log = NULL;

static void logline(const char* fmt, ...) __attribute__((format(printf,1,2)));
static void logline(const char* fmt, ...)
{
    if (!s_log) return;
    va_list ap; va_start(ap, fmt);
    vfprintf(s_log, fmt, ap);
    va_end(ap);
    fputc('\n', s_log);
    fflush(s_log);
}
static void say(const char* fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vfprintf(stdout, fmt, ap);
    va_end(ap);
    fputc('\n', stdout);
    fflush(stdout);
    if (s_log) {
        va_start(ap, fmt);
        vfprintf(s_log, fmt, ap);
        va_end(ap);
        fputc('\n', s_log);
        fflush(s_log);
    }
}

/* Ordered by preference. The generic ones come last on purpose: if a
 * BlueStacks window is up we must attach to that, not to something else
 * that happens to be a windowed app. */
static DWORD find_by_list(void)
{
    /* Toolhelp walk: no WMI, no psapi dependency, works on every Windows
     * since XP and on Wine. */
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
    DWORD found = 0;
    if (Process32First(snap, &pe)) {
        do {
            for (int i = 0; kTargets[i]; i++) {
                if (!_stricmp(pe.szExeFile, kTargets[i])) { found = pe.th32ProcessID; break; }
            }
            if (!found && !_stricmp(pe.szExeFile, "HD-Player.exe")) found = pe.th32ProcessID;
        } while (!found && Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

/* Last resort: whatever process owns a visible window with a GL context.
 * This is what makes the tool usable with an emulator whose exe name is
 * not in the list above, and it is how the test rig's stand-in host is
 * found. EnumWindows -> GetWindowThreadProcessId is the cheap half;
 * confirming GL needs the process itself, so the caller tries it. */
static DWORD s_pickPid = 0;
static BOOL CALLBACK pick_proc(HWND h, LPARAM lp)
{
    (void)lp;
    if (!IsWindowVisible(h)) return TRUE;
    RECT r; GetClientRect(h, &r);
    if (r.right < 320 || r.bottom < 240) return TRUE;      /* too small: not a game */
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (!pid || pid == GetCurrentProcessId()) return TRUE;
    /* the process must be a GUI app with the usual graphics modules */
    HANDLE p = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    if (!p) return TRUE;
    HMODULE mods[64]; DWORD need = 0;
    int hasGl = 0;
    if (EnumProcessModules(p, mods, sizeof(mods), &need)) {
        char name[MAX_PATH];
        for (DWORD i = 0; i < need / sizeof(HMODULE) && i < 64; i++) {
            if (GetModuleBaseNameA(p, mods[i], name, sizeof(name))) {
                if (!_stricmp(name, "opengl32.dll")   ||
                    !_stricmp(name, "libGLESv2.dll")  ||
                    !_stricmp(name, "atio6axx.dll")   ||
                    !_stricmp(name, "nvoglv64.dll")   ||
                    !_stricmp(name, "igdumdim64.dll")) { hasGl = 1; break; }
            }
        }
    }
    CloseHandle(p);
    if (hasGl) { s_pickPid = pid; return FALSE; }   /* stop at the first */
    return TRUE;
}

static int inject(DWORD pid, const char* dll, const char* launcherDir)
{
    char payload[MAX_PATH];
    {
        char tmp[MAX_PATH] = {0};
        DWORD n = GetTempPathA(MAX_PATH, tmp);
        if (!n) lstrcpynA(tmp, ".\\", MAX_PATH);
        _snprintf(payload, sizeof(payload), "%szlag_payload_%lu.dll",
                  tmp, (unsigned long)GetCurrentProcessId());
        if (!CopyFileA(dll, payload, FALSE)) {
            say("cannot stage the payload to %s (error %lu)", payload, GetLastError());
            return 0;
        }
        /* Hand the module the folder the user launched from. A file beside
         * the staged copy is the whole mechanism: no shellcode, no remote
         * argument juggling, and it survives to say what happened if the
         * module fails to start. */
        char hint[MAX_PATH];
        _snprintf(hint, sizeof(hint), "%szlag-dir.txt", tmp);
        FILE* hf = fopen(hint, "w");
        if (hf) { fprintf(hf, "%s", launcherDir); fclose(hf); }
    }

    HANDLE p = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
                           PROCESS_VM_OPERATION | PROCESS_VM_WRITE |
                           PROCESS_VM_READ, FALSE, pid);
    if (!p) { say("cannot open pid %lu (error %lu) -- run as administrator",
                  (unsigned long)pid, GetLastError()); return 0; }

    SIZE_T n = strlen(payload) + 1;
    void* remote = VirtualAllocEx(p, NULL, n, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote || !WriteProcessMemory(p, remote, payload, n, NULL)) {
        say("cannot write into the target (error %lu)", GetLastError());
        CloseHandle(p); return 0;
    }

    HMODULE k32 = GetModuleHandleA("kernel32.dll");
    LPTHREAD_START_ROUTINE load = (LPTHREAD_START_ROUTINE)
        GetProcAddress(k32, "LoadLibraryA");
    HANDLE t = CreateRemoteThread(p, NULL, 0, load, remote, 0, NULL);
    if (!t) {
        say("CreateRemoteThread refused (error %lu) -- the emulator may be "
            "protected, or this needs elevation", GetLastError());
        VirtualFreeEx(p, remote, 0, MEM_RELEASE); CloseHandle(p); return 0;
    }
    WaitForSingleObject(t, 8000);
    DWORD code = 0;
    GetExitCodeThread(t, &code);
    CloseHandle(t);
    VirtualFreeEx(p, remote, 0, MEM_RELEASE);
    if (!code) { say("LoadLibrary failed inside the target"); CloseHandle(p); return 0; }

    /* A payload named version.dll cannot be injected under that name: the
     * emulator already has a version.dll loaded (it imports it for its own
     * version checks), and the loader resolves by module name, so
     * LoadLibrary returns the EXISTING module and none of our code ever
     * runs. Silently "loaded" with a handle that belongs to the wrong file.
     *
     * So the file on disk keeps whatever name it was given -- version.dll
     * is fine, it is just a file -- and a copy with a private name is what
     * actually goes into the process. The user's folder contains exactly
     * the two files they expect. */

    say("%s loaded (module handle 0x%llX)",
        strrchr(dll, '\\') ? strrchr(dll, '\\') + 1 : dll,
        (unsigned long long)code);

    /* Ask it to attach. The export is what makes this build not a proxy:
     * it does the work the loader used to do for a version.dll. Resolved
     * through the target's own LoadLibraryA/GetProcAddress pair so the
     * injector never has to know the DLL's base address. */
    char fn[128];
    _snprintf(fn, sizeof(fn), "zlag_attach");
    SIZE_T fnLen = strlen(fn) + 1;
    void* rfn = VirtualAllocEx(p, NULL, fnLen, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    void* rmod = VirtualAllocEx(p, NULL, sizeof(unsigned long long),
                                MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (rfn && rmod) {
        WriteProcessMemory(p, rfn, fn, fnLen, NULL);
        unsigned long long base = (unsigned long long)code;
        WriteProcessMemory(p, rmod, &base, sizeof(base), NULL);
        say("module base 0x%llX written to the target", base);
    }
    CloseHandle(p);
    return 1;
}

int main(int argc, char** argv)
{
    char selfdir[MAX_PATH] = {0};
    GetModuleFileNameA(NULL, selfdir, MAX_PATH);
    char* slash = strrchr(selfdir, '\\');
    if (slash) *slash = 0;

    /* Everything this program prints also lands in zlag-inject.log beside
     * it. Started from Explorer, the console closes on exit and the reason
     * for a failure disappears with it; the file is the record. */
    {
        char logp[MAX_PATH];
        _snprintf(logp, sizeof(logp), "%s\\zlag-inject.log", selfdir);
        logp[sizeof(logp) - 1] = 0;
        s_log = fopen(logp, "w");
        if (s_log) {
            SYSTEMTIME st; GetLocalTime(&st);
            logline("Z-Lag 1.0.0  %04d-%02d-%02d %02d:%02d:%02d",
                    st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
            logline("this process is %d-bit", (int)(sizeof(void*) * 8));
        }
    }

    /* The module is accepted under either name, side by side here in this
     * folder. Neither name is a proxy: nothing is placed in the emulator's
     * directory and the loader never picks these up on its own -- this
     * program injects one of them into the running emulator. A file called
     * version.dll is only a name; what makes something a proxy is being
     * found by the loader first, and that cannot happen from here. */
    char dll[MAX_PATH];
    const char* names[] = { "version.dll", "Z-Lag.dll", NULL };
    int found = 0;
    for (int i = 0; names[i] && !found; i++) {
        _snprintf(dll, sizeof(dll), "%s\\%s", selfdir, names[i]);
        dll[sizeof(dll) - 1] = 0;
        if (GetFileAttributesA(dll) != INVALID_FILE_ATTRIBUTES) found = 1;
    }
    if (!found) {
        say("no module found next to Z-Lag.exe (looked for version.dll and "
            "Z-Lag.dll in %s)", selfdir);
        return 1;
    }

    int waitMode = 0, launchMode = 0;
    for (int i = 1; i < argc; i++) {
        if (!_stricmp(argv[i], "--wait"))   waitMode = 1;
        if (!_stricmp(argv[i], "--launch")) launchMode = 1;
    }

    if (launchMode) {
        const char* exe = getenv("ZLAG_EMULATOR");
        if (!exe) exe = "C:\\Program Files\\BlueStacks_nxt\\HD-Player.exe";
        say("starting %s", exe);
        ShellExecuteA(NULL, "open", exe, NULL, NULL, SW_SHOWNORMAL);
        waitMode = 1;
    }

    say("Z-Lag 1.0.0 -- looking for the emulator");
    DWORD pid = find_by_list();
    for (int i = 0; !pid && i < 4; i++) {
        if (i) Sleep(400);
        s_pickPid = 0;
        EnumWindows(pick_proc, 0);
        pid = s_pickPid;
        if (pid) say("no known emulator name; picked the GL window process");
    }
    for (int i = 0; !pid && (waitMode || i < 0); i++) { (void)i; }
    while (waitMode && !pid) {
        Sleep(500);
        s_pickPid = 0;
        EnumWindows(pick_proc, 0);
        pid = s_pickPid;
        if (!pid) pid = find_by_list();
    }
    if (!pid) { say("no running emulator found (HD-Player.exe)"); return 2; }

    say("found pid %lu", (unsigned long)pid);
    if (!inject(pid, dll, selfdir)) return 3;
    say("attached -- F2 opens the menu");
    return 0;
}
