#ifndef ZLAG_ADBEXEC_H
#define ZLAG_ADBEXEC_H
/* Run adb without a command interpreter. Drain the pipe without blocking
 * forever: adb or a guest may hang, and an inherited writer can keep an
 * anonymous pipe open even after the original process has exited. */
#include <windows.h>
#include <stdio.h>
#include <string.h>

static int zl_adb_spawn(const char* adb, const char* args,
                        void (*onLine)(const char*, void*), void* ctx)
{
    char cmd[8192];
    int n = _snprintf(cmd, sizeof(cmd), "\"%s\" %s", adb, args);
    if (n < 0 || n >= (int)sizeof(cmd)) return -4;
    cmd[sizeof(cmd) - 1] = 0;

    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    HANDLE rd = NULL, wr = NULL;
    if (!CreatePipe(&rd, &wr, &sa, 0)) return -1;
    if (!SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0)) {
        CloseHandle(rd); CloseHandle(wr); return -1;
    }
    STARTUPINFOA si; ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = wr;
    si.hStdError = wr;
    si.hStdInput = NULL;
    PROCESS_INFORMATION pi; ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcessA(NULL, cmd, NULL, NULL, TRUE, CREATE_NO_WINDOW,
                        NULL, NULL, &si, &pi)) {
        CloseHandle(rd); CloseHandle(wr); return -2;
    }
    CloseHandle(wr);

    char chunk[1024], line[2048];
    size_t used = 0;
    DWORD start = GetTickCount();
    int timeout = 0, exited = 0;
    for (;;) {
        DWORD available = 0, got = 0;
        BOOL peek = PeekNamedPipe(rd, NULL, 0, NULL, &available, NULL);
        if (peek && available) {
            DWORD take = available < sizeof(chunk) ? available : (DWORD)sizeof(chunk);
            if (ReadFile(rd, chunk, take, &got, NULL) && got) {
                for (DWORD i = 0; i < got; ++i) {
                    char c = chunk[i];
                    if (c == '\n') {
                        while (used && line[used - 1] == '\r') --used;
                        line[used] = 0;
                        if (used && onLine) onLine(line, ctx);
                        used = 0;
                    } else if (used + 1 < sizeof(line)) {
                        line[used++] = c;
                    }
                }
            }
        }
        exited = WaitForSingleObject(pi.hProcess, 0) == WAIT_OBJECT_0;
        if (exited && (!peek || !available)) break;
        if (GetTickCount() - start >= 30000) {
            timeout = 1;
            TerminateProcess(pi.hProcess, 1);
            WaitForSingleObject(pi.hProcess, 2000);
            break;
        }
        if (!available) WaitForSingleObject(pi.hProcess, 40);
    }
    if (used && onLine) {
        while (used && line[used - 1] == '\r') --used;
        line[used] = 0;
        if (used) onLine(line, ctx);
    }
    DWORD rc = 1;
    if (!timeout && exited && GetExitCodeProcess(pi.hProcess, &rc)) {
        /* remote shell exit status is honored by current adb builds */
    } else if (timeout) {
        rc = (DWORD)-3;
    }
    CloseHandle(rd);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    return (int)rc;
}
#endif
