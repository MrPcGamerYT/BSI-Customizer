/* =====================================================================
 *  menuwin.cpp  --  the menu, as a real Windows window.
 *
 *  An overlay panel lives on the emulator's surface, so every click on it
 *  is taken away from the game. A window does not have that problem: it
 *  has its own title bar, its own taskbar button and its own input queue,
 *  and nothing is intercepted to make it work.
 *
 *  There are two ImGui contexts in the process on purpose:
 *
 *    ctx 0  the overlay's -- the status strip and, historically, the panel
 *    ctx 1  this window's  -- its own atlas, its own draw data
 *
 *  Sharing one context between the emulator's render thread and a window
 *  thread is a data race that shows up as "sometimes it draws nothing",
 *  which is the exact class of bug this whole rewrite exists to remove.
 * ===================================================================== */
#include "menuwin.h"
#include "common.h"
#include "dpi_scope.h"
#include "imgui.h"
#include "imgui/backends/imgui_impl_win32.h"
#include <windows.h>
#include <GL/gl.h>

/* GL 1.1 headers predate shaders; the enums are plain constants */
#ifndef GL_VERTEX_SHADER
#define GL_VERTEX_SHADER   0x8B31
#endif
#ifndef GL_FRAGMENT_SHADER
#define GL_FRAGMENT_SHADER 0x8B30
#endif
#ifndef GL_COMPILE_STATUS
#define GL_COMPILE_STATUS  0x8B81
#endif
#ifndef GL_LINK_STATUS
#define GL_LINK_STATUS     0x8B82
#endif
#ifndef GL_ARRAY_BUFFER
#define GL_ARRAY_BUFFER    0x8892
#endif
#ifndef GL_ELEMENT_ARRAY_BUFFER
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#endif
#ifndef GL_STREAM_DRAW
#define GL_STREAM_DRAW     0x88E0
#endif
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE   0x812F
#endif
#ifndef GL_TEXTURE0
#define GL_TEXTURE0        0x84C0
#endif

typedef long long GLsizeiptr_t;

/* GL entry points, resolved once and called through plain pointers */
typedef void (*PFN_glUseProgram)(GLuint);
typedef void (*PFN_glUniform1i)(GLint, GLint);
typedef void (*PFN_glUniform2f)(GLint, GLfloat, GLfloat);
typedef void (*PFN_glGenBuffers)(GLsizei, GLuint*);
typedef void (*PFN_glBindBuffer)(GLenum, GLuint);
typedef void (*PFN_glBufferData)(GLenum, GLsizeiptr_t, const void*, GLenum);
typedef void (*PFN_glBufferSubData)(GLenum, long long, GLsizeiptr_t, const void*);
typedef void (*PFN_glEnableAttrib)(GLuint);
typedef void (*PFN_glVertexAttribPointer)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*);
typedef void (*PFN_glDrawElements)(GLenum, GLsizei, GLenum, const void*);
typedef void (*PFN_glActiveTexture)(GLenum);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern "C" int  zl_ui_frame_window(int w, int h);   /* the tabs, no rendering */
extern "C" void zl_ui_style_window(void);

/* the software rasteriser that turns draw lists into pixels */
extern "C" void zlm_raster(const ImDrawData* dd, unsigned int* out,
                           int w, int h, const unsigned char* atlas,
                           int aw, int ah);

#define ZLW_CLASS "ZLagMenuWindow"
#define ZLW_F2_MESSAGE (WM_APP + 0x2A)
#define ZLW_DEFAULT_WIDTH 700
#define ZLW_DEFAULT_HEIGHT 500

/* ------------------------------------------------------------------ */
/*  state                                                             */
/* ------------------------------------------------------------------ */
static HWND   s_wnd = NULL;
static HDC    s_dc  = NULL;
static HGLRC  s_rc  = NULL;
static int    s_w = ZLW_DEFAULT_WIDTH, s_h = ZLW_DEFAULT_HEIGHT;
static volatile LONG s_alive = 0;
static volatile LONG s_quit  = 0;
static HHOOK s_f2Hook = NULL;
/* F2 hook and poll both run on the menu thread. */
static int s_f2HookDown = 0, s_f2Swallow = 0, s_f2HookSeen = 0;
static DWORD s_lastF2Hook = 0;

static ImGuiContext* s_ctx = NULL;
static ImFont* s_menuFont = NULL;
static GLuint s_prog = 0, s_vbo = 0, s_ibo = 0, s_fontTex = 0;
static GLint  s_uTex = -1, s_uHalf = -1, s_aPos = -1, s_aUV = -1;
static int    s_vboCap = 0, s_iboCap = 0;
static int    s_maxTex = 0;
static int    s_gl2 = 0;

/* ------------------------------------------------------------------ */
/*  a small 2D blit path, independent of the ES backend in ui_es.cpp   */
/* ------------------------------------------------------------------ */
static const char* BLIT_VS =
    "attribute vec2 aPos;\n"
    "attribute vec2 aUV;\n"
    "uniform vec2 uHalf;\n"
    "varying vec2 vUV;\n"
    "void main(){\n"
    "  vUV = aUV;\n"
    "  gl_Position = vec4(aPos.x / uHalf.x - 1.0, 1.0 - aPos.y / uHalf.y, 0.0, 1.0);\n"
    "}\n";

static const char* BLIT_FS =
    "#ifdef GL_ES\n"
    "precision mediump float;\n"
    "#endif\n"
    "uniform sampler2D uTex;\n"
    "varying vec2 vUV;\n"
    "void main(){ gl_FragColor = texture2D(uTex, vUV); }\n";

static HMODULE s_gl = NULL;

/* Two lookup paths, because OpenGL splits them: anything that existed in
 * GL 1.1 (glDrawElements, glTexImage2D, ...) is a plain export of
 * opengl32.dll and wglGetProcAddress returns NULL for it. Everything from
 * GL 2.0 on arrives through wglGetProcAddress. Asking the wrong one is a
 * silent NULL, and calling a NULL is an execute-access fault at 0x0. */
static void* glsym(const char* n)
{
    /* opengl32.dll FIRST. wglGetProcAddress answers for core functions with
     * a stub on some drivers -- it returns a readable, callable address that
     * does nothing. glGenBuffers through that stub yields buffer 0, and a
     * later glBufferSubData on buffer 0 is GL_INVALID_OPERATION, which is
     * exactly the 0x0502 that was rejecting every draw. Extensions are not
     * in opengl32.dll, so they fall through to the second lookup. */
    if (!s_gl) s_gl = LoadLibraryA("opengl32.dll");
    if (s_gl) {
        void* q = (void*)GetProcAddress(s_gl, n);
        if (q) return q;
    }
    void* p = (void*)wglGetProcAddress(n);
    if (p && p != (void*)1 && p != (void*)2 && p != (void*)3 &&
        p != (void*)-1) return p;
    return NULL;
}

static GLuint compile(GLenum type, const char* src)
{
    GLuint (*createShader)(GLenum) = (GLuint(*)(GLenum))glsym("glCreateShader");
    void (*shaderSource)(GLuint, GLsizei, const char* const*, const GLint*) =
        (void(*)(GLuint, GLsizei, const char* const*, const GLint*))glsym("glShaderSource");
    void (*compileShader)(GLuint) = (void(*)(GLuint))glsym("glCompileShader");
    void (*getShaderiv)(GLuint, GLenum, GLint*) =
        (void(*)(GLuint, GLenum, GLint*))glsym("glGetShaderiv");
    if (!createShader || !shaderSource || !compileShader) return 0;

    GLuint s = createShader(type);
    shaderSource(s, 1, &src, NULL);
    compileShader(s);
    GLint ok = 0;
    if (getShaderiv) getShaderiv(s, GL_COMPILE_STATUS, &ok);
    return ok ? s : 0;
}

static int blit_init(void)
{
    if (!glsym("glCreateShader")) return 0;      /* GL 1.1: no shaders here */
    if (!glsym("glGenBuffers"))   return 0;

    GLuint vs = compile(GL_VERTEX_SHADER, BLIT_VS);
    GLuint fs = compile(GL_FRAGMENT_SHADER, BLIT_FS);
    if (!vs || !fs) { zl_log(LOG_WARN, "menuwin: shader compile failed"); return 0; }

    GLuint (*createProgram)(void) = (GLuint(*)(void))glsym("glCreateProgram");
    void (*attachShader)(GLuint, GLuint) = (void(*)(GLuint, GLuint))glsym("glAttachShader");
    void (*bindAttrib)(GLuint, GLuint, const char*) =
        (void(*)(GLuint, GLuint, const char*))glsym("glBindAttribLocation");
    void (*linkProgram)(GLuint) = (void(*)(GLuint))glsym("glLinkProgram");
    void (*getProgramiv)(GLuint, GLenum, GLint*) =
        (void(*)(GLuint, GLenum, GLint*))glsym("glGetProgramiv");

    s_prog = createProgram();
    attachShader(s_prog, vs);
    attachShader(s_prog, fs);
    /* No glBindAttribLocation here. Forcing attribute 0/1 made the linker
     * place aPos and uTex in the same slot -- the uniforms read back as
     * (uTex=1, uHalf=0, aPos=0, aUV=1), i.e. every name landed in the
     * wrong register, and every draw was rejected. Let the linker choose,
     * then query what it chose. */
    linkProgram(s_prog);

    GLint ok = 0;
    getProgramiv(s_prog, GL_LINK_STATUS, &ok);
    if (!ok) { zl_log(LOG_WARN, "menuwin: program link failed"); s_prog = 0; return 0; }

    /* Ask the linker where it put everything. A location of -1 means the
     * name was optimised away -- a sign the program is not what we think
     * it is -- and must be logged rather than used as an index. */
    s_uTex  = ((GLint(*)(GLuint, const char*))glsym("glGetUniformLocation"))(s_prog, "uTex");
    s_uHalf = ((GLint(*)(GLuint, const char*))glsym("glGetUniformLocation"))(s_prog, "uHalf");
    s_aPos  = ((GLint(*)(GLuint, const char*))glsym("glGetAttribLocation"))(s_prog, "aPos");
    s_aUV   = ((GLint(*)(GLuint, const char*))glsym("glGetAttribLocation"))(s_prog, "aUV");

    zl_log(LOG_INFO, "menuwin link: uTex=%d uHalf=%d aPos=%d aUV=%d",
           s_uTex, s_uHalf, s_aPos, s_aUV);
    if (s_uTex < 0 || s_uHalf < 0 || s_aPos < 0 || s_aUV < 0) {
        zl_log(LOG_ERR, "menuwin: program did not expose all of its names");
        s_prog = 0;
        return 0;
    }

    PFN_glGenBuffers genBuffers = (PFN_glGenBuffers)glsym("glGenBuffers");
    genBuffers(1, &s_vbo);
    genBuffers(1, &s_ibo);
    zl_log(LOG_INFO, "menuwin buffers: vbo=%u ibo=%u", (unsigned)s_vbo, (unsigned)s_ibo);
    if (!s_vbo || !s_ibo) {
        zl_log(LOG_ERR, "menuwin: glGenBuffers produced no buffers");
        return 0;
    }
    s_gl2 = 1;
    return 1;
}

/* ------------------------------------------------------------------ */
/*  find the emulator's own frame, to place the menu beside it          */
/* ------------------------------------------------------------------ */
struct FindCtx { DWORD pid; HWND best; };

static BOOL CALLBACK find_cb(HWND h, LPARAM lp)
{
    FindCtx* c = (FindCtx*)lp;
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (pid != c->pid) return TRUE;
    if (!IsWindowVisible(h)) return TRUE;
    if (GetWindow(h, GW_OWNER) != NULL) return TRUE;      /* not a dialog */

    RECT r;
    if (!GetWindowRect(h, &r)) return TRUE;
    /* the frame is the big one; splash and tool windows are not */
    if (r.right - r.left < 240 || r.bottom - r.top < 180) return TRUE;
    c->best = h;
    return FALSE;
}

static HWND host_frame(void)
{
    DWORD pid = (DWORD)g_state.pid;
    if (!pid) return NULL;
    FindCtx c = { pid, NULL };
    EnumWindows(find_cb, (LPARAM)&c);
    return c.best;
}

/* ------------------------------------------------------------------ */
/*  the window                                                        */
/* ------------------------------------------------------------------ */
/* Place the panel within one monitor's work area. Never move or resize the
 * emulator or change the desktop resolution. On a maximized single monitor,
 * the separate panel necessarily overlaps until hidden with F2. */
static int clamp_coord(int n, int lo, int hi)
{
    if (hi < lo) hi = lo;
    return n < lo ? lo : (n > hi ? hi : n);
}

static void place_next_to_host(int* x, int* y)
{
    const int edge = 8, gap = 12;
    HWND host = host_frame();
    RECT hr = {0, 0, 0, 0}, work = {0, 0, 0, 0};
    int have_host = host && GetWindowRect(host, &hr) &&
                    hr.right - hr.left > 200 && hr.bottom - hr.top > 150;
    int saved = (g_cfg.menuX != -1 && g_cfg.menuY != -1);
    HMONITOR monitor;
    if (saved) {
        POINT pt = {g_cfg.menuX, g_cfg.menuY};
        monitor = MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
    } else {
        monitor = MonitorFromWindow(have_host ? host : NULL, MONITOR_DEFAULTTOPRIMARY);
    }
    MONITORINFO mi = {0};
    mi.cbSize = sizeof(mi);
    if (monitor && GetMonitorInfoA(monitor, &mi)) work = mi.rcWork;
    else if (!SystemParametersInfoA(SPI_GETWORKAREA, 0, &work, 0)) {
        work.left = work.top = 0;
        work.right = GetSystemMetrics(SM_CXSCREEN);
        work.bottom = GetSystemMetrics(SM_CYSCREEN);
    }

    /* Older builds could save a size enlarged by a phantom window frame.
     * Retain the chosen position, but intentionally discard the old size. */
    s_w = ZLW_DEFAULT_WIDTH;
    s_h = ZLW_DEFAULT_HEIGHT;
    int available_w = work.right - work.left - 2 * edge;
    int available_h = work.bottom - work.top - 2 * edge;
    if (available_w < 1) available_w = 1;
    if (available_h < 1) available_h = 1;
    if (s_w > available_w) s_w = available_w;
    if (s_h > available_h) s_h = available_h;

    if (saved) {
        *x = g_cfg.menuX;
        *y = g_cfg.menuY;
    } else if (have_host && work.right - hr.right >= s_w + gap + edge) {
        *x = hr.right + gap;
        *y = hr.top;
    } else if (have_host && hr.left - work.left >= s_w + gap + edge) {
        *x = hr.left - gap - s_w;
        *y = hr.top;
    } else {
        *x = work.right - edge - s_w;
        *y = work.top + edge;
    }
    *x = clamp_coord(*x, work.left + edge, work.right - edge - s_w);
    *y = clamp_coord(*y, work.top + edge, work.bottom - edge - s_h);
    zl_log(LOG_INFO, "menu window %dx%d at %d,%d; host geometry unchanged",
           s_w, s_h, *x, *y);
}

/* A click is two events (press, release) and they routinely arrive inside
 * one rendered frame -- with level-triggered polling the release overwrites
 * the press before ImGui ever looks, and the button highlight goes on but
 * nothing happens. Queue them and replay in order. */
enum { ZLW_EV_MOVE, ZLW_EV_DOWN, ZLW_EV_UP, ZLW_EV_WHEEL };
struct ZlwEv { int type; float a, b; };

static ZlwEv s_q[256];
static volatile LONG s_qHead = 0, s_qTail = 0;

static void q_push(int type, float a, float b)
{
    LONG h = InterlockedIncrement(&s_qHead) - 1;
    s_q[h & 255].type = type; s_q[h & 255].a = a; s_q[h & 255].b = b;
}

static void feed_mouse(LPARAM lp)
{
    q_push(ZLW_EV_MOVE, (float)(short)LOWORD(lp), (float)(short)HIWORD(lp));
}

/* ImGui samples the button level once per NewFrame: if a press and its
 * release both land in one frame, the level never changes between frames and
 * the click is invisible. Stop the drain after a single button transition so
 * the press gets its own frame and the release the next one. */
static void q_drain(void)
{
    ImGuiIO& io = ImGui::GetIO();
    for (;;) {
        LONG t = s_qTail;
        if (t >= s_qHead) break;
        ZlwEv e = s_q[t & 255];
        InterlockedIncrement(&s_qTail);
        switch (e.type) {
        case ZLW_EV_MOVE:  io.AddMousePosEvent(e.a, e.b); break;
        case ZLW_EV_DOWN:
            /* the click's own coordinates, not whatever the pointer feed
             * last managed to sample */
            io.AddMousePosEvent(e.a, e.b); io.AddMouseButtonEvent(0, true);
            return;
        case ZLW_EV_UP:
            io.AddMousePosEvent(e.a, e.b); io.AddMouseButtonEvent(0, false);
            return;
        case ZLW_EV_WHEEL: io.AddMouseWheelEvent(0.0f, e.b); return;
        }
    }
}

static void feed_keys(void)
{
    ImGuiIO& io = ImGui::GetIO();
    io.AddKeyEvent(ImGuiKey_Tab,       (GetKeyState(VK_TAB)     & 0x8000) != 0);
    io.AddKeyEvent(ImGuiKey_Enter,     (GetKeyState(VK_RETURN)  & 0x8000) != 0);
    io.AddKeyEvent(ImGuiKey_Escape,    (GetKeyState(VK_ESCAPE)  & 0x8000) != 0);
    io.AddKeyEvent(ImGuiKey_Backspace, (GetKeyState(VK_BACK)    & 0x8000) != 0);
    io.AddKeyEvent(ImGuiKey_Space,     (GetKeyState(VK_SPACE)   & 0x8000) != 0);
    for (int c = 'A'; c <= 'Z'; c++)
        io.AddKeyEvent((ImGuiKey)((int)ImGuiKey_A + (c - 'A')),
                       (GetKeyState(c) & 0x8000) != 0);
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

/* Rounded corners that are actually rounded.
 *
 * Drawing the panel with a rounded background is not enough: the GL surface
 * behind it is a full rectangle of dark pixels, so the corners still come
 * out square. The window needs a region -- the OS then clips the corners
 * away entirely and whatever is behind shows through. SetWindowRgn takes
 * ownership of the region, so the old one is freed by the call itself. */
#define ZLW_CORNER 16
static void apply_round_region(HWND h)
{
    RECT rc;
    if (!GetClientRect(h, &rc)) return;
    int w = rc.right - rc.left, hh = rc.bottom - rc.top;
    if (w < 40 || hh < 40) return;          /* mid-resize: leave it alone */
    HRGN r = CreateRoundRectRgn(0, 0, w + 1, hh + 1, ZLW_CORNER, ZLW_CORNER);
    if (r && !SetWindowRgn(h, r, TRUE)) DeleteObject(r);
}

static LRESULT CALLBACK wndproc(HWND h, UINT m, WPARAM wp, LPARAM lp)
{
    /* ImGui's current context is process-global. Pin our context under the
     * same lock used for drawing before delivering messages to its backend. */
    if (s_ctx) {
        LRESULT handled;
        zl_ui_lock();
        ImGui::SetCurrentContext(s_ctx);
        handled = ImGui_ImplWin32_WndProcHandler(h, m, wp, lp);
        zl_ui_unlock();
        if (handled) return 1;
    }

    switch (m) {
    case WM_SIZE:
        s_w = LOWORD(lp); s_h = HIWORD(lp);
        apply_round_region(h);      /* the region follows every resize */
        return 0;

    case WM_DPICHANGED:
        /* Keep the requested physical-pixel size when moving monitors; do
         * not accept a suggested larger rectangle or resize the emulator. */
        return 0;

    case WM_LBUTTONDOWN:
        /* Dragging is started from the panel's header (see draw_menu): the
         * header draws real buttons now -- the close dots -- and grabbing
         * every press in the top strip meant those could never be clicked.
         * Here we only take focus. */
        SetFocus(h);
        return 0;

    case WM_NCHITTEST:
        /* no resize borders on a borderless panel: every pixel is client
         * area, and moving is done from the strip above */
        return HTCLIENT;

    case ZLW_F2_MESSAGE:
        /* The low-level callback only posts this; all UI work happens here. */
        zl_open_menu_toggle();
        return 0;

    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
        /* F2 is handled by the keyboard hook or its polling fallback. */
        if ((int)wp == ZL_TOGGLE_VK) return 0;
        if ((int)wp == VK_ESCAPE && !(lp & 0x40000000) && g_state.menuWanted) {
            InterlockedExchange(&g_state.menuWanted, 0);
            InterlockedExchange(&g_state.menuOpen, 0);
            return 0;
        }
        return 0;

    case WM_KEYUP:
    case WM_SYSKEYUP:
        return 0;

    case WM_SYSCOMMAND:
        if ((wp & 0xFFF0) == SC_KEYMENU) return 0;   /* no beep on Alt */
        break;

    case WM_EXITSIZEMOVE:
        /* The user just finished dragging or resizing us. This is the moment
         * to remember it: in the message handler the window already has its
         * final rect. Without this the menu reappeared at the same guessed
         * spot every time, on top of the emulator, no matter where it had
         * been put. */
        if (h == s_wnd) {
            RECT r;
            if (GetWindowRect(h, &r)) {
                g_cfg.menuX = r.left;
                g_cfg.menuY = r.top;
                g_cfg.menuW = r.right - r.left;
                g_cfg.menuH = r.bottom - r.top;
                zl_settings_save();
                zl_log(LOG_INFO, "menu window position saved: %dx%d at %ld,%ld",
                       (int)g_cfg.menuW, (int)g_cfg.menuH,
                       (long)g_cfg.menuX, (long)g_cfg.menuY);
            }
        }
        return 0;

    case WM_CLOSE:
        /* HIDE, never destroy.
         *
         * This is the bug the user reported: pressing the titlebar X made
         * the menu unusable until the emulator was restarted. The handler
         * below looked correct -- hide the window, clear the flag -- but
         * ShowWindow(SW_HIDE) on a window whose WM_CLOSE is being processed
         * by DefWindowProc still ends in DestroyWindow, because returning 0
         * is not enough: the default close path runs anyway once the window
         * is hidden. The window object is gone, s_wnd names nothing, and the
         * thread's own loop then exits on WM_DESTROY. A hidden window can be
         * shown again; a destroyed one cannot.
         *
         * So: hide it, clear the flag, and let the message loop keep the
         * object alive. Reopening is then just ShowWindow. */
        InterlockedExchange(&g_state.menuWanted, 0);
        InterlockedExchange(&g_state.menuOpen, 0);
        ShowWindow(h, SW_HIDE);
        zl_log(LOG_INFO, "menu window hidden by its own close button "
                         "(F2 brings it back)");
        return 0;   /* never reaches DestroyWindow */
    }
    return DefWindowProcA(h, m, wp, lp);
}

static int window_create(void)
{
    WNDCLASSA wc = {0};
    wc.lpfnWndProc   = wndproc;
    wc.hInstance     = GetModuleHandleA(NULL);
    wc.lpszClassName = ZLW_CLASS;
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.style         = CS_OWNDC;
    if (!RegisterClassA(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) {
        zl_log(LOG_ERR, "menuwin: RegisterClass failed (%lu)", GetLastError());
        return 0;
    }

    int x, y;
    place_next_to_host(&x, &y);

    s_wnd = CreateWindowExA(WS_EX_APPWINDOW | WS_EX_TOPMOST, ZLW_CLASS, "Z-Lag  -  Menu",
                            /* Borderless: the white caption bar was drawn by
                             * Windows, not by us, and there is no style that
                             * makes it dark on every build. As a popup the
                             * panel is all ours, and the corner region rounds
                             * the whole window instead of just the client. */
                            WS_POPUP,
                            x, y, s_w, s_h,
                            NULL, NULL, wc.hInstance, NULL);
    if (!s_wnd) {
        zl_log(LOG_ERR, "menuwin: CreateWindow failed (%lu)", GetLastError());
        return 0;
    }

    s_dc = GetDC(s_wnd);

    PIXELFORMATDESCRIPTOR pfd = {0};
    pfd.nSize      = sizeof(pfd);
    pfd.nVersion   = 1;
    pfd.dwFlags    = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cDepthBits = 0;
    pfd.iLayerType = PFD_MAIN_PLANE;

    int pf = ChoosePixelFormat(s_dc, &pfd);
    if (!pf || !SetPixelFormat(s_dc, pf, &pfd)) {
        zl_log(LOG_ERR, "menuwin: no pixel format (%lu)", GetLastError());
        return 0;
    }
    s_rc = wglCreateContext(s_dc);
    if (!s_rc || !wglMakeCurrent(s_dc, s_rc)) {
        zl_log(LOG_ERR, "menuwin: no GL context (%lu)", GetLastError());
        return 0;
    }

    /* --- its own ImGui context and font atlas ------------------------ */
    zl_ui_lock();
    s_ctx = ImGui::CreateContext();
    zl_ui_bind_window_context(s_ctx);   /* tell the shared builder which context this lane owns */
    ImGui::SetCurrentContext(s_ctx);
    zl_ui_style_window();
    /* Official backend instead of the hand-rolled input path.
     *
     * The old path fed ImGui from TWO sources at once: GetAsyncKeyState
     * sampled every frame, and WM_LBUTTONDOWN/UP queued from the window
     * procedure. Whichever arrived first from a given click won, and on
     * some machines -- DPI-scaled desktops especially -- the two disagreed
     * about where the cursor was, so the press landed on no widget and the
     * menu simply did not respond. Sampling key state also misses a click
     * entirely if the press and release both happen between two frames.
     *
     * ImGui's own Win32 backend has none of these problems: it is driven
     * purely by the messages Windows sends, it converts the pointer with
     * the same call the window uses, and it is what every ImGui
     * application on the planet ships with. There is no reason for us to
     * be cleverer than it about reading a mouse. */
    ImGui_ImplWin32_InitForOpenGL(s_wnd);
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = NULL;
    io.LogFilename = NULL;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    /* A real font at its native size.
     *
     * This used to rasterise ImGui's bitmap font at 26 px and scale it down
     * to 13 with FontGlobalScale -- an upscaled bitmap font scaled back down
     * is the worst of both: soft stems, uneven spacing, nothing crisp at any
     * size. A system TTF at the size it will actually be drawn is the basic,
     * readable answer, and every Windows install has one of these. */
    {
        static const char* candidates[] = {
            "C:\\Windows\\Fonts\\segoeui.ttf",
            "C:\\Windows\\Fonts\\tahoma.ttf",
            "C:\\Windows\\Fonts\\arial.ttf",
            "C:\\Windows\\Fonts\\verdana.ttf",
            NULL
        };
        ImFontConfig cfg;
        cfg.OversampleH = 2;
        cfg.OversampleV = 1;
        cfg.PixelSnapH  = true;
        int loaded = 0;
        for (int i = 0; candidates[i]; i++) {
            if (GetFileAttributesA(candidates[i]) == INVALID_FILE_ATTRIBUTES) continue;
            s_menuFont = io.Fonts->AddFontFromFileTTF(candidates[i], 14.0f, &cfg);
            if (s_menuFont) {
                loaded = 1;
                zl_log(LOG_INFO, "menu font: %s @14px", candidates[i]);
                break;
            }
        }
        if (!loaded) {
            ImFontConfig dcfg;
            dcfg.SizePixels = 13.0f;
            s_menuFont = io.Fonts->AddFontDefault(&dcfg);
            zl_log(LOG_WARN, "menu font: no system TTF found, using the built-in atlas");
        }
        io.FontDefault = s_menuFont;
        io.FontGlobalScale = 1.0f;
        io.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);
        io.FontAllowUserScaling = false;
    }

    /* This renderer rasterizes on the CPU and blits with OpenGL 1.1.
     * Do not compile an unused shader or depend on GL2 entry points. */
    zl_log(LOG_INFO, "menuwin: software rasterizer with OpenGL 1.1 blit");

    unsigned char* pix = NULL; int fw = 0, fh = 0;
    io.Fonts->GetTexDataAsRGBA32(&pix, &fw, &fh);
    { GLint mx = 0; glGetIntegerv(GL_MAX_TEXTURE_SIZE, &mx); s_maxTex = mx; }
    glGenTextures(1, &s_fontTex);
    glBindTexture(GL_TEXTURE_2D, s_fontTex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, fw, fh, 0, GL_RGBA,
                 GL_UNSIGNED_BYTE, pix);
    zl_log(LOG_INFO, "menuwin atlas: %dx%d", fw, fh);

    /* The software rasterizer reads ImGui's live atlas directly. Keep the
     * CPU pixels alive rather than maintaining a potentially stale copy. */
    io.Fonts->SetTexID((ImTextureID)(intptr_t)s_fontTex);

    zl_ui_unlock();
    zl_log(LOG_OK, "menu window up (%dx%d, atlas %dx%d)", s_w, s_h, fw, fh);
    return 1;
}

/* ------------------------------------------------------------------ */
/*  one frame: build the UI, rasterise it, blit it                    */
/* ------------------------------------------------------------------ */
static void render_and_present(void)
{
    /* One UI unit maps to one client pixel in the menu's own window.
     * Re-read the client size rather than relying on an old WM_SIZE message;
     * this does not resize the menu, the emulator, or the desktop. */
    RECT client;
    if (!s_wnd || !GetClientRect(s_wnd, &client)) return;
    int cw = client.right - client.left, ch = client.bottom - client.top;
    if (cw <= 0 || ch <= 0) return;
    s_w = cw; s_h = ch;

    zl_ui_lock();               /* recursive: build_frame re-takes it */

    /* Pin OUR context before touching ImGui::GetIO(): the other lane leaves
     * its own context current, and events fed to the wrong context are simply
     * dropped -- the panel hovers but never clicks. */
    ImGui::SetCurrentContext(s_ctx);

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)s_w, (float)s_h);
    io.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);
    io.FontGlobalScale = 1.0f;
    io.FontAllowUserScaling = false;
    if (s_menuFont) io.FontDefault = s_menuFont;
    io.DeltaTime   = 1.0f / 60.0f;

    /* Pointer and keyboard state come from ImGui_ImplWin32, which the
     * window procedure feeds. This used to sample GetAsyncKeyState every
     * frame AND drain a queue of button messages -- two sources that
     * disagreed on scaled displays, with the result that clicks hit
     * nothing. One source now: Windows' own messages. */
    ImGui_ImplWin32_NewFrame();

    /* build_frame() owns NewFrame and Render. This lane builds, then turns
     * the result into pixels itself. */
    if (!zl_ui_frame_window(s_w, s_h)) { zl_ui_unlock(); return; }

    /* Second driver for the window corners. The swap hook covers the
     * emulator's own frames, but if that hook is not installed -- or the
     * host is on a lane we never see -- the panel drawing is still a
     * heartbeat we can hang the region on. Both lanes end up calling the
     * same idempotent function, which only touches the window when the
     * radius or the size actually changed. */
    {
        static DWORD last = 0;
        DWORD now = GetTickCount();
        if (!last || now - last > 500) {
            last = now;
            zl_round_tick(NULL);
        }
    }

    ImDrawData* dd = ImGui::GetDrawData();
    if (!dd) { zl_ui_unlock(); return; }

    wglMakeCurrent(s_dc, s_rc);

    glViewport(0, 0, s_w, s_h);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDisable(GL_SCISSOR_TEST);
    /* no glClear: the blit below covers every pixel of the client area with
     * the menu's own background, so clearing first is a full framebuffer
     * write that is immediately overwritten. */

    /* The live atlas belongs to this context and the UI lock is held. */
    unsigned char* atlas_pixels = NULL;
    int atlas_width = 0, atlas_height = 0;
    io.Fonts->GetTexDataAsRGBA32(&atlas_pixels, &atlas_width, &atlas_height);
    if (atlas_pixels && atlas_width > 0 && atlas_height > 0) {
        static unsigned int* px = NULL;
        static int cap = 0;
        const int need = s_w * s_h;
        if (cap < need) {
            free(px);
            px = (unsigned int*)malloc((size_t)need * 4u);
            cap = px ? need : 0;
        }
        if (px) {
            /* Clear the entire pixel buffer before drawing this frame. */
            const unsigned int bg = 0xFF0F0A09u;
            for (size_t i = 0, count = (size_t)s_w * (size_t)s_h; i < count; ++i)
                px[i] = bg;

            zlm_raster(dd, px, s_w, s_h, atlas_pixels, atlas_width, atlas_height);

            glDisable(GL_TEXTURE_2D);
            glDisable(GL_BLEND);
            glMatrixMode(GL_PROJECTION); glLoadIdentity();
            glMatrixMode(GL_MODELVIEW);  glLoadIdentity();
            glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
            glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
            glPixelStorei(GL_UNPACK_SKIP_PIXELS, 0);
            glPixelStorei(GL_UNPACK_SKIP_ROWS, 0);

            /* glDrawPixels reads its first row as the BOTTOM of the image and
             * ImGui lays out with y downwards: flip on the way out. */
            glRasterPos2f(-1.0f, 1.0f);
            glPixelZoom(1.0f, -1.0f);
            glDrawPixels(s_w, s_h, GL_RGBA, GL_UNSIGNED_BYTE, px);
            glPixelZoom(1.0f, 1.0f);
        }
    }

    {
        /* straight to the driver: running this through the DLL's own
         * wglSwapBuffers hook would drag the emulator's fragment pipeline
         * into a window that does not want it */
        static BOOL (WINAPI* realSwap)(HDC) = NULL;
        if (!realSwap) {
            HMODULE gdi = GetModuleHandleA("gdi32.dll");
            realSwap = (BOOL (WINAPI*)(HDC))GetProcAddress(gdi, "SwapBuffers");
        }
        if (realSwap) realSwap(s_dc); else SwapBuffers(s_dc);
    }
    zl_ui_unlock();
}

/* F2 is active only while the emulator or this panel is foreground. The
 * low-level hook lives on this window's message-pumping thread and only
 * posts a message; it does not draw, log or subclass any host window. */
static int f2_focus_is_ours(void)
{
    HWND foreground = GetForegroundWindow();
    DWORD pid = 0;
    if (!foreground) return 0;
    GetWindowThreadProcessId(foreground, &pid);
    return pid == GetCurrentProcessId();
}

static LRESULT CALLBACK f2_hook_proc(int code, WPARAM wp, LPARAM lp)
{
    if (code == HC_ACTION) {
        const KBDLLHOOKSTRUCT* key = (const KBDLLHOOKSTRUCT*)lp;
        if ((int)key->vkCode == ZL_TOGGLE_VK) {
            const int down = (wp == WM_KEYDOWN || wp == WM_SYSKEYDOWN);
            const int up = (wp == WM_KEYUP || wp == WM_SYSKEYUP);
            s_lastF2Hook = GetTickCount();
            s_f2HookSeen = 1;
            if (down) {
                if (!s_f2HookDown) {
                    s_f2HookDown = 1;       /* ignore key-repeat messages */
                    s_f2Swallow = f2_focus_is_ours();
                    if (s_f2Swallow && !PostMessageA(s_wnd, ZLW_F2_MESSAGE, 0, 0))
                        s_f2Swallow = 0;
                }
                if (s_f2Swallow) return 1;
            } else if (up) {
                int swallow = s_f2Swallow;
                s_f2HookDown = 0;
                s_f2Swallow = 0;
                if (swallow) return 1;
            }
        }
    }
    return CallNextHookEx(s_f2Hook, code, wp, lp);
}

static void f2_hook_install(void)
{
    HMODULE module = NULL;
    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCSTR)(void*)&f2_hook_proc, &module);
    s_f2Hook = SetWindowsHookExA(WH_KEYBOARD_LL, f2_hook_proc, module, 0);
    if (s_f2Hook) zl_log(LOG_INFO, "F2 listener installed on menu thread");
    else zl_log(LOG_WARN, "F2 hook unavailable (%lu); using key polling", GetLastError());
}

/* A foreground-scoped fallback also keeps F2 usable if Windows removes a
 * hook. Recent hook events are suppressed here to avoid a double toggle. */
static void hotkey_poll(void)
{
    static int previous = 0;
    int down = (GetAsyncKeyState(ZL_TOGGLE_VK) & 0x8000) ? 1 : 0;
    DWORD now = GetTickCount();
    if (down && !previous && f2_focus_is_ours() &&
        (!s_f2HookSeen || now - s_lastF2Hook > 250u))
        zl_open_menu_toggle();
    previous = down;
}

static DWORD WINAPI menu_thread(LPVOID)
{
    /* The menu's own thread uses physical pixels; this does not change the
     * process-wide or emulator render-thread DPI awareness. */
    ZLNativeDpiScope native_dpi;
    /* Texture reduction belongs to the game, not this menu's font atlas. */
    zl_lite_own_pass(1);
    if (!window_create()) {
        zl_lite_own_pass(0);
        InterlockedExchange(&s_alive, 0);
        return 0;
    }

    f2_hook_install();
    if (g_state.menuWanted) {
        ShowWindow(s_wnd, SW_SHOWNOACTIVATE);
        SetWindowPos(s_wnd, HWND_TOP, 0, 0, 0, 0,
                     SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW | SWP_NOACTIVATE);
        apply_round_region(s_wnd);
        UpdateWindow(s_wnd);
    }

    while (!s_quit) {
        MSG msg;
        while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) { InterlockedExchange(&s_quit, 1); break; }
            TranslateMessage(&msg);
            DispatchMessageA(&msg);
        }
        if (s_quit) break;

        zl_dispatch_pending_actions(); /* ADB also works without a GL present */
        hotkey_poll();              /* foreground-scoped fallback */
        zl_menuwin_sync();          /* menuWanted -> the window, every tick */
        /* While hidden, poll faster: this is the state the user gets stuck
         * in, and a 60 ms window can miss a quick tap of F2. */
        if (!s_wnd || !IsWindowVisible(s_wnd)) { Sleep(20); continue; }
        render_and_present();
        zl_settings_tick();      /* flush a pending ini write, once */
        Sleep(16);               /* ~60 fps is plenty for a settings panel and
                                  * costs half the frames of the old 8 ms spin,
                                  * in the same process as the emulator */
    }

    if (s_f2Hook) { UnhookWindowsHookEx(s_f2Hook); s_f2Hook = NULL; }
    if (s_ctx) {
        zl_ui_lock();
        ImGui::SetCurrentContext(s_ctx);
        ImGui_ImplWin32_Shutdown();
        if (s_fontTex) glDeleteTextures(1, &s_fontTex);
        ImGui::DestroyContext(s_ctx);
        s_ctx = NULL;
        s_menuFont = NULL;
        zl_ui_bind_window_context(NULL);
        zl_ui_unlock();
    }
    wglMakeCurrent(NULL, NULL);
    if (s_rc) { wglDeleteContext(s_rc); s_rc = NULL; }
    if (s_dc) { ReleaseDC(s_wnd, s_dc); s_dc = NULL; }
    if (s_wnd) { DestroyWindow(s_wnd); s_wnd = NULL; }

    zl_lite_own_pass(0);
    InterlockedExchange(&s_alive, 0);
    zl_log(LOG_INFO, "menu window thread exited");
    return 0;
}

/* ------------------------------------------------------------------ */
extern "C" int zl_menuwin_start(void)
{
    if (InterlockedCompareExchange(&s_alive, 1, 0) != 0) return 1;
    InterlockedExchange(&s_quit, 0);
    HANDLE h = CreateThread(NULL, 0, menu_thread, NULL, 0, NULL);
    if (!h) { InterlockedExchange(&s_alive, 0); return 0; }
    CloseHandle(h);
    return 1;
}

/* Runs on the window thread every iteration. The window's visibility used to
 * be governed only by the first ShowWindow() at creation, so once the user
 * pressed the titlebar X (which hides, rather than destroys) nothing ever
 * brought it back: the window existed, the hotkey flipped menuWanted, and no
 * code connected the two. This is that connection.
 *
 * It also means every way of asking for the menu -- F2, the
 * in-window hotkey, auto-open, and a future tray item -- goes through one
 * piece of state instead of each of them poking ShowWindow() themselves. */
extern "C" void* zl_menuwin_hwnd(void) { return (void*)s_wnd; }

extern "C" void zl_menuwin_sync(void)
{
    if (!s_wnd) {
        /* No window at all. If the user wants the menu, build a new one --
         * that is the rebuild path after a destroy we did not ask for. */
        if (g_state.menuWanted) {
            if (!window_create()) return;
            ShowWindow(s_wnd, SW_SHOWNOACTIVATE);
            SetWindowPos(s_wnd, HWND_TOPMOST, 0, 0, 0, 0,
                         SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW | SWP_NOACTIVATE);
            zl_log(LOG_INFO, "menu window rebuilt and shown");
        }
        return;
    }

    /* The handle can outlive the window. WM_DESTROY fires for reasons that
     * have nothing to do with us -- the WM closing the app, a session
     * ending, DefWindowProc on an unhandled close -- and once it has, s_wnd
     * is a number that no longer names anything, while this thread is still
     * inside its message loop for one more iteration. Calling ShowWindow or
     * SetWindowPos on that is how a menu that was only hidden turns into a
     * menu that is gone for good.
     *
     * IsWindow() is the cheap, correct question: it asks the WM whether the
     * handle is still a window. If it is not, the thread is finishing and
     * there is nothing to show. */
    if (!IsWindow(s_wnd)) { s_wnd = NULL; return; }

    int want = g_state.menuWanted ? 1 : 0;
    int shown = IsWindowVisible(s_wnd) ? 1 : 0;
    if (want == shown) return;

    if (want) {
        ShowWindow(s_wnd, SW_SHOWNOACTIVATE);
        SetWindowPos(s_wnd, HWND_TOPMOST, 0, 0, 0, 0,
                     SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW | SWP_NOACTIVATE);
        zl_log(LOG_INFO, "menu window shown");
    } else {
        ShowWindow(s_wnd, SW_HIDE);
        zl_log(LOG_INFO, "menu window hidden");
    }
}

extern "C" void zl_menuwin_show(int on)
{
    if (!s_wnd) {
        if (on) zl_menuwin_start();
        return;
    }
    if (on) {
        ShowWindow(s_wnd, SW_SHOWNOACTIVATE);
        /* HWND_TOPMOST, not HWND_TOP: the emulator goes fullscreen and
         * raises itself, and a normal window ends up behind it -- the menu
         * existing but unreachable. TOPMOST is the only z-order that
         * survives the host's own SetForegroundWindow. */
        SetWindowPos(s_wnd, HWND_TOPMOST, 0, 0, 0, 0,
                     SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW | SWP_NOACTIVATE);
        zl_log(LOG_INFO, "menu window shown");
    } else {
        ShowWindow(s_wnd, SW_HIDE);
        zl_log(LOG_INFO, "menu window hidden");
    }
}

/* Is this DC one of ours? The host hooks wglSwapBuffers process-wide, so our
 * own window swaps straight into the emulator's frame pipeline. Telling them
 * apart is the difference between a menu and a crash. */
extern "C" int zl_menuwin_is_ours(void* hdc)
{
    if (!hdc) return 0;
    if ((void*)s_dc == hdc) return 1;
    {
        HWND w = WindowFromDC((HDC)hdc);
        if (w && w == s_wnd) return 1;
    }
    return 0;
}

extern "C" int zl_menuwin_visible(void)
{
    return (s_wnd && IsWindowVisible(s_wnd)) ? 1 : 0;
}

extern "C" void zl_menuwin_toggle(void)
{
    zl_open_menu_toggle();
}
