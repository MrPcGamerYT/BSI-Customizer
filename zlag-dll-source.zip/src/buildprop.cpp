/* No new vendor/system properties are applied. An explicit, best-effort
 * cleanup can remove only this tool's old, exactly marked block. It never
 * requests root or remounts a partition. */
#include "common.h"
#include "safe_adb.h"

#define ZL_DEV_VENDOR "/vendor/build.prop"
#define ZL_DEV_SYSTEM "/system/build.prop"

typedef struct PropResult {
    int absent, clean, found, removed, readonly, malformed, backupExists, failed, symlink, metadata;
} PropResult;

static void prop_line(const char* line, void* opaque)
{
    PropResult* r = (PropResult*)opaque;
    if (strstr(line, "ZL-PROP-ABSENT")) r->absent = 1;
    if (strstr(line, "ZL-PROP-CLEAN")) r->clean = 1;
    if (strstr(line, "ZL-PROP-FOUND")) r->found = 1;
    if (strstr(line, "ZL-PROP-REMOVED")) r->removed = 1;
    if (strstr(line, "ZL-PROP-READONLY")) r->readonly = 1;
    if (strstr(line, "ZL-PROP-MALFORMED")) r->malformed = 1;
    if (strstr(line, "ZL-PROP-BACKUP-EXISTS")) r->backupExists = 1;
    if (strstr(line, "ZL-PROP-FAILED")) r->failed = 1;
    if (strstr(line, "ZL-PROP-LINK")) r->symlink = 1;
    if (strstr(line, "ZL-PROP-METADATA")) r->metadata = 1;
}

extern "C" void zl_buildprop_apply(void)
{
    apply_log("[i] system and vendor properties remain unchanged by the safe profile");
}

extern "C" void zl_buildprop_persist(void)
{
    apply_log("[i] permanent property overrides are disabled; nothing was written");
}

static void inspect_one(const char* adb, const char* serial, const char* file, const char* label)
{
    char args[1200];
    int n = _snprintf(args, sizeof(args),
        "shell \"if [ ! -f %s ]; then echo ZL-PROP-ABSENT; "
        "elif [ ! -r %s ]; then echo ZL-PROP-FAILED; exit 1; "
        "elif grep -q '^# ===== Z-LAG BUILD PROP =====$' %s 2>/dev/null || "
        "grep -q '^# ===== Z-LAG END =====$' %s 2>/dev/null; "
        "then echo ZL-PROP-FOUND; else echo ZL-PROP-CLEAN; fi\"", file, file, file, file);
    if (n < 0 || n >= (int)sizeof(args)) { apply_log("[!!] %s check failed", label); return; }
    PropResult r = {0};
    int rc = zl_safe_adb_call(adb, serial, args, prop_line, &r);
    if (rc != 0) apply_log("[!!] %s check failed", label);
    else if (r.found) apply_log("[!] %s: older marked overrides found", label);
    else if (r.clean) apply_log("[ok] %s: no marked overrides found", label);
    else if (r.absent) apply_log("[i] %s: not present on this instance", label);
    else apply_log("[!!] %s check returned no result", label);
}

extern "C" void zl_buildprop_diff(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    apply_log("--- Check for older property overrides (read-only) ---");
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, sizeof(serial))) return;
    inspect_one(adb, serial, ZL_DEV_VENDOR, "Vendor");
    inspect_one(adb, serial, ZL_DEV_SYSTEM, "System");
}

static void revert_one(const char* adb, const char* serial, const char* file, const char* label)
{
    /* Exactly one ordered marker pair is required. Back up first, build a
     * separate candidate, and require matching owner/mode/SELinux label before
     * atomic replacement. Never overwrite a backup or follow a symlink. */
    char args[3072];
    int n = _snprintf(args, sizeof(args),
        "shell \"f=%s; "
        "if [ ! -f $f ]; then echo ZL-PROP-ABSENT; exit 0; fi; "
        "if [ -L $f ]; then echo ZL-PROP-LINK; exit 0; fi; "
        "if [ ! -r $f ]; then echo ZL-PROP-FAILED; exit 1; fi; "
        "a=$(grep -c '^# ===== Z-LAG BUILD PROP =====$' $f); "
        "b=$(grep -c '^# ===== Z-LAG END =====$' $f); "
        "case $a:$b in *[!0-9:]*|:*|*:) echo ZL-PROP-FAILED; exit 1;; esac; "
        "if [ $a -eq 0 ] && [ $b -eq 0 ]; then echo ZL-PROP-CLEAN; exit 0; fi; "
        "if [ $a -ne 1 ] || [ $b -ne 1 ]; then echo ZL-PROP-MALFORMED; exit 0; fi; "
        "x=$(grep -n '^# ===== Z-LAG BUILD PROP =====$' $f | cut -d: -f1); "
        "y=$(grep -n '^# ===== Z-LAG END =====$' $f | cut -d: -f1); "
        "if [ $x -ge $y ]; then echo ZL-PROP-MALFORMED; exit 0; fi; "
        "if [ ! -w $f ]; then echo ZL-PROP-READONLY; exit 0; fi; "
        "q=${f}.zlag-before-revert; t=${f}.zlag-clean-new; "
        "if [ -e $q ] || [ -L $q ] || [ -e $t ] || [ -L $t ]; "
        "then echo ZL-PROP-BACKUP-EXISTS; exit 0; fi; "
        "if ! cp -p $f $q || ! cp -p $f $t; "
        "then rm -f $t; echo ZL-PROP-FAILED; exit 1; fi; "
        "if ! sed '/^# ===== Z-LAG BUILD PROP =====$/,/^# ===== Z-LAG END =====$/d' $f > $t; "
        "then rm -f $t; echo ZL-PROP-FAILED; exit 1; fi; "
        "if [ ! -s $t ] || grep -q '^# ===== Z-LAG BUILD PROP =====$' $t || "
        "! cmp -s $f $q; then rm -f $t; echo ZL-PROP-FAILED; exit 1; fi; "
        "m1=$(stat -c %%u:%%g:%%a $f 2>/dev/null); "
        "m2=$(stat -c %%u:%%g:%%a $t 2>/dev/null); "
        "z1=$(ls -Zd $f 2>/dev/null | awk '{print $1}'); "
        "z2=$(ls -Zd $t 2>/dev/null | awk '{print $1}'); "
        "case $m1:$m2 in *[!0-9:]*|:*|*:) rm -f $t; echo ZL-PROP-METADATA; exit 0;; esac; "
        "case $z1 in u:*) :;; *) rm -f $t; echo ZL-PROP-METADATA; exit 0;; esac; "
        "case $z2 in u:*) :;; *) rm -f $t; echo ZL-PROP-METADATA; exit 0;; esac; "
        "if [ $m1 != $m2 ] || [ $z1 != $z2 ]; "
        "then rm -f $t; echo ZL-PROP-METADATA; exit 0; fi; "
        "if ! mv -f $t $f; then rm -f $t; echo ZL-PROP-FAILED; exit 1; fi; "
        "echo ZL-PROP-REMOVED\"", file);
    if (n < 0 || n >= (int)sizeof(args)) { apply_log("[!!] %s cleanup failed", label); return; }
    PropResult r = {0};
    int rc = zl_safe_adb_call(adb, serial, args, prop_line, &r);
    if (rc == 0 && r.removed)
        apply_log("[ok] %s: marked block removed; a backup was kept", label);
    else if (rc == 0 && r.clean)
        apply_log("[i] %s: no marked block to remove", label);
    else if (rc == 0 && r.absent)
        apply_log("[i] %s: not present on this instance", label);
    else if (rc == 0 && r.readonly)
        apply_log("[!!] %s: read-only, so no change was made", label);
    else if (rc == 0 && r.malformed)
        apply_log("[!!] %s: markers are incomplete or ambiguous; left untouched", label);
    else if (rc == 0 && r.backupExists)
        apply_log("[!!] %s: existing backup preserved; left untouched", label);
    else if (rc == 0 && r.symlink)
        apply_log("[!!] %s: linked file; left untouched for safety", label);
    else if (rc == 0 && r.metadata)
        apply_log("[!!] %s: file security metadata could not be verified; left untouched", label);
    else
        apply_log("[!!] %s: cleanup failed or could not be verified", label);
}

extern "C" void zl_buildprop_revert(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    apply_log("--- Remove older marked property overrides ---");
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, sizeof(serial))) return;
    revert_one(adb, serial, ZL_DEV_VENDOR, "Vendor");
    revert_one(adb, serial, ZL_DEV_SYSTEM, "System");
    apply_log("[i] no root or remount was requested; read-only files need separate recovery");
    apply_log("[i] restarting the instance may be needed; unsaved old runtime changes may remain");
}
