/* menuwin.h -- the menu as a standalone Windows window */
#ifndef ZLAG_MENUWIN_H
#define ZLAG_MENUWIN_H

#ifdef __cplusplus
extern "C" {
#endif

int  zl_menuwin_start(void);     /* create the window + thread (idempotent) */
void zl_menuwin_show(int on);    /* show/hide it                             */
int  zl_menuwin_visible(void);
int  zl_menuwin_is_ours(void* hdc);
void zl_menuwin_toggle(void);
void zl_menuwin_sync(void);      /* menuWanted -> window, every tick        */
void* zl_menuwin_hwnd(void);     /* the HWND, for dragging from inside ImGui */

#ifdef __cplusplus
}
#endif
#endif
