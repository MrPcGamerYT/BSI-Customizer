/* =====================================================================
 *  input.c  --  window subclass, hotkey, ImGui input feed
 *
 *  Installed from the GL thread on first present, on the window that
 *  owns the device context (the emulator's render window, usually a
 *  child of the BlueStacks frame).  SetWindowsHookEx is NOT used on
 *  purpose: a subclass cannot trip anti-cheat/anti-hook behaviour and
 *  gets uninstalled with the window.
 * ===================================================================== */
#include "common.h"
#include "menuwin.h"
#include "zlag_imgui.h"

extern void zl_settings_save(void);

static WNDPROC s_oldProc = NULL;

/* The collapsed launcher's screen rect, published by the UI thread each
 * frame so the window thread can decide whether a click belongs to the
 * launcher or to the game. Plain ints: a torn read at worst mis-hits one
 * click, and only while the panel is being resized.                    */
static volatile LONG s_launch[4] = {18, 18, 0, 0};

/* dpi/96 of the window we are subclassed on; 96 unless the host says
 * otherwise. Guards every cursor -> panel-space conversion below. */
static int s_dpi = 96;

/* No dpi_scale() any more, and that is the fix.
 *
 * Every rectangle published to this file (zl_launcher_rect, zl_panel_rect)
 * is in CLIENT pixels -- the UI lays itself out against GetClientRect and
 * ImGui's DisplaySize, which is client pixels too. Cursor messages here are
 * also client pixels. Both sides are already in the same space, so scaling
 * the cursor by dpi/96 before the compare multiplied one side by 1.25/1.5/
 * 2.0 and nothing else: at any display scale other than 100% the button
 * stopped answering clicks, and the panel edge went dead. The overlay is
 * now dpi-agnostic by construction -- it never needs to know the dpi, which
 * is strictly better than getting the factor right. s_dpi is kept for the
 * log line only. */

/* The open panel's rect, same contract as the launcher: four plain ints,
 * published by the UI thread once a frame. Zero size = no panel. */
static volatile LONG s_panel[4] = {0, 0, 0, 0};

void zl_panel_rect(int x, int y, int w, int h)
{
    s_panel[0] = x; s_panel[1] = y;
    s_panel[2] = x + w; s_panel[3] = y + h;
}

static int panel_contains(int x, int y)
{
    LONG x0 = s_panel[0], y0 = s_panel[1];
    LONG x1 = s_panel[2], y1 = s_panel[3];
    if (x1 <= x0 || y1 <= y0) return 0;
    return x >= x0 && x < x1 && y >= y0 && y < y1;
}

/* Called once when the subclass goes in: the panel is laid out for the
 * emulator's drawable size, so a scaled display has to be accounted for
 * from the very first hit test, not from the first WM_DPICHANGED. */
void zl_input_set_dpi(int dpi)
{
    if (dpi > 0) s_dpi = dpi;
}

void zl_launcher_rect(int x, int y, int w, int h)
{
    s_launch[0] = x; s_launch[1] = y;
    s_launch[2] = x + w; s_launch[3] = y + h;
    /* mirror into the published state so the self-test can report it */
    InterlockedExchange(&g_state.launcherX, x);
    InterlockedExchange(&g_state.launcherY, y);
    InterlockedExchange(&g_state.launcherW, w);
    InterlockedExchange(&g_state.launcherH, h);
}

int zl_launcher_contains(int x, int y)
{
    LONG x0 = s_launch[0], y0 = s_launch[1];
    LONG x1 = s_launch[2], y1 = s_launch[3];
    if (x1 <= x0 || y1 <= y0) return 0;          /* not published yet */
    /* 6 px of slack: the arrow is a big target, do not make the player
     * pixel-hunt it at 4K */
    return x >= x0 - 6 && x <= x1 + 6 && y >= y0 - 6 && y <= y1 + 6;
}
/* The external build owns its own window and message loop.  In that build
 * never subclass the emulator, register global keyboard shortcuts, or attach
 * raw input to a host window. F2 is watched by the menu thread instead. */
#ifdef ZL_DEFAULT_MENUWINDOW
void zl_open_menu_toggle(void)
{
    LONG old_value, new_value;
    do {
        old_value = InterlockedCompareExchange(&g_state.menuWanted, 0, 0);
        new_value = old_value ? 0 : 1;
    } while (InterlockedCompareExchange(&g_state.menuWanted, new_value, old_value) != old_value);
    InterlockedExchange(&g_state.menuOpen, new_value);
    zl_log(LOG_INFO, "F2 -> menu %s", new_value ? "open" : "closed");
}
void zl_input_install(HWND target) { (void)target; }
void zl_input_install_fallback_hook(void) { }
void zl_hotkey_register(void) { }
void zl_hotkey_unregister(void) { }
void zl_input_watchdog(void) { zl_autoopen_tick(); }
#else
static HWND    s_hwnd    = NULL;
static int     s_subclassed = 0;

/* ------------------------------------------------------------------ */
/* Several lanes can see the same physical key press (window subclass, raw
 * input, low-level hook, WM_CHAR, RegisterHotKey). Any two of them firing
 * for one press cancel each other out -- the panel opens and closes in the
 * same millisecond and the user sees nothing. One gate for all lanes. */
static DWORD s_lastToggle = 0;

void zl_open_menu_toggle(void)
{
    DWORD now = GetTickCount();
    if (now - s_lastToggle < 220) return;      /* same physical press */
    s_lastToggle = now;

    /* Internal menu: "open" is a flag the render lane reads, nothing more.
     * The panel is drawn over the game inside the emulator's own frame, so
     * there is no window to show, hide or keep in sync. */
    LONG v = g_state.menuWanted ? 0 : 1;
    InterlockedExchange(&g_state.menuWanted, v);
    InterlockedExchange(&g_state.menuOpen, v);
    zl_log(LOG_INFO, "hotkey -> menu %s", v ? "open" : "closed");
    /* No corner flash any more: the only thing allowed on the emulator's
     * surface is the OPEN / CLOSE button, and the panel appearing is its
     * own proof that the press arrived. */
    if (v) zl_selftest();           /* opening: refresh the report */
}

/* single producer (the window thread) / single consumer (the GL thread) */
static void push_event(LONG type, LONG a, LONG b)
{
    LONG h = g_in.head;
    if (h - g_in.tail >= ZL_IN_RING) return;      /* full: drop, never block */
    g_in.ring[h & (ZL_IN_RING - 1)].type = type;
    g_in.ring[h & (ZL_IN_RING - 1)].a = a;
    g_in.ring[h & (ZL_IN_RING - 1)].b = b;
    InterlockedExchange(&g_in.head, h + 1);
}

/* True when the pressed key completes the configured chord.
 * Ctrl is checked live (GetKeyState) rather than by tracking our own
 * WM_KEYDOWN for VK_CONTROL -- that survives focus changes and the
 * key-repeat storms Windows sends while the user holds the key down. */
static int is_chord(int vk)
{
    /* ---- F2, on its own ---------------------------------------------
     * No modifier, so there is no state to agree on and no chord that can
     * half-arrive. Esc stays entirely with the emulator, which uses it to
     * leave full screen. */
    if (vk == ZL_TOGGLE_VK) return 1;
    if (vk == VK_ESCAPE)    return 0;   /* still the emulator's key */

    if (vk != g_cfg.hotkeyVk) return 0;
    if (!g_cfg.hotkeyCtrl) return 1;

    /* Ctrl+Shift+7 and Ctrl+Alt+7 are handled by the registered system
     * hotkey instead (see zl_hotkey_register). They are supersets of
     * Ctrl+7, so without this guard one press matches both lanes and the
     * panel toggles twice -- open then immediately closed. */
    if (GetAsyncKeyState(VK_SHIFT)   & 0x8000) return 0;
    if (GetAsyncKeyState(VK_MENU)    & 0x8000) return 0;
    /* Three independent ways to see the Ctrl half of the chord, because an
     * emulator window that owns a game-loop thread will happily report Ctrl
     * as "up" at the moment it forwards the key to us:
     *   1. the live async state (survives our own SetCapture games)
     *   2. this thread's queue state (the window really has focus)
     *   3. GetKeyState inside a plain WM_KEYDOWN -- the documented path
     * Only one of them has to agree.                                          */
    if (GetAsyncKeyState(VK_CONTROL) & 0x8000) return 1;
    if (GetKeyState(VK_CONTROL)     & 0x8000) return 1;
    if (GetAsyncKeyState(VK_LCONTROL) & 0x8000) return 1;
    if (GetAsyncKeyState(VK_RCONTROL) & 0x8000) return 1;
    return 0;
}

static void push_key(WPARAM vk, int down)
{
    if (vk >= 512) return;
    push_event(ZL_EV_KEY, (LONG)vk, down ? 1 : 0);
}

static void push_pos(LPARAM lp)
{
    LONG x = (LONG)(short)LOWORD(lp);
    LONG y = (LONG)(short)HIWORD(lp);
    InterlockedExchange(&g_in.mousePos[0], x);
    InterlockedExchange(&g_in.mousePos[1], y);
    push_event(ZL_EV_POS, x, y);
}

static LRESULT CALLBACK zl_wndproc(HWND h, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
        if (is_chord((int)wp)) {
            /* swallow the auto-repeat: Windows sends WM_KEYDOWN every
             * ~30 ms while a key is held, which would strobe the panel */
            if (!(lp & 0x40000000)) zl_open_menu_toggle();
            return 0;
        }
        if (g_state.menuOpen && (int)wp == VK_ESCAPE) {
            InterlockedExchange(&g_state.menuWanted, 0);
            return 0;
        }
        if (g_state.menuOpen) push_key(wp, 1);
        break;

    case WM_KEYUP:
    case WM_SYSKEYUP:
        if (g_state.menuOpen) push_key(wp, 0);
        /* fall through: let the emulator see the release too */
        if (g_state.menuOpen) push_key(wp, 0);
        break;

    case WM_CHAR:
        /* Second lane for the hotkey. Some hosts (BlueStacks' Qt frame in
         * particular) never deliver WM_KEYDOWN to the GL child window but
         * do deliver WM_CHAR after TranslateMessage. If the character is
         * our hotkey and Ctrl is down, toggle here as well -- is_chord()
         * dedupes nothing, so gate on a timestamp instead. */
        if (g_cfg.hotkeyVk != VK_ESCAPE &&
            g_cfg.hotkeyVk < 128 && (int)wp == g_cfg.hotkeyVk &&
            g_cfg.hotkeyCtrl && (GetAsyncKeyState(VK_CONTROL) & 0x8000) &&
            !(GetAsyncKeyState(VK_SHIFT) & 0x8000) &&
            !(GetAsyncKeyState(VK_MENU)  & 0x8000)) {
            static DWORD lastCharToggle = 0;
            DWORD now = GetTickCount();
            if (now - lastCharToggle > 250) {
                lastCharToggle = now;
                zl_open_menu_toggle();
                return 0;
            }
        }
        if (g_state.menuOpen) {
            push_event(ZL_EV_CHAR, (LONG)wp, 0);
            return 0;
        }
        break;

    case WM_MOUSEMOVE:
        /* always track: ImGui needs a valid cursor position even before a
         * click, and the panel can open while the mouse is already inside */
        push_pos(lp);
        if (zl_launcher_contains((int)(short)LOWORD(lp),
                                 (int)(short)HIWORD(lp)))
            return 0;      /* the cursor is over the button: do not pass it on */
        break;

    case WM_LBUTTONDOWN: case WM_LBUTTONUP:
    case WM_RBUTTONDOWN: case WM_RBUTTONUP:
    case WM_MBUTTONDOWN: case WM_MBUTTONUP: {
        push_pos(lp);
        {
            /* only the left button can hit the launcher */
            int onLauncher = (msg == WM_LBUTTONDOWN || msg == WM_LBUTTONUP) &&
                             zl_launcher_contains((int)(short)LOWORD(lp),
                                                  (int)(short)HIWORD(lp));
            /* ONLY the button may eat a click. This used to be
             * "g_state.menuOpen || onLauncher", and g_state.menuOpen is true
             * whenever the menu WINDOW is open -- which it is from the second
             * frame of every launch. The emulator then captured the mouse for
             * as long as the window stayed open, and the host's own mouse
             * handling (SetCursorPos on mouse move -- the pattern every
             * DirectInput-style game uses) fought the capture for control of
             * the cursor. That is exactly "the menu becomes unresponsive and
             * the picture jumps around". The menu window has its own HWND and
             * its own mouse handling; it needs nothing from this one. */
            /* The panel is open and the click landed inside it: that click
             * belongs to the panel, not the game. */
            int onPanel = g_state.menuOpen &&
                          panel_contains((int)(short)LOWORD(lp),
                                         (int)(short)HIWORD(lp));

            if (onLauncher || onPanel) {
                int btn = (msg == WM_LBUTTONDOWN || msg == WM_LBUTTONUP) ? 0 :
                          (msg == WM_RBUTTONDOWN || msg == WM_RBUTTONUP) ? 1 : 2;
                int down = (msg == WM_LBUTTONDOWN || msg == WM_RBUTTONDOWN ||
                            msg == WM_MBUTTONDOWN);
                push_event(ZL_EV_BTN, btn, down);
                if (!down) ReleaseCapture();
                else SetCapture(h);
                return 0;      /* swallowed: the game never sees it */
            }
            /* Everywhere else the click is the game's. No capture, no
             * swallow: this is the whole point of the internal lane. */
        }
        break;
    }

    case WM_MOUSEWHEEL:
        /* WM_MOUSEWHEEL carries SCREEN coordinates while everything else
         * here is client coordinates, and the cursor that matters is the
         * one ImGui was last told about. This used to swallow the wheel
         * anywhere on screen whenever the panel happened to be open, so
         * scrolling inside the emulator went dead. Only the panel takes
         * it now. */
        if (g_state.menuOpen &&
            panel_contains((int)g_in.mousePos[0], (int)g_in.mousePos[1])) {
            push_event(ZL_EV_WHEEL, (LONG)(short)HIWORD(wp) / WHEEL_DELTA, 0);
            return 0;
        }
        break;

    case WM_SETCURSOR:
        if (g_state.menuOpen && LOWORD(lp) == HTCLIENT) {
            SetCursor(LoadCursor(NULL, IDC_ARROW));
            return TRUE;
        }
        break;

    case WM_DPICHANGED:
        /* The panel is laid out in the emulator's drawable pixels. The
         * window rect and the raw mouse messages are in the window's
         * logical coordinates, which differ by a factor of dpi/96 on any
         * scaled display. Without knowing that factor the button rect and
         * the cursor live in two different spaces and the hit test misses
         * -- clicks land near, but not on, the button, and the panel looks
         * dead. Published so the hit tests can scale. */
        s_dpi = (int)LOWORD(wp);
        if (s_dpi <= 0) s_dpi = 96;
        break;
    case WM_KILLFOCUS:
    case WM_CAPTURECHANGED:
        /* Alt-tab, or anything that steals capture, in the middle of a
         * drag: the button-up never arrives, so ImGui keeps that button
         * latched down and every later hover behaves like a drag. This is
         * the classic "the menu went weird and stayed weird" state. Clear
         * it here, and let go of the capture we took. */
        if (GetCapture() == h) ReleaseCapture();
        push_event(ZL_EV_BTN, 0, 0);
        push_event(ZL_EV_BTN, 1, 0);
        push_event(ZL_EV_BTN, 2, 0);
        if (s_oldProc) return CallWindowProcA(s_oldProc, h, msg, wp, lp);
        break;
    }

    if (s_oldProc) return CallWindowProcA(s_oldProc, h, msg, wp, lp);
    return DefWindowProcA(h, msg, wp, lp);
}

/* ------------------------------------------------------------------ */
/* raw input as a second lane: some BlueStacks builds route keyboard   */
/* through a child window that never sees WM_KEYDOWN in the parent.    */
/* ------------------------------------------------------------------ */
static void ensure_raw(void)
{
    RAWINPUTDEVICE rid[2];
    rid[0].usUsagePage = 0x01; rid[0].usUsage = 0x06;   /* keyboard */
    rid[0].dwFlags = RIDEV_INPUTSINK; rid[0].hwndTarget = s_hwnd;
    rid[1].usUsagePage = 0x01; rid[1].usUsage = 0x02;   /* mouse    */
    rid[1].dwFlags = 0; rid[1].hwndTarget = s_hwnd;
    RegisterRawInputDevices(rid, 2, sizeof(RAWINPUTDEVICE));
}

void zl_input_install(HWND target)
{
    if (!target) return;
    if (s_subclassed && s_hwnd == target) return;

    if (!s_subclassed) {
        s_oldProc = (WNDPROC)SetWindowLongPtrA(target, GWLP_WNDPROC, (LONG_PTR)zl_wndproc);
        if (!s_oldProc) {
            zl_log(LOG_WARN, "could not subclass 0x%p (err %lu) -- hotkey via keyboard hook",
                   (void*)target, GetLastError());
        } else {
            s_subclassed = 1;
            s_hwnd = target;

            /* Ask the window what it thinks its dpi is. GetDpiForWindow is
             * Windows 10+; fall back to the device context, then to 96. A
             * wrong value here does not break the panel, it breaks the
             * hit test -- clicks land beside the button instead of on it. */
            {
                int dpi = 0;
                typedef UINT (WINAPI *PFN_GetDpiForWindow)(HWND);
                static PFN_GetDpiForWindow pGetDpi = NULL;
                static int tried = 0;
                if (!tried) {
                    tried = 1;
                    HMODULE u = GetModuleHandleA("user32.dll");
                    if (u) pGetDpi = (PFN_GetDpiForWindow)(void*)GetProcAddress(u, "GetDpiForWindow");
                }
                if (pGetDpi) dpi = (int)pGetDpi(target);
                if (!dpi) {
                    HDC dc = GetDC(target);
                    if (dc) { dpi = GetDeviceCaps(dc, LOGPIXELSX); ReleaseDC(target, dc); }
                }
                zl_input_set_dpi(dpi > 0 ? dpi : 96);
            }
            zl_log(LOG_OK, "window subclassed (F2 = panel, dpi %d, hit tests in client px)", s_dpi);
        }
    }
    ensure_raw();
}

/* ------------------------------------------------------------------ */
/* Fallback hotkey: a low-level keyboard hook is installed ONLY if the
 * subclass failed (e.g. protected frame windows). It is passive.      */
/* ------------------------------------------------------------------ */
static HHOOK s_kbHook = NULL;

static LRESULT CALLBACK kb_proc(int code, WPARAM wp, LPARAM lp)
{
    if (code == HC_ACTION) {
        KBDLLHOOKSTRUCT* k = (KBDLLHOOKSTRUCT*)lp;
        const int isKeyDown = (wp == WM_KEYDOWN || wp == WM_SYSKEYDOWN) &&
                              !(k->flags & LLKHF_UP);
        /* F2: one key, no modifier, swallowed so the game never sees it. */
        if ((int)k->vkCode == ZL_TOGGLE_VK) {
            if (isKeyDown) zl_open_menu_toggle();
            return 1;
        }
        else if ((int)k->vkCode == g_cfg.hotkeyVk && g_cfg.hotkeyCtrl) {
            if ((GetAsyncKeyState(VK_CONTROL) & 0x8000) &&
                !(GetAsyncKeyState(VK_SHIFT) & 0x8000) &&
                !(GetAsyncKeyState(VK_MENU)  & 0x8000)) {
                if (isKeyDown) zl_open_menu_toggle();
                return 1;
            }
        }
    }
    return CallNextHookEx(s_kbHook, code, wp, lp);
}

void zl_input_install_fallback_hook(void)
{
    if (s_kbHook) return;
    /* Test hook: ZLAG_NO_KBHOOK=1 stops this lane from arming at all, so a
     * rig run can prove the menu reopens with the hooks dead. Nothing in
     * the product reads it. */
    {
        char e[8];
        if (GetEnvironmentVariableA("ZLAG_NO_KBHOOK", e, sizeof(e)))
            { zl_log(LOG_WARN, "keyboard hook disabled by ZLAG_NO_KBHOOK"); return; }
    }
    /* Arm the low-level hook unconditionally, not only when the subclass
     * failed. Two reasons:
     *   - in exclusive fullscreen the host swaps to a different HWND and
     *     our subclass is on the old one
     *   - a subclassed window still misses keys the host pre-translates
     * The hook is passive; it does not inject and cannot trip anti-cheat. */
    s_kbHook = SetWindowsHookExA(WH_KEYBOARD_LL, kb_proc, NULL, 0);
    if (s_kbHook) zl_log(LOG_INFO, "keyboard hotkey hook armed (F2)");
    else zl_log(LOG_WARN, "WH_KEYBOARD_LL failed (err %lu)", GetLastError());
}

/* A registered system hotkey works with NO window, NO GL and NO focus:
 * RegisterHotKey delivers WM_HOTKEY to our own invisible message window.
 * That makes it a lane the emulator cannot swallow, which is exactly the
 * situation where "the menu does not open". Registered twice, once bare
 * and once with Ctrl, and torn down when the host stops.             */
static HWND s_hotWnd = NULL;
#define ZL_HOTKEY_ID   0x2A61   /* arbitrary, ours */
#define ZL_HOTKEY_ID2  0x2A62

static LRESULT CALLBACK hot_wndproc(HWND h, UINT m, WPARAM wp, LPARAM lp)
{
    if (m == WM_HOTKEY) {
        if (wp == ZL_HOTKEY_ID || wp == ZL_HOTKEY_ID2) {
            zl_open_menu_toggle();
            return 0;
        }
    }
    return DefWindowProcA(h, m, wp, lp);
}

void zl_hotkey_register(void)
{
    if (s_hotWnd) return;

    WNDCLASSA wc = {0};
    wc.lpfnWndProc = hot_wndproc;
    wc.hInstance = GetModuleHandleA(NULL);
    wc.lpszClassName = "ZLAGHOTKEY";
    RegisterClassA(&wc);                    /* already registered is fine */

    s_hotWnd = CreateWindowExA(0, "ZLAGHOTKEY", "zlag-hotkey", 0,
                               0, 0, 0, 0, HWND_MESSAGE, NULL, wc.hInstance, NULL);
    if (!s_hotWnd) {
        zl_log(LOG_WARN, "hotkey window failed (err %lu)", GetLastError());
        return;
    }

    UINT mods = (g_cfg.hotkeyCtrl ? MOD_CONTROL : 0) | MOD_NOREPEAT;
    if (RegisterHotKey(s_hotWnd, ZL_HOTKEY_ID, mods | MOD_SHIFT, g_cfg.hotkeyVk))
        zl_log(LOG_OK, "system hotkey registered: Ctrl+Shift+%c", (char)g_cfg.hotkeyVk);
    else
        zl_log(LOG_WARN, "Ctrl+Shift+%c already taken (err %lu)",
               (char)g_cfg.hotkeyVk, GetLastError());

    /* second chord, no modifier ambiguity: Shift+F9 style is what users
     * try when nothing else works, so register Ctrl+Alt+<key> as well */
    if (RegisterHotKey(s_hotWnd, ZL_HOTKEY_ID2, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT,
                       g_cfg.hotkeyVk))
        zl_log(LOG_OK, "system hotkey registered: Ctrl+Alt+%c", (char)g_cfg.hotkeyVk);
}

void zl_hotkey_unregister(void)
{
    if (!s_hotWnd) return;
    UnregisterHotKey(s_hotWnd, ZL_HOTKEY_ID);
    UnregisterHotKey(s_hotWnd, ZL_HOTKEY_ID2);
    DestroyWindow(s_hotWnd);
    s_hotWnd = NULL;
}

/* called from the present hook every frame: cheap, idempotent */
void zl_input_watchdog(void)
{
    /* the startup panel is opened from here too: a host that presents two
     * frames and then parks inside a loading screen never reaches the
     * swap-side check again, and "it did not open" is what that looks like
     * from the outside. */
    zl_autoopen_tick();

    if (!s_kbHook) zl_input_install_fallback_hook();
    if (!s_subclassed) {
        HWND fg = GetForegroundWindow();
        if (fg) {
            char cls[128] = {0};
            GetClassNameA(fg, cls, sizeof(cls) - 1);
            /* the emulator frame of every supported host */
            if (strstr(cls, "Qt") || strstr(cls, "BlueStacks") ||
                strstr(cls, "HD-Player") || strstr(cls, "MEmu") ||
                strstr(cls, "Nox") || strstr(cls, "LdVBox") ||
                strstr(cls, "SDL_app"))
                zl_input_install(fg);
        }
    }
}

#endif /* ZL_DEFAULT_MENUWINDOW */
