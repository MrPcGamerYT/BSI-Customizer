/* =====================================================================
 *  gl_pipeline.c  --  the post-process chain that runs inside
 *  HD-Player.exe's GL context, right after the emulator presents.
 *
 *  per frame (all sizes full-res unless noted):
 *    src  <- copy of the presented back buffer
 *    src  -> fxaa   -> fx        (fxaa > 0)
 *    fx/src -> bright -> A(half) -> gaussH -> B(half) -> gaussV -> A  (bloom)
 *    fx/src + prev -> flow (half res, 20-candidate SAD)               (mblur)
 *    composite(frame=fx|src, bloom=A, flow, prev) -> default fb
 *    prev <- fx|src        (exactly one frame of history, no feedback)
 *
 *  With master off or every weight at zero, nothing is drawn: the
 *  emulator frame is presented untouched (bit-exact identity).
 * ===================================================================== */
#include "common.h"
#include "gl_loader.h"
#include "zlag_shaders.h"

typedef struct GLProg {
    GLuint id;
    GLint  uTex, uTexel, uAmt, uDir, uThr;
} GLProg;

#define TEX_SRC   0
#define TEX_FX    1
#define TEX_BLA   2
#define TEX_BLB   3
#define TEX_FLOW  4
#define TEX_N     5

static int      s_ready  = 0;
static int      s_failed = 0;
static int      s_attempts = 0;
#define ZL_MAX_ATTEMPTS 12          /* a BlueStacks GL context can be created
                                       more than once per session; a failed
                                       compile must not be permanent */
static int      s_w = 0, s_h = 0;
static int      s_bw = 0, s_bh = 0;        /* half-res targets */
static GLuint   s_tex[TEX_N];
static GLuint   s_fbo[TEX_N];
static GLuint   s_prevTex;
static GLuint   s_quadBuf;

static GLProg   s_pFxaa, s_pBright, s_pGauss, s_pFlow, s_pComp, s_pCopy;

/* one frame counter, used to warm the history buffer */
static unsigned s_frameNo = 0;

#define ZL_MAX_UNITS 8

/* The bundled GL header is trimmed to what the pipeline itself uses.
 * These are the standard values for the extra state we now save and
 * restore; spelled out here rather than widening the shared header. */
#ifndef GL_ARRAY_BUFFER_BINDING
#define GL_ARRAY_BUFFER_BINDING          0x8894
#endif
#ifndef GL_ELEMENT_ARRAY_BUFFER_BINDING
#define GL_ELEMENT_ARRAY_BUFFER_BINDING  0x8895
#endif
#ifndef GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS
#define GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS 0x8B4D
#endif
#ifndef GL_BLEND_SRC_RGB
#define GL_BLEND_SRC_RGB                 0x80C9
#endif
#ifndef GL_BLEND_DST_RGB
#define GL_BLEND_DST_RGB                 0x80C8
#endif
#ifndef GL_BLEND_SRC_ALPHA
#define GL_BLEND_SRC_ALPHA               0x80CB
#endif
#ifndef GL_BLEND_DST_ALPHA
#define GL_BLEND_DST_ALPHA               0x80CA
#endif
#ifndef GL_BLEND_EQUATION_RGB
#define GL_BLEND_EQUATION_RGB            0x8009
#endif
#ifndef GL_BLEND_EQUATION_ALPHA
#define GL_BLEND_EQUATION_ALPHA          0x883D
#endif
#ifndef GL_DEPTH_FUNC
#define GL_DEPTH_FUNC                    0x0B74
#endif
#ifndef GL_COLOR_WRITEMASK
#define GL_COLOR_WRITEMASK               0x0C23
#endif
#ifndef GL_DEPTH_WRITEMASK
#define GL_DEPTH_WRITEMASK               0x0B72
#endif
#ifndef GL_COLOR_CLEAR_VALUE
#define GL_COLOR_CLEAR_VALUE             0x0C22
#endif
#ifndef GL_UNPACK_ROW_LENGTH
#define GL_UNPACK_ROW_LENGTH             0x0CF2
#endif
#ifndef GL_UNPACK_SKIP_ROWS
#define GL_UNPACK_SKIP_ROWS              0x0CF3
#endif
#ifndef GL_UNPACK_SKIP_PIXELS
#define GL_UNPACK_SKIP_PIXELS            0x0CF4
#endif
#ifndef GL_VERTEX_ATTRIB_ARRAY_ENABLED
#define GL_VERTEX_ATTRIB_ARRAY_ENABLED   0x8622
#endif
#ifndef GL_PACK_ALIGNMENT
#define GL_PACK_ALIGNMENT                0x0D05
#endif

/* ---------------------------------------------------------------
 *  Saved GL state.
 *
 *  This used to save little more than the viewport and a handful of
 *  enable bits, and every one of the things it did not save is a way
 *  to corrupt the emulator's next frame. The three that actually bite:
 *
 *    - GL_ARRAY_BUFFER. We bind our quad VBO and leave 0 behind. A host
 *      that streams vertices from a bound VBO then feeds the driver a
 *      null buffer -> garbage geometry or a drop to 0 fps.
 *    - vertex attribute arrays 0 and 1. We disable them unconditionally.
 *      A host that keeps them enabled (fixed-function-ish setups and
 *      older games do) draws with no attributes at all.
 *    - the blend / depth FUNCTION, not just the enable. A host that
 *      sets glBlendFunc(GL_ONE, GL_ONE) or glDepthFunc(GL_NEVER) and
 *      leaves it set gets it back, because we never touched it.
 *
 *  The rest: active texture unit *all four* bindings, the vertex array
 *  object, GL_SCISSOR_TEST's rect, the colour write mask, and the
 *  unpack state used by glDrawPixels. Save and restore are matched
 *  member for member -- if you add one to the save, add the restore.
 * --------------------------------------------------------------- */
typedef struct GLSaved {
    GLint viewport[4];
    GLint fbo, rbo, prog, activeTex;
    GLint tex2d[ZL_MAX_UNITS];
    GLint arrayBuf, elemBuf, vao;
    GLint blendSrcRGB, blendDstRGB, blendSrcA, blendDstA;
    GLint blendEqRGB, blendEqA;
    GLint depthFunc;
    GLint scissor[4];
    GLboolean colorMask[4];
    GLint packAlign, unpackAlign, unpackRowLen, unpackSkipRows, unpackSkipPix;
    GLboolean attrib0, attrib1;
    GLboolean depthMask;
    GLfloat clearColor[4];
    GLboolean blend, depth, cull, scissor_en, stencil;
    int valid;
} GLSaved;
static GLSaved s_save;

/* --------------------------------------------------------------- */
static GLuint compile(GLenum type, const char* src)
{
    GLuint sh = zgl.glCreateShader(type);
    if (!sh) return 0;
    zgl.glShaderSource(sh, 1, &src, NULL);
    zgl.glCompileShader(sh);
    GLint ok = 0;
    zgl.glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1600] = {0};
        GLsizei n = 0;
        zgl.glGetShaderInfoLog(sh, sizeof(log) - 1, &n, log);
        zl_log(LOG_ERR, "shader %s did not compile: %s",
               type == GL_VERTEX_SHADER ? "vertex" : "fragment", log);
        zgl.glDeleteShader(sh);
        return 0;
    }
    return sh;
}

static GLuint link_prog(const char* fs)
{
    GLuint vs = compile(GL_VERTEX_SHADER, ZL_VS);
    GLuint f  = compile(GL_FRAGMENT_SHADER, fs);
    if (!vs || !f) { if (vs) zgl.glDeleteShader(vs); if (f) zgl.glDeleteShader(f); return 0; }

    GLuint p = zgl.glCreateProgram();
    zgl.glAttachShader(p, vs);
    zgl.glAttachShader(p, f);
    zgl.glBindAttribLocation(p, 0, "aPos");
    zgl.glBindAttribLocation(p, 1, "aUV");
    zgl.glLinkProgram(p);
    GLint ok = 0;
    zgl.glGetProgramiv(p, GL_LINK_STATUS, &ok);
    zgl.glDeleteShader(vs);
    zgl.glDeleteShader(f);
    if (!ok) {
        char log[1600] = {0};
        GLsizei n = 0;
        zgl.glGetProgramInfoLog(p, sizeof(log) - 1, &n, log);
        zl_log(LOG_ERR, "program link failed: %s", log);
        zgl.glDeleteProgram(p);
        return 0;
    }
    return p;
}

static void prog_init(GLProg* gp)
{
    memset(gp, 0, sizeof(*gp));
    gp->uTex = gp->uTexel = gp->uAmt = gp->uDir = gp->uThr = -1;
}

static int prog_wrap(GLProg* gp, const char* fs)
{
    prog_init(gp);
    gp->id = link_prog(fs);
    if (!gp->id) return 0;
    gp->uTex   = zgl.glGetUniformLocation(gp->id, "t");
    gp->uTexel = zgl.glGetUniformLocation(gp->id, "texel");
    gp->uAmt   = zgl.glGetUniformLocation(gp->id, "amt");
    gp->uDir   = zgl.glGetUniformLocation(gp->id, "dir");
    gp->uThr   = zgl.glGetUniformLocation(gp->id, "thr");
    return 1;
}

/* --------------------------------------------------------------- */
/* GL_RGBA8 (0x8058) is a desktop-GL sized format; ES2 rejects it as an
 * internalformat, so only use it when the emulator is on a desktop GL
 * context. Detected from GL_VERSION, decided once. */
static int s_useSized = -1;

static int is_gles(void)
{
    const char* v = (const char*)zgl.glGetString(GL_VERSION);
    if (!v) return 0;
    /* ES contexts say "OpenGL ES", ANGLE says "OpenGL ES 3.0 (ANGLE ...)" */
    return (v[0] == 'O' && v[7] == 'E') ? 1 : 0;
}

static void make_tex(int i, int w, int h)
{
    zgl.glGenTextures(1, &s_tex[i]);
    zgl.glBindTexture(GL_TEXTURE_2D, s_tex[i]);
    if (s_useSized < 0) s_useSized = is_gles() ? 0 : 1;
    zgl.glTexImage2D(GL_TEXTURE_2D, 0, s_useSized ? GL_RGBA8 : GL_RGBA,
                     w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    zgl.glGenFramebuffers(1, &s_fbo[i]);
    zgl.glBindFramebuffer(GL_FRAMEBUFFER, s_fbo[i]);
    zgl.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, s_tex[i], 0);
    GLenum st = zgl.glCheckFramebufferStatus(GL_FRAMEBUFFER);
    if (st != GL_FRAMEBUFFER_COMPLETE)
        zl_log(LOG_WARN, "FBO %d incomplete (0x%X) -- effects may be skipped", i, st);
    zgl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

static void release_all(void)
{
    if (!zgl_have()) return;
    for (int i = 0; i < TEX_N; i++) {
        if (s_fbo[i]) { zgl.glDeleteFramebuffers(1, &s_fbo[i]); s_fbo[i] = 0; }
        if (s_tex[i]) { zgl.glDeleteTextures(1, &s_tex[i]);   s_tex[i] = 0; }
    }
    if (s_prevTex) { zgl.glDeleteTextures(1, &s_prevTex); s_prevTex = 0; }
    if (s_quadBuf) { zgl.glDeleteBuffers(1, &s_quadBuf);  s_quadBuf = 0; }
    s_ready = 0; s_w = s_h = s_bw = s_bh = 0;
}

static void alloc_targets(int w, int h)
{
    if (s_ready && s_w == w && s_h == h) return;

    int wasReady = s_ready;
    /* Park the bindings first. Releasing textures/FBOs that are still
     * bound is legal GL, but the *next* glBindTexture/glFramebuffer then
     * lands on a stale name and the composite can draw into itself. */
    zgl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
    zgl.glBindTexture(GL_TEXTURE_2D, 0);
    release_all();
    s_ready = 0;

    int bw = ZL_MAX(64, w / 2), bh = ZL_MAX(64, h / 2);
    s_w = w; s_h = h; s_bw = bw; s_bh = bh;

    make_tex(TEX_SRC,  w,  h);
    make_tex(TEX_FX,   w,  h);
    make_tex(TEX_BLA,  bw, bh);
    make_tex(TEX_BLB,  bw, bh);
    make_tex(TEX_FLOW, bw, bh);

    /* the fullscreen quad VBO: (re)created here because release_all()
     * sweeps it together with the render targets -- losing it silently
     * turns every pass into a no-op (no vertex data -> no fragments) */
    if (!s_quadBuf) {
        static const float quad[16] = {
            -1.f, -1.f, 0.f, 0.f,
             1.f, -1.f, 1.f, 0.f,
            -1.f,  1.f, 0.f, 1.f,
             1.f,  1.f, 1.f, 1.f,
        };
        zgl.glGenBuffers(1, &s_quadBuf);
        zgl.glBindBuffer(GL_ARRAY_BUFFER, s_quadBuf);
        zgl.glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
        zgl.glBindBuffer(GL_ARRAY_BUFFER, 0);
    }

    zgl.glGenTextures(1, &s_prevTex);
    zgl.glBindTexture(GL_TEXTURE_2D, s_prevTex);
    zgl.glTexImage2D(GL_TEXTURE_2D, 0, s_useSized ? GL_RGBA8 : GL_RGBA,
                     w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    zgl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    /* clear every target: flow/prev must not start as garbage */
    for (int i = 0; i < TEX_N; i++) {
        zgl.glBindFramebuffer(GL_FRAMEBUFFER, s_fbo[i]);
        zgl.glViewport(0, 0, (i >= TEX_BLA) ? bw : w, (i >= TEX_BLA) ? bh : h);
        zgl.glClearColor(0.5f, 0.5f, 0.0f, 1.0f);
        zgl.glClear(GL_COLOR_BUFFER_BIT);
    }
    zgl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
    zgl.glBindTexture(GL_TEXTURE_2D, 0);

    zgl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
    zgl.glBindTexture(GL_TEXTURE_2D, 0);
    zgl.glUseProgram(0);
    s_frameNo = 0;
    s_ready = 1;
    s_failed = 0;
    s_attempts = 0;
    zl_log(wasReady ? LOG_INFO : LOG_OK,
           "render targets rebuilt: %dx%d (bloom/flow at %dx%d)", w, h, bw, bh);
}

/* --------------------------------------------------------------- */
void zl_gl_begin(void)
{
    if (!zgl_have()) return;

    /* --- everything we are about to change ---------------------- */
    zgl.glGetIntegerv(GL_VIEWPORT, s_save.viewport);
    zgl.glGetIntegerv(GL_FRAMEBUFFER_BINDING, &s_save.fbo);
    zgl.glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, &s_save.rbo);
    zgl.glGetIntegerv(GL_CURRENT_PROGRAM, &s_save.prog);
    zgl.glGetIntegerv(GL_ACTIVE_TEXTURE, &s_save.activeTex);
    zgl.glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &s_save.arrayBuf);
    zgl.glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &s_save.elemBuf);
    if (zgl.glBindVertexArray) {
        GLint vao = 0;
        zgl.glGetIntegerv(0x85B5 /* GL_VERTEX_ARRAY_BINDING */, &vao);
        s_save.vao = vao;
    } else {
        s_save.vao = 0;
    }

    /* per-unit texture bindings: we always work on unit 0, but restore
     * every unit we might have disturbed out of caution */
    {
        int units = 0;
        zgl.glGetIntegerv(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS, &units);
        if (units <= 0 || units > ZL_MAX_UNITS) units = ZL_MAX_UNITS;
        for (int i = 0; i < units; i++) {
            zgl.glActiveTexture(GL_TEXTURE0 + i);
            zgl.glGetIntegerv(GL_TEXTURE_BINDING_2D, &s_save.tex2d[i]);
        }
    }
    zgl.glActiveTexture(GL_TEXTURE0);

    /* the modes, not just the enables */
    zgl.glGetIntegerv(GL_BLEND_SRC_RGB,  &s_save.blendSrcRGB);
    zgl.glGetIntegerv(GL_BLEND_DST_RGB,  &s_save.blendDstRGB);
    zgl.glGetIntegerv(GL_BLEND_SRC_ALPHA, &s_save.blendSrcA);
    zgl.glGetIntegerv(GL_BLEND_DST_ALPHA, &s_save.blendDstA);
    zgl.glGetIntegerv(GL_BLEND_EQUATION_RGB, &s_save.blendEqRGB);
    zgl.glGetIntegerv(GL_BLEND_EQUATION_ALPHA, &s_save.blendEqA);
    zgl.glGetIntegerv(GL_DEPTH_FUNC, &s_save.depthFunc);
    zgl.glGetIntegerv(GL_SCISSOR_BOX, s_save.scissor);
    zgl.glGetBooleanv(GL_COLOR_WRITEMASK, s_save.colorMask);
    zgl.glGetBooleanv(GL_DEPTH_WRITEMASK, &s_save.depthMask);
    zgl.glGetFloatv(GL_COLOR_CLEAR_VALUE, s_save.clearColor);

    /* the pixel-store state glDrawPixels depends on */
    zgl.glGetIntegerv(GL_PACK_ALIGNMENT, &s_save.packAlign);
    zgl.glGetIntegerv(GL_UNPACK_ALIGNMENT, &s_save.unpackAlign);
    zgl.glGetIntegerv(GL_UNPACK_ROW_LENGTH, &s_save.unpackRowLen);
    zgl.glGetIntegerv(GL_UNPACK_SKIP_ROWS, &s_save.unpackSkipRows);
    zgl.glGetIntegerv(GL_UNPACK_SKIP_PIXELS, &s_save.unpackSkipPix);

    /* which attribute arrays the host had on. Query both: disabling an
     * array the host re-enables next frame is free, disabling one it
     * never touches again is a corrupted host. */
    {
        GLint en = 0;
        zgl.glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &en);
        s_save.attrib0 = (GLboolean)en;
        en = 0;
        zgl.glGetVertexAttribiv(1, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &en);
        s_save.attrib1 = (GLboolean)en;
    }

    s_save.blend    = zgl.glIsEnabled(GL_BLEND);
    s_save.depth    = zgl.glIsEnabled(GL_DEPTH_TEST);
    s_save.cull     = zgl.glIsEnabled(GL_CULL_FACE);
    s_save.scissor_en = zgl.glIsEnabled(GL_SCISSOR_TEST);
    s_save.stencil  = zgl.glIsEnabled(GL_STENCIL_TEST);
    s_save.valid = 1;
}

void zl_gl_end(void)
{
    if (!zgl_have() || !s_save.valid) return;

    /* --- put back, member for member ---------------------------- */
    zgl.glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)s_save.fbo);
    zgl.glViewport(s_save.viewport[0], s_save.viewport[1],
                   s_save.viewport[2], s_save.viewport[3]);
    zgl.glUseProgram((GLuint)s_save.prog);

    if (zgl.glBindVertexArray)
        zgl.glBindVertexArray((GLuint)s_save.vao);
    zgl.glBindBuffer(GL_ARRAY_BUFFER, (GLuint)s_save.arrayBuf);
    zgl.glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, (GLuint)s_save.elemBuf);

    {
        int units = 0;
        zgl.glGetIntegerv(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS, &units);
        if (units <= 0 || units > ZL_MAX_UNITS) units = ZL_MAX_UNITS;
        for (int i = 0; i < units; i++) {
            zgl.glActiveTexture(GL_TEXTURE0 + i);
            zgl.glBindTexture(GL_TEXTURE_2D, (GLuint)s_save.tex2d[i]);
        }
    }
    zgl.glActiveTexture((GLenum)(s_save.activeTex ? s_save.activeTex : GL_TEXTURE0));

    zgl.glBlendFuncSeparate((GLenum)s_save.blendSrcRGB, (GLenum)s_save.blendDstRGB,
                            (GLenum)s_save.blendSrcA,   (GLenum)s_save.blendDstA);
    zgl.glBlendEquationSeparate((GLenum)s_save.blendEqRGB, (GLenum)s_save.blendEqA);
    zgl.glDepthFunc((GLenum)s_save.depthFunc);
    zgl.glScissor(s_save.scissor[0], s_save.scissor[1],
                  s_save.scissor[2], s_save.scissor[3]);
    zgl.glColorMask(s_save.colorMask[0], s_save.colorMask[1],
                    s_save.colorMask[2], s_save.colorMask[3]);
    zgl.glDepthMask(s_save.depthMask);
    zgl.glClearColor(s_save.clearColor[0], s_save.clearColor[1],
                     s_save.clearColor[2], s_save.clearColor[3]);

    zgl.glPixelStorei(GL_PACK_ALIGNMENT,   s_save.packAlign);
    zgl.glPixelStorei(GL_UNPACK_ALIGNMENT, s_save.unpackAlign);
    zgl.glPixelStorei(GL_UNPACK_ROW_LENGTH, s_save.unpackRowLen);
    zgl.glPixelStorei(GL_UNPACK_SKIP_ROWS,  s_save.unpackSkipRows);
    zgl.glPixelStorei(GL_UNPACK_SKIP_PIXELS, s_save.unpackSkipPix);

    if (s_save.attrib0) zgl.glEnableVertexAttribArray(0);
    else                zgl.glDisableVertexAttribArray(0);
    if (s_save.attrib1) zgl.glEnableVertexAttribArray(1);
    else                zgl.glDisableVertexAttribArray(1);

    if (s_save.blend)   zgl.glEnable(GL_BLEND);      else zgl.glDisable(GL_BLEND);
    if (s_save.depth)   zgl.glEnable(GL_DEPTH_TEST); else zgl.glDisable(GL_DEPTH_TEST);
    if (s_save.cull)    zgl.glEnable(GL_CULL_FACE);  else zgl.glDisable(GL_CULL_FACE);
    if (s_save.scissor_en) zgl.glEnable(GL_SCISSOR_TEST); else zgl.glDisable(GL_SCISSOR_TEST);
    if (s_save.stencil) zgl.glEnable(GL_STENCIL_TEST); else zgl.glDisable(GL_STENCIL_TEST);

    s_save.valid = 0;
}

int zl_gl_init(void)
{
    if (s_ready) return 1;
    if (s_failed && s_attempts >= ZL_MAX_ATTEMPTS) return 0;
    s_attempts++;

    if (!zgl_load() || !zgl.ok3) {
        zl_log(LOG_ERR, "GL 2.0 + FBO support missing (lane=%d ok2=%d ok3=%d) -- overlay disabled",
               zgl_lane(), zgl.ok2, zgl.ok3);
        s_failed = 1;
        return 0;
    }
    if (!zgl.glGenFramebuffers || !zgl.glCheckFramebufferStatus) {
        s_failed = 1;
        return 0;
    }

    int ok = 0;
    ok += prog_wrap(&s_pComp,   ZL_FS_COMPOSITE);
    ok += prog_wrap(&s_pCopy,   ZL_FS_COPY);
    ok += prog_wrap(&s_pFxaa,   ZL_FS_FXAA);
    ok += prog_wrap(&s_pBright, ZL_FS_BRIGHT);
    ok += prog_wrap(&s_pGauss,  ZL_FS_GAUSS);
    ok += prog_wrap(&s_pFlow,   ZL_FS_FLOW);

    if (!s_pComp.id) {
        /* The composite is the one program we cannot fake with a simpler
         * one -- but the plain copy program still is a valid last resort:
         * presenting through it keeps the overlay alive (and the UI
         * visible) with no grading, instead of killing the whole thing. */
        if (s_pCopy.id) {
            zl_log(LOG_ERR, "composite failed to compile -- running in "
                            "pass-through mode (UI only, no grading)");
            s_failed = 1;                 /* still counted, retried later */
        } else {
            zl_log(LOG_ERR, "no usable shader program at all -- overlay disabled");
            s_failed = 1;
            return 0;
        }
    }

    GLint vp[4] = {0, 0, 1280, 720};
    zgl.glGetIntegerv(GL_VIEWPORT, vp);
    if (vp[2] > 32 && vp[3] > 32) alloc_targets(vp[2], vp[3]);

    zl_log(LOG_OK, "GL post-process chain online: %d/6 programs", ok);
    return 1;
}

int zl_gl_is_ready(void) { return s_ready; }
void zl_gl_shutdown(void) { release_all(); }

/* --------------------------------------------------------------- */
static void bind_quad(void)
{
    zgl.glBindBuffer(GL_ARRAY_BUFFER, s_quadBuf);
    zgl.glEnableVertexAttribArray(0);
    zgl.glEnableVertexAttribArray(1);
    zgl.glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 16, (void*)0);
    zgl.glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 16, (void*)8);
}

static void draw_quad(void) { zgl.glDrawArrays(GL_TRIANGLE_STRIP, 0, 4); }

static void unbind_quad(void)
{
    zgl.glDisableVertexAttribArray(0);
    zgl.glDisableVertexAttribArray(1);
    zgl.glBindBuffer(GL_ARRAY_BUFFER, 0);
}

/* pass: srcTex (sw x sh) -> dst fbo (dw x dh) */
static void pass(GLProg* p, int dstFbo, int dw, int dh, GLuint srcTex,
                 int sw, int sh, float amt, float dirX, float dirY, float thr)
{
    zgl.glBindFramebuffer(GL_FRAMEBUFFER, s_fbo[dstFbo]);
    zgl.glViewport(0, 0, dw, dh);
    zgl.glUseProgram(p->id);
    zgl.glActiveTexture(GL_TEXTURE0);
    zgl.glBindTexture(GL_TEXTURE_2D, srcTex);
    if (p->uTex   >= 0) zgl.glUniform1i(p->uTex, 0);
    if (p->uTexel >= 0) zgl.glUniform2f(p->uTexel, 1.0f / sw, 1.0f / sh);
    if (p->uAmt   >= 0) zgl.glUniform1f(p->uAmt, amt);
    if (p->uDir   >= 0) zgl.glUniform2f(p->uDir, dirX, dirY);
    if (p->uThr   >= 0) zgl.glUniform1f(p->uThr, thr);
    bind_quad();
    draw_quad();
    unbind_quad();
}

/* --------------------------------------------------------------- */
/* Every parameter at or near neutral means the pass would copy the frame
 * onto a texture and draw it back unchanged: a full-screen copy plus a
 * full-screen quad, per frame, for nothing. */
int zl_effects_active(void)
{
#define NZ(x) (((x) > 0.0005f) || ((x) < -0.0005f))
    return NZ(g_cfg.sat) || NZ(g_cfg.con) || NZ(g_cfg.shp) || NZ(g_cfg.warm) ||
           NZ(g_cfg.blm) || NZ(g_cfg.lift) || NZ(g_cfg.vig) || NZ(g_cfg.hdr) ||
           NZ(g_cfg.amb) || NZ(g_cfg.mblur) || NZ(g_cfg.sres) || NZ(g_cfg.rcas) ||
           NZ(g_cfg.fxaa);
#undef NZ
}

int zl_gl_render_frame(int fbw, int fbh)
{
    if (!s_ready || !g_cfg.masterOn) return 0;
    if (!zl_effects_active()) return 0;        /* nothing to grade */
    if (fbw < 64 || fbh < 64) return 0;
    int rebuilt = 0;
    if (fbw != s_w || fbh != s_h) { alloc_targets(fbw, fbh); rebuilt = 1; }

    const float tx = 1.0f / (float)s_w;
    const float ty = 1.0f / (float)s_h;

    /* first frame of a fresh target set: let the emulator present once
     * untouched while we capture the frame into TEX_SRC (a composite
     * drawn from a just-rebuilt, never-rendered FBO shows garbage). */
    if (rebuilt || s_frameNo == 0) {
        zgl.glActiveTexture(GL_TEXTURE0);
        zgl.glBindTexture(GL_TEXTURE_2D, s_tex[TEX_SRC]);
        zgl.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, s_w, s_h);
        zgl.glBindTexture(GL_TEXTURE_2D, s_prevTex);
        zgl.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, s_w, s_h);
        s_frameNo++;
        return 0;
    }

    /* ---- 1. capture the presented frame (default fb -> TEX_SRC) ---- */
    zgl.glActiveTexture(GL_TEXTURE0);
    zgl.glBindTexture(GL_TEXTURE_2D, s_tex[TEX_SRC]);
    zgl.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, s_w, s_h);

    int cur = TEX_SRC;

    /* ---- 2. FXAA / edge sharpen ---------------------------------- */
    if (g_cfg.fxaa > 0.004f && s_pFxaa.id) {
        pass(&s_pFxaa, TEX_FX, s_w, s_h, s_tex[cur], s_w, s_h,
             g_cfg.fxaa, 0, 0, 0);
        cur = TEX_FX;
    }

    /* ---- 3. bloom ------------------------------------------------ */
    int bloomOk = 0;
    if (g_cfg.blm > 0.001f && s_pBright.id && s_pGauss.id) {
        pass(&s_pBright, TEX_BLA, s_bw, s_bh, s_tex[cur], s_w, s_h, 0, 0, 0, 0.34f);
        pass(&s_pGauss,  TEX_BLB, s_bw, s_bh, s_tex[TEX_BLA], s_bw, s_bh,
             0, 1.35f, 0.0f, 0);
        pass(&s_pGauss,  TEX_BLA, s_bw, s_bh, s_tex[TEX_BLB], s_bw, s_bh,
             0, 0.0f, 1.35f, 0);
        bloomOk = 1;
    }

    /* ---- 4. optical flow (half res) ------------------------------ */
    if (g_cfg.mblur > 0.001f && g_cfg.flow > 0.001f && s_pFlow.id && s_frameNo > 0) {
        zgl.glBindFramebuffer(GL_FRAMEBUFFER, s_fbo[TEX_FLOW]);
        zgl.glViewport(0, 0, s_bw, s_bh);
        zgl.glUseProgram(s_pFlow.id);
        GLint uc = zgl.glGetUniformLocation(s_pFlow.id, "cur");
        GLint up = zgl.glGetUniformLocation(s_pFlow.id, "prev");
        GLint ut = zgl.glGetUniformLocation(s_pFlow.id, "texel");
        if (uc >= 0) zgl.glUniform1i(uc, 0);
        if (up >= 0) zgl.glUniform1i(up, 1);
        if (ut >= 0) zgl.glUniform2f(ut, 2.0f * tx, 2.0f * ty);
        zgl.glActiveTexture(GL_TEXTURE0);
        zgl.glBindTexture(GL_TEXTURE_2D, s_tex[cur]);
        zgl.glActiveTexture(GL_TEXTURE1);
        zgl.glBindTexture(GL_TEXTURE_2D, s_prevTex);
        bind_quad();
        draw_quad();
        unbind_quad();
        zgl.glActiveTexture(GL_TEXTURE0);
    }

    /* ---- 5. composite straight into the back buffer -------------- */
    {
        zgl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
        zgl.glViewport(0, 0, s_w, s_h);


        zgl.glUseProgram(s_pComp.id);

        GLint uFrame = zgl.glGetUniformLocation(s_pComp.id, "frame");
        GLint uBloom = zgl.glGetUniformLocation(s_pComp.id, "bloomT");
        GLint uFlow  = zgl.glGetUniformLocation(s_pComp.id, "flowT");
        GLint uPrev  = zgl.glGetUniformLocation(s_pComp.id, "prevF");
        GLint uTexel = zgl.glGetUniformLocation(s_pComp.id, "texel");
        GLint uHas   = zgl.glGetUniformLocation(s_pComp.id, "hasPrev");

        if (uFrame >= 0) zgl.glUniform1i(uFrame, 0);
        if (uBloom >= 0) zgl.glUniform1i(uBloom, 1);
        if (uFlow  >= 0) zgl.glUniform1i(uFlow,  2);
        if (uPrev  >= 0) zgl.glUniform1i(uPrev,  3);
        if (uTexel >= 0) zgl.glUniform2f(uTexel, tx, ty);
        if (uHas   >= 0) zgl.glUniform1f(uHas, (s_frameNo > 0 && s_prevTex) ? 1.0f : 0.0f);

#define U1(name, val) do { GLint L = zgl.glGetUniformLocation(s_pComp.id, name); \
                           if (L >= 0) zgl.glUniform1f(L, (val)); } while (0)
        U1("sat",   g_cfg.sat);
        U1("con",   g_cfg.con);
        U1("shp",   g_cfg.shp);
        U1("sres",  g_cfg.sres);
        U1("rcas",  g_cfg.rcas);
        U1("warm",  g_cfg.warm);
        U1("blm",   bloomOk ? g_cfg.blm : 0.0f);
        U1("lift",  g_cfg.lift);
        U1("vig",   g_cfg.vig);
        U1("hdr",   g_cfg.hdr);
        U1("amb",   g_cfg.amb);
        U1("mblur", g_cfg.mblur);
        U1("flowAmt", g_cfg.flow);
#undef U1

        zgl.glActiveTexture(GL_TEXTURE0);
        zgl.glBindTexture(GL_TEXTURE_2D, s_tex[cur]);
        zgl.glActiveTexture(GL_TEXTURE1);
        zgl.glBindTexture(GL_TEXTURE_2D, s_tex[TEX_BLA]);
        zgl.glActiveTexture(GL_TEXTURE2);
        zgl.glBindTexture(GL_TEXTURE_2D, s_tex[TEX_FLOW]);
        zgl.glActiveTexture(GL_TEXTURE3);
        zgl.glBindTexture(GL_TEXTURE_2D, s_prevTex);

        bind_quad();
        draw_quad();
        unbind_quad();
        zgl.glUseProgram(0);
        zgl.glActiveTexture(GL_TEXTURE0);

        /* ---- 6. roll history: prev <- this frame (never the result) */
        zgl.glBindFramebuffer(GL_READ_FRAMEBUFFER, s_fbo[cur]);
        zgl.glBindTexture(GL_TEXTURE_2D, s_prevTex);
        zgl.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, s_w, s_h);
        zgl.glBindFramebuffer(GL_READ_FRAMEBUFFER, 0);
        zgl.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
        zgl.glBindTexture(GL_TEXTURE_2D, 0);
    }

    s_frameNo++;
    return 1;
}
