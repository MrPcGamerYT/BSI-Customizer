/* Optional ADB debloater. Separate manual disable and confirmed user-0
 * uninstall actions target only a verified BlueStacks instance. Image files
 * are never modified; install-existing recovery is best effort, not a backup.
 * The staged helper is byte verified and saved values are never executed. */
#include "common.h"
#include "safe_adb.h"
#include "debloat_sh.h"
#include "requested_apps.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DB_MAX_APPS 1024
#define DB_NAME_LEN 121
#define DB_BATCH_LIMIT 10

typedef struct DbRow {
    char name[DB_NAME_LEN];
    LONG state;             /* 1 enabled, 2 disabled */
    LONG requested;         /* exact user list or verified requested folder */
    volatile LONG selected;
} DbRow;
static DbRow s_rows[DB_MAX_APPS];
static volatile LONG s_count = 0;
static int s_collectCount = 0, s_collectState = 0, s_collectOverflow = 0, s_collectBad = 0;
static int s_folderBits = 0, s_pathsChecked = 0, s_pathsSeen = 0;
static int s_requestedMatches = 0, s_exactFound = 0, s_missingCount = 0;
static const char* s_missing[DB_MAX_APPS];
static char s_scanSerial[64] = {0}, s_scanBoot[37] = {0};
volatile LONG g_dbPresetCommand = 0; /* 1 remove requested, 2 recover removed */

static const char* const s_folderLabels[] = {
    "BookmarkProvider", "Camera2", "Gallery2", "CalendarProvider",
    "DocumentsUI", "Contacts", "ContactsProvider", "FusedLocation"
};
static const char* const s_folderPaths[] = {
    "/system/app/BookmarkProvider", "/system/app/Camera2", "/system/app/Gallery2",
    "/system/priv-app/CalendarProvider", "/system/priv-app/DocumentsUI",
    "/system/priv-app/Contacts", "/system/priv-app/ContactsProvider",
    "/system/priv-app/FusedLocation"
};
static int exact_requested(const char* name)
{
    for (int i = 0; ZL_REQUESTED_APPS[i]; ++i)
        if (strcmp(name, ZL_REQUESTED_APPS[i]) == 0) return 1;
    return 0;
}
static int requested_folder(const char* path, size_t len)
{
    for (int i = 0; i < 8; ++i) {
        size_t n = strlen(s_folderPaths[i]);
        if (len >= n && memcmp(path, s_folderPaths[i], n) == 0 &&
            ((len > n && path[n] == '/') ||
             (len == n + 4 && memcmp(path + n, ".apk", 4) == 0))) return i;
    }
    return -1;
}

static int valid_package(const char* p)
{
    if (!p || !*p || *p == '.' || strlen(p) >= DB_NAME_LEN || !strchr(p, '.') || strstr(p, "..")) return 0;
    for (; *p; ++p)
        if (!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
              (*p >= '0' && *p <= '9') || *p == '_' || *p == '.')) return 0;
    return 1;
}

static int protected_package(const char* p)
{
    static const char* exact[] = {
        "android", "com.android.systemui", "com.android.settings", "com.android.shell",
        "com.android.vending", "com.google.android.gms", "com.google.android.gsf",
        "com.bluestacks.home", "com.bluestacks.settings", "com.android.launcher",
        "com.android.launcher2", "com.android.launcher3", "com.google.android.packageinstaller",
        "com.android.packageinstaller", NULL
    };
    for (int i = 0; exact[i]; ++i) if (strcmp(p, exact[i]) == 0) return 1;
    return strncmp(p, "com.android.providers.", 22) == 0 ||
           strncmp(p, "com.android.inputmethod.", 24) == 0 ||
           strncmp(p, "com.google.android.inputmethod.", 31) == 0;
}

extern "C" int zl_db_app_count(void) { return (int)InterlockedCompareExchange(&s_count, 0, 0); }
extern "C" const char* zl_db_app_name(int i)
{
    return i >= 0 && i < zl_db_app_count() ? s_rows[i].name : "";
}
extern "C" int zl_db_app_state(int i)
{
    return i >= 0 && i < zl_db_app_count() ? (int)s_rows[i].state : 0;
}
extern "C" int zl_db_app_protected(int i)
{
    return i >= 0 && i < zl_db_app_count() ? protected_package(s_rows[i].name) : 1;
}
extern "C" int zl_db_app_selected(int i)
{
    return i >= 0 && i < zl_db_app_count() ?
        (int)InterlockedCompareExchange(&s_rows[i].selected, 0, 0) : 0;
}
extern "C" int zl_db_selected_count(void)
{
    int n = 0, count = zl_db_app_count();
    for (int i = 0; i < count; ++i) n += zl_db_app_selected(i) != 0;
    return n;
}
extern "C" int zl_db_select_app(int i, int on)
{
    if (i < 0 || i >= zl_db_app_count() || s_rows[i].state != 1 || protected_package(s_rows[i].name)) return 0;
    if (on && !zl_db_app_selected(i) && zl_db_selected_count() >= DB_BATCH_LIMIT) return 0;
    InterlockedExchange(&s_rows[i].selected, on ? 1 : 0);
    return 1;
}
extern "C" void zl_db_clear_selection(void)
{
    int count = zl_db_app_count();
    for (int i = 0; i < count; ++i) InterlockedExchange(&s_rows[i].selected, 0);
}
extern "C" void zl_db_forget_scan(void)
{
    InterlockedExchange(&g_dbChecked, 0);
    InterlockedExchange(&g_dbPresent, 0);
    InterlockedExchange(&s_count, 0);
    s_folderBits = 0; s_pathsChecked = 0;
    s_requestedMatches = s_exactFound = s_missingCount = 0;
    s_scanSerial[0] = s_scanBoot[0] = 0;
}

extern "C" int zl_db_app_requested(int i)
{
    return i >= 0 && i < zl_db_app_count() ? (int)s_rows[i].requested : 0;
}
extern "C" int zl_db_requested_count(void) { return s_requestedMatches; }
extern "C" int zl_db_requested_total(void)
{
    int n = 0; while (ZL_REQUESTED_APPS[n]) ++n; return n;
}
extern "C" int zl_db_requested_exact_found(void) { return s_exactFound; }
extern "C" const char* zl_db_requested_missing(int index)
{
    return index >= 0 && index < s_missingCount ? s_missing[index] : "";
}
extern "C" int zl_db_folders_checked(void) { return s_pathsChecked; }
extern "C" int zl_db_folder_found(int i) { return i >= 0 && i < 8 && (s_folderBits & (1 << i)); }
extern "C" const char* zl_db_folder_name(int i) { return i >= 0 && i < 8 ? s_folderLabels[i] : ""; }
extern "C" int zl_db_scan_bound(void) { return s_scanSerial[0] && s_scanBoot[0]; }

static void collect_package(const char* line, void*)
{
    if (strncmp(line, "package:", 8) != 0) {
        if (strstr(line, "Error:") || strstr(line, "error:") ||
            strstr(line, "Exception") || strstr(line, "Unknown option")) s_collectBad = 1;
        return;
    }
    const char* name = line + 8;
    if (!valid_package(name)) return;
    for (int i = 0; i < s_collectCount; ++i) {
        if (strcmp(s_rows[i].name, name) == 0) {
            /* A contradictory response is not selectable. */
            if (s_rows[i].state != s_collectState) s_rows[i].state = 2;
            return;
        }
    }
    if (s_collectCount >= DB_MAX_APPS) { s_collectOverflow = 1; return; }
    DbRow* r = &s_rows[s_collectCount++];
    lstrcpynA(r->name, name, sizeof(r->name));
    r->state = s_collectState;
    r->requested = exact_requested(name);
    r->selected = 0;
}

/* -f reports package-to-APK mapping. Ignore all unrequested folder names and
 * never display the paths; the guest helper verifies each match again. */
static void collect_package_path(const char* line, void*)
{
    if (strncmp(line, "package:", 8) != 0) {
        if (strstr(line, "Error:") || strstr(line, "error:") || strstr(line, "Exception") ||
            strstr(line, "Unknown option")) s_collectBad = 1;
        return;
    }
    const char* eq = strrchr(line + 8, '=');
    if (!eq) { s_collectBad = 1; return; }
    ++s_pathsSeen;
    if (!valid_package(eq + 1)) return; /* e.g. the framework package 'android' */
    int folder = requested_folder(line + 8, (size_t)(eq - (line + 8)));
    if (folder < 0) return;
    for (int i = 0; i < s_collectCount; ++i) {
        if (strcmp(s_rows[i].name, eq + 1) == 0) {
            s_rows[i].requested = 1;
            s_folderBits |= 1 << folder;
            return;
        }
    }
}

typedef struct DbBootId { char value[37]; int seen, invalid; } DbBootId;
static void boot_id_line(const char* line, void* opaque)
{
    DbBootId* id = (DbBootId*)opaque;
    if (id->seen++ || strlen(line) != 36) { id->invalid = 1; return; }
    for (int i = 0; i < 36; ++i) {
        char c = line[i];
        if (i == 8 || i == 13 || i == 18 || i == 23) {
            if (c != '-') { id->invalid = 1; return; }
        } else if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'))) {
            id->invalid = 1; return;
        }
    }
    lstrcpynA(id->value, line, sizeof(id->value));
}
static int read_boot_id(const char* adb, const char* serial, char out[37])
{
    DbBootId id = {{0}, 0, 0};
    int rc = zl_safe_adb_call(adb, serial, "shell cat /proc/sys/kernel/random/boot_id", boot_id_line, &id);
    if (rc != 0 || id.invalid || id.seen != 1) { out[0] = 0; return 0; }
    lstrcpynA(out, id.value, 37); return 1;
}
static int same_scanned_boot(const char* adb, const char* serial)
{
    char now[37];
    return s_scanSerial[0] && s_scanBoot[0] && strcmp(serial, s_scanSerial) == 0 &&
           read_boot_id(adb, serial, now) && strcmp(now, s_scanBoot) == 0;
}

static int same_boot_id(const char* adb, const char* serial, const char* expected);

static int compare_rows(const void* a, const void* b)
{
    return _stricmp(((const DbRow*)a)->name, ((const DbRow*)b)->name);
}

static int verify_target(char* adb, char* serial)
{
    if (!zl_safe_adb_target(adb, MAX_PATH, serial, 64)) {
        g_dbDevice[0] = 0;
        return 0;
    }
    lstrcpynA(g_dbDevice, serial, sizeof(g_dbDevice));
    return 1;
}

extern "C" void zl_db_scan_apps(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0};
    zl_db_forget_scan();
    apply_log("--- scanning installed apps for Android user 0 ---");
    if (!verify_target(adb, serial)) return;
    char bootBefore[37] = {0}, bootAfter[37] = {0};
    int hadBoot = read_boot_id(adb, serial, bootBefore);
    s_collectCount = s_collectOverflow = s_collectBad = 0;
    s_collectState = 1;
    int a = zl_safe_adb_call(adb, serial, "shell pm list packages --user 0 -e", collect_package, NULL);
    s_collectState = 2;
    int b = zl_safe_adb_call(adb, serial, "shell pm list packages --user 0 -d", collect_package, NULL);
    if (a != 0 || b != 0 || s_collectOverflow || s_collectBad) {
        apply_log("[!!] app scan incomplete; no packages can be selected yet");
        return;
    }
    s_folderBits = s_pathsChecked = s_pathsSeen = 0;
    s_collectBad = 0;
    int p = zl_safe_adb_call(adb, serial, "shell pm list packages -f --user 0", collect_package_path, NULL);
    if (p == 0 && !s_collectBad && (s_pathsSeen > 0 || s_collectCount == 0)) s_pathsChecked = 1;
    else {
        /* Discard any partially collected folder results; exact matches remain. */
        s_folderBits = 0;
        for (int i = 0; i < s_collectCount; ++i) s_rows[i].requested = exact_requested(s_rows[i].name);
        apply_log("[!!] folder matches could not be checked; only exact package IDs are available");
    }
    if (hadBoot && read_boot_id(adb, serial, bootAfter) && strcmp(bootBefore, bootAfter) == 0) {
        lstrcpynA(s_scanSerial, serial, sizeof(s_scanSerial));
        lstrcpynA(s_scanBoot, bootBefore, sizeof(s_scanBoot));
    } else {
        apply_log("[!!] instance changed or could not be bound to the scan; app changes are blocked");
    }
    qsort(s_rows, (size_t)s_collectCount, sizeof(s_rows[0]), compare_rows);
    s_requestedMatches = s_exactFound = s_missingCount = 0;
    for (int i = 0; i < s_collectCount; ++i) {
        if (s_rows[i].requested) ++s_requestedMatches;
        if (exact_requested(s_rows[i].name)) ++s_exactFound;
    }
    for (int i = 0; ZL_REQUESTED_APPS[i] && s_missingCount < DB_MAX_APPS; ++i) {
        int found = 0;
        for (int j = 0; j < s_collectCount; ++j)
            if (strcmp(s_rows[j].name, ZL_REQUESTED_APPS[i]) == 0) { found = 1; break; }
        if (!found) s_missing[s_missingCount++] = ZL_REQUESTED_APPS[i];
    }
    InterlockedExchange(&s_count, s_collectCount);
    InterlockedExchange(&g_dbPresent, s_collectCount);
    InterlockedExchange(&g_dbChecked, 1);
    apply_log("[ok] found %d apps; %d requested matches; nothing was changed", s_collectCount, zl_db_requested_count());
    apply_log("[i] %d of %d exact requested IDs are present", zl_db_requested_exact_found(), zl_db_requested_total());
    if (s_pathsChecked) for (int i = 0; i < 8; ++i)
        apply_log("[i] %s: %s", s_folderLabels[i], (s_folderBits & (1 << i)) ? "matched" : "unmatched");
}

/* Send one fresh helper under a unique name. Pull it back and compare every
 * byte before executing it: an earlier helper on the guest is never trusted. */
static int stage_helper(const char* adb, const char* serial, char* remote, size_t remoteSize)
{
    static volatile LONG nonce = 0;
    char dir[MAX_PATH] = {0}, host[MAX_PATH] = {0}, check[MAX_PATH] = {0}, args[1024];
    DWORD n = GetTempPathA(MAX_PATH, dir);
    if (!n || n >= MAX_PATH || !GetTempFileNameA(dir, "zdb", 0, host) ||
        !GetTempFileNameA(dir, "zdc", 0, check)) {
        if (host[0]) DeleteFileA(host);
        apply_log("[!!] could not prepare the app-management helper");
        return 0;
    }
    FILE* f = fopen(host, "wb");
    int good = 0;
    if (f) {
        size_t wrote = fwrite(ZL_DB_SCRIPT, 1, ZL_DB_SCRIPT_BYTES, f);
        int closed = fclose(f) == 0;
        good = wrote == ZL_DB_SCRIPT_BYTES && closed;
    }
    int k = _snprintf(remote, remoteSize, "/data/local/tmp/.zlag-db-%lu-%lu-%ld.sh",
                      (unsigned long)GetCurrentProcessId(), (unsigned long)GetTickCount(),
                      (long)InterlockedIncrement(&nonce));
    int reserved = 0;
    if (k < 0 || k >= (int)remoteSize) good = 0;
    if (good) {
        /* Never overwrite or remove a file that existed before this run. */
        k = _snprintf(args, sizeof(args), "shell \"[ ! -e %s ] && [ ! -L %s ]\"", remote, remote);
        good = k >= 0 && k < (int)sizeof(args) && zl_safe_adb_call(adb, serial, args, NULL, NULL) == 0;
        if (good) reserved = 1;
    }
    if (good) {
        k = _snprintf(args, sizeof(args), "push \"%s\" %s", host, remote);
        good = k >= 0 && k < (int)sizeof(args) && zl_safe_adb_call(adb, serial, args, NULL, NULL) == 0;
    }
    if (good) {
        k = _snprintf(args, sizeof(args), "shell \"[ -f %s ] && [ ! -L %s ]\"", remote, remote);
        good = k >= 0 && k < (int)sizeof(args) && zl_safe_adb_call(adb, serial, args, NULL, NULL) == 0;
    }
    if (good) {
        k = _snprintf(args, sizeof(args), "pull %s \"%s\"", remote, check);
        good = k >= 0 && k < (int)sizeof(args) && zl_safe_adb_call(adb, serial, args, NULL, NULL) == 0;
    }
    if (good) {
        f = fopen(check, "rb");
        if (!f) good = 0;
        else {
            char block[1024]; size_t offset = 0, got;
            while ((got = fread(block, 1, sizeof(block), f)) != 0) {
                if (offset + got > ZL_DB_SCRIPT_BYTES || memcmp(block, ZL_DB_SCRIPT + offset, got) != 0) {
                    good = 0; break;
                }
                offset += got;
            }
            if (ferror(f) || offset != ZL_DB_SCRIPT_BYTES) good = 0;
            fclose(f);
        }
    }
    DeleteFileA(host);
    DeleteFileA(check);
    if (!good) {
        if (reserved && remote[0]) {
            k = _snprintf(args, sizeof(args), "shell rm -f %s", remote);
            if (k >= 0 && k < (int)sizeof(args)) zl_safe_adb_call(adb, serial, args, NULL, NULL);
        }
        remote[0] = 0;
        apply_log("[!!] helper transfer could not be verified; no apps were changed");
        return 0;
    }
    return 1;
}

static void remove_helper(const char* adb, const char* serial, const char* remote)
{
    char args[512];
    if (!remote[0]) return;
    int k = _snprintf(args, sizeof(args), "shell rm -f %s", remote);
    if (k >= 0 && k < (int)sizeof(args)) zl_safe_adb_call(adb, serial, args, NULL, NULL);
}

typedef struct DbResult {
    int reported, error, count;
    const char* const* names;
    const char* mode;
    unsigned char seen[DB_BATCH_LIMIT];
} DbResult;
static void result_line_safe(const char* line, void* opaque)
{
    DbResult* r = (DbResult*)opaque;
    const char* name = NULL;
    const char* kind = NULL;
    const char* format = NULL;
    int ok = 0;
#define DB_RESULT(TAG, KIND, OK, FORMAT) \
    if (strncmp(line, TAG, sizeof(TAG) - 1) == 0) { \
        name = line + sizeof(TAG) - 1; kind = KIND; ok = OK; format = FORMAT; }
    DB_RESULT("ZL-OK-DISABLED ", "disable", 1, "[ok] disabled %s")
    else DB_RESULT("ZL-OK-RESTORED ", "restore", 1, "[ok] restored %s")
    else DB_RESULT("ZL-SKIP-DISABLE ", "disable", 0, "[i] skipped %s (protected, unavailable, disabled or already saved)")
    else DB_RESULT("ZL-FAIL-DISABLE ", "disable", 0, "[!!] could not disable %s")
    else DB_RESULT("ZL-UNCERTAIN-DISABLE ", "disable", 0, "[!!] outcome uncertain for %s; saved state kept")
    else DB_RESULT("ZL-FAIL-RESTORE ", "restore", 0, "[!!] could not restore %s; saved state kept")
    else DB_RESULT("ZL-UNCERTAIN-RESTORE ", "restore", 0, "[!!] restore uncertain for %s; saved state kept")
    else DB_RESULT("ZL-OK-REMOVED ", "uninstall", 1, "[ok] removed for user 0: %s")
    else DB_RESULT("ZL-SKIP-REMOVE ", "uninstall", 0, "[i] skipped %s (not requested, unavailable, unknown or already saved)")
    else DB_RESULT("ZL-FAIL-REMOVE ", "uninstall", 0, "[!!] could not remove %s")
    else DB_RESULT("ZL-UNCERTAIN-REMOVE ", "uninstall", 0, "[!!] removal uncertain for %s; saved record kept")
    else DB_RESULT("ZL-OK-REINSTALLED ", "reinstall", 1, "[ok] available again with saved state: %s")
    else DB_RESULT("ZL-FAIL-REINSTALL ", "reinstall", 0, "[!!] could not recover %s; instance backup may be needed")
    else DB_RESULT("ZL-UNCERTAIN-REINSTALL ", "reinstall", 0, "[!!] recovery uncertain for %s; saved record kept")
    else if (strncmp(line, "ZL-BUSY", 7) == 0 || strstr(line, "ZL-BACKUP-") ||
             strstr(line, "ZL-UNKNOWN-ACTION")) r->error = 1;
#undef DB_RESULT
    if (!name) return;
    if (!valid_package(name) || strcmp(kind, r->mode) != 0) { r->error = 1; return; }
    int i = 0;
    while (i < r->count && strcmp(r->names[i], name) != 0) ++i;
    if (i == r->count || r->seen[i]) { r->error = 1; return; }
    r->seen[i] = 1;
    ++r->reported;
    apply_log(format, name);
    InterlockedIncrement(&g_dbDone);
    if (ok) InterlockedIncrement(&g_dbOk); else InterlockedIncrement(&g_dbFail);
}

static int run_batch(const char* adb, const char* serial, const char* remote,
                     const char* mode, const char* const* names, int count)
{
    char args[4096];
    if (count <= 0 || count > DB_BATCH_LIMIT) return 0;
    int len = _snprintf(args, sizeof(args), "shell sh %s %s", remote, mode);
    if (len < 0 || len >= (int)sizeof(args)) return 0;
    for (int i = 0; i < count; ++i) {
        if (!valid_package(names[i])) return 0;
        int add = _snprintf(args + len, sizeof(args) - len, " %s", names[i]);
        if (add < 0 || add >= (int)(sizeof(args) - len)) return 0;
        len += add;
    }
    DbResult r = {}; r.names = names; r.count = count; r.mode = mode;
    int rc = zl_safe_adb_call(adb, serial, args, result_line_safe, &r);
    if (rc != 0 || r.error || r.reported != count) {
        for (int i = 0; i < count; ++i) if (!r.seen[i]) {
            apply_log("[!!] no verified result for %s; outcome unknown", names[i]);
            InterlockedIncrement(&g_dbDone); InterlockedIncrement(&g_dbFail);
        }
        apply_log("[!!] batch incomplete or timed out; remaining apps were not attempted");
        return 0;
    }
    return 1;
}

extern "C" void zl_db_disable_selected(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0}, remote[256] = {0};
    const char* names[DB_BATCH_LIMIT];
    int n = 0, count = zl_db_app_count();
    apply_log("--- disabling selected apps (no uninstall) ---");
    if (!g_dbChecked || !count || !verify_target(adb, serial)) return;
    if (!same_scanned_boot(adb, serial)) {
        apply_log("[!!] instance changed since scanning; rescan before disabling");
        zl_db_forget_scan(); return;
    }
    for (int i = 0; i < count && n < DB_BATCH_LIMIT; ++i)
        if (zl_db_app_selected(i) && s_rows[i].state == 1 && !protected_package(s_rows[i].name))
            names[n++] = s_rows[i].name;
    if (!n) { apply_log("[i] no eligible apps selected"); return; }
    InterlockedExchange(&g_dbDone, 0); InterlockedExchange(&g_dbTotal, n);
    InterlockedExchange(&g_dbOk, 0); InterlockedExchange(&g_dbFail, 0);
    if (!stage_helper(adb, serial, remote, sizeof(remote))) return;
    if (same_scanned_boot(adb, serial)) {
        run_batch(adb, serial, remote, "disable", names, n);
        if (same_scanned_boot(adb, serial)) remove_helper(adb, serial, remote);
    } else apply_log("[!!] instance changed before the batch; no disable command was sent");
    /* A fresh scan is required; stale rows cannot trigger another action. */
    zl_db_forget_scan();
    apply_log("[i] scan again to refresh the list; saved changes can be restored");
}

typedef struct SavedList {
    char names[DB_MAX_APPS][DB_NAME_LEN];
    int count, overflow, invalid, complete, none;
} SavedList;
static SavedList s_saved;
static void saved_line(const char* line, void* opaque)
{
    SavedList* s = (SavedList*)opaque;
    if (strncmp(line, "ZL-SAVED ", 9) == 0) {
        const char* name = line + 9;
        if (!valid_package(name)) { s->invalid = 1; return; }
        if (s->count >= DB_MAX_APPS) { s->overflow = 1; return; }
        lstrcpynA(s->names[s->count++], name, DB_NAME_LEN);
    } else if (strcmp(line, "ZL-LIST-DONE") == 0) s->complete = 1;
    else if (strcmp(line, "ZL-NO-BACKUP") == 0) s->none = 1;
    else if (strstr(line, "ZL-INVALID-BACKUP") || strstr(line, "ZL-BACKUP-")) s->invalid = 1;
}

extern "C" void zl_db_restore_changes(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0}, remote[256] = {0}, args[512], boot[37];
    apply_log("--- restoring only changes saved by this debloater ---");
    if (!verify_target(adb, serial)) return;
    if (!read_boot_id(adb, serial, boot)) {
        apply_log("[!!] unable to verify this running instance; no restore was attempted"); return;
    }
    if (!stage_helper(adb, serial, remote, sizeof(remote))) return;
    if (!same_boot_id(adb, serial, boot)) {
        apply_log("[!!] instance changed; no restore was attempted"); return;
    }
    memset(&s_saved, 0, sizeof(s_saved));
    int k = _snprintf(args, sizeof(args), "shell sh %s list", remote);
    int rc = (k < 0 || k >= (int)sizeof(args)) ? -4 :
             zl_safe_adb_call(adb, serial, args, saved_line, &s_saved);
    if (rc != 0 || s_saved.invalid || s_saved.overflow || (!s_saved.complete && !s_saved.none)) {
        apply_log("[!!] saved app states could not be safely read; nothing was restored");
        if (same_boot_id(adb, serial, boot)) remove_helper(adb, serial, remote);
        return;
    }
    if (s_saved.none || s_saved.count == 0) {
        apply_log("[i] no saved debloater changes found on this instance");
        if (same_boot_id(adb, serial, boot)) remove_helper(adb, serial, remote);
        return;
    }
    InterlockedExchange(&g_dbDone, 0); InterlockedExchange(&g_dbTotal, s_saved.count);
    InterlockedExchange(&g_dbOk, 0); InterlockedExchange(&g_dbFail, 0);
    for (int i = 0; i < s_saved.count; i += DB_BATCH_LIMIT) {
        if (!same_boot_id(adb, serial, boot)) {
            apply_log("[!!] instance changed or disconnected; remaining restore was not attempted"); break;
        }
        const char* names[DB_BATCH_LIMIT];
        int n = s_saved.count - i; if (n > DB_BATCH_LIMIT) n = DB_BATCH_LIMIT;
        for (int j = 0; j < n; ++j) names[j] = s_saved.names[i + j];
        if (!run_batch(adb, serial, remote, "restore", names, n)) break;
    }
    if (same_boot_id(adb, serial, boot)) remove_helper(adb, serial, remote);
    zl_db_forget_scan();
    apply_log("[i] unfinished or conflicting saved states remain available for retry");
}

/* This preset is intentionally separate from disabling. The scanned package
 * list is bound to one guest boot; each package is rechecked by the helper. */
extern "C" void zl_db_remove_requested(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0}, remote[256] = {0};
    const char* names[DB_MAX_APPS];
    int n = 0, count = zl_db_app_count();
    apply_log("--- confirmed removal of requested apps for Android user 0 ---");
    apply_log("[i] image files and download files are not deleted by this action");
    if (!g_dbChecked || !count || !verify_target(adb, serial)) return;
    if (!same_scanned_boot(adb, serial)) {
        apply_log("[!!] instance changed since scanning; rescan before removal");
        zl_db_forget_scan(); return;
    }
    for (int i = 0; i < count; ++i)
        if (s_rows[i].requested) names[n++] = s_rows[i].name;
    if (!n) { apply_log("[i] no requested apps matched this instance"); return; }
    InterlockedExchange(&g_dbDone, 0); InterlockedExchange(&g_dbTotal, n);
    InterlockedExchange(&g_dbOk, 0); InterlockedExchange(&g_dbFail, 0);
    if (!stage_helper(adb, serial, remote, sizeof(remote))) return;
    /* One package per bounded call minimizes timeout/partial-result ambiguity. */
    for (int i = 0; i < n; ++i) {
        if (!same_scanned_boot(adb, serial)) {
            apply_log("[!!] instance changed or disconnected; remaining apps were not attempted");
            break;
        }
        if (!run_batch(adb, serial, remote, "uninstall", &names[i], 1)) break;
    }
    if (same_scanned_boot(adb, serial)) remove_helper(adb, serial, remote);
    LONG unattempted = g_dbTotal - g_dbDone;
    if (unattempted < 0) unattempted = 0;
    apply_log("[i] removal summary: %ld confirmed, %ld skipped/failed/uncertain, %ld not attempted",
              (long)g_dbOk, (long)g_dbFail, (long)unattempted);
    apply_log("[i] system image and download files were not deleted; recovery is not guaranteed");
    zl_db_forget_scan();
}

static void removed_line(const char* line, void* opaque)
{
    SavedList* s = (SavedList*)opaque;
    if (strncmp(line, "ZL-REMOVED ", 11) == 0) {
        const char* name = line + 11;
        if (!valid_package(name)) { s->invalid = 1; return; }
        if (s->count >= DB_MAX_APPS) { s->overflow = 1; return; }
        for (int i = 0; i < s->count; ++i)
            if (strcmp(s->names[i], name) == 0) { s->invalid = 1; return; }
        lstrcpynA(s->names[s->count++], name, DB_NAME_LEN);
    } else if (strcmp(line, "ZL-REMOVE-LIST-DONE") == 0) s->complete = 1;
    else if (strcmp(line, "ZL-NO-BACKUP") == 0) s->none = 1;
    else if (strstr(line, "ZL-INVALID-BACKUP") || strstr(line, "ZL-BACKUP-")) s->invalid = 1;
}
static int same_boot_id(const char* adb, const char* serial, const char* expected)
{
    char now[37];
    return read_boot_id(adb, serial, now) && strcmp(now, expected) == 0;
}

/* Best effort only: Android may have discarded a downloaded APK, and this
 * helper never treats a journal as an app/data backup. */
extern "C" void zl_db_recover_removed(void)
{
    char adb[MAX_PATH] = {0}, serial[64] = {0}, remote[256] = {0}, args[512], boot[37];
    apply_log("--- attempting to recover this debloater's removed apps ---");
    if (!verify_target(adb, serial)) return;
    if (!read_boot_id(adb, serial, boot)) {
        apply_log("[!!] unable to verify this running instance; no recovery was attempted"); return;
    }
    if (!stage_helper(adb, serial, remote, sizeof(remote))) return;
    if (!same_boot_id(adb, serial, boot)) {
        apply_log("[!!] instance changed; no recovery was attempted"); return;
    }
    memset(&s_saved, 0, sizeof(s_saved));
    int k = _snprintf(args, sizeof(args), "shell sh %s list-removed", remote);
    int rc = (k < 0 || k >= (int)sizeof(args)) ? -4 :
             zl_safe_adb_call(adb, serial, args, removed_line, &s_saved);
    if (rc != 0 || s_saved.invalid || s_saved.overflow || (!s_saved.complete && !s_saved.none)) {
        apply_log("[!!] saved removal records could not be safely read; nothing was recovered");
        if (same_boot_id(adb, serial, boot)) remove_helper(adb, serial, remote);
        return;
    }
    if (s_saved.none || s_saved.count == 0) {
        apply_log("[i] no saved removal records found on this instance");
        if (same_boot_id(adb, serial, boot)) remove_helper(adb, serial, remote);
        return;
    }
    InterlockedExchange(&g_dbDone, 0); InterlockedExchange(&g_dbTotal, s_saved.count);
    InterlockedExchange(&g_dbOk, 0); InterlockedExchange(&g_dbFail, 0);
    for (int i = 0; i < s_saved.count; ++i) {
        if (!same_boot_id(adb, serial, boot)) {
            apply_log("[!!] instance changed or disconnected; remaining recovery was not attempted"); break;
        }
        const char* name = s_saved.names[i];
        if (!run_batch(adb, serial, remote, "reinstall", &name, 1)) break;
    }
    if (same_boot_id(adb, serial, boot)) remove_helper(adb, serial, remote);
    LONG unattempted = g_dbTotal - g_dbDone;
    if (unattempted < 0) unattempted = 0;
    apply_log("[i] recovery summary: %ld available, %ld failed/uncertain, %ld not attempted",
              (long)g_dbOk, (long)g_dbFail, (long)unattempted);
    apply_log("[i] remaining records are kept for retry; use your instance backup if needed");
    zl_db_forget_scan();
}
