#ifndef ZLAG_SAFE_ADB_H
#define ZLAG_SAFE_ADB_H
/* ADB operations must not select the first arbitrary USB/network device.
 * Use the user-selected local instance and require BlueStacks evidence.
 * If the evidence is missing, fail closed rather than guess. */
#include "common.h"
#include "adbexec.h"
#include <ctype.h>

void apply_log(const char* fmt, ...);

typedef struct ZLSafeIdentity { int recognized; } ZLSafeIdentity;

static void zl_safe_identity_line(const char* line, void* opaque)
{
    ZLSafeIdentity* id = (ZLSafeIdentity*)opaque;
    char lower[2048];
    size_t i = 0;
    for (; line[i] && i + 1 < sizeof(lower); ++i)
        lower[i] = (char)tolower((unsigned char)line[i]);
    lower[i] = 0;
    if (strstr(lower, "[bst.") || strstr(lower, "bluestacks") ||
        strstr(lower, "zl-bs-file")) id->recognized = 1;
}

static int zl_safe_adb_target(char* adb, DWORD adbSize, char* serial, DWORD serialSize)
{
    int port = g_cfg.adbPort;
    if (!zl_adb_find(adb, adbSize)) {
        apply_log("[!!] Android connection tool not found; nothing was changed");
        return 0;
    }
    if (port < 1 || port > 65535) {
        apply_log("[!!] select a valid instance port first; nothing was changed");
        return 0;
    }
    _snprintf(serial, serialSize, "127.0.0.1:%d", port);
    serial[serialSize - 1] = 0;
    char args[512];
    _snprintf(args, sizeof(args),
        "-s %s shell \"getprop; if [ -f /data/Bluestacks.prop ]; then echo ZL-BS-FILE; fi\"",
        serial);
    args[sizeof(args) - 1] = 0;
    ZLSafeIdentity id = { 0 };
    int rc = zl_adb_spawn(adb, args, zl_safe_identity_line, &id);
    if (rc != 0) {
        apply_log("[!!] selected instance is not reachable; connect its port in ADB first");
        return 0;
    }
    if (!id.recognized) {
        apply_log("[!!] BlueStacks identity could not be verified; nothing was changed");
        return 0;
    }
    return 1;
}

static int zl_safe_adb_call(const char* adb, const char* serial, const char* args,
                            void (*onLine)(const char*, void*), void* ctx)
{
    char scoped[7168];
    int n = _snprintf(scoped, sizeof(scoped), "-s %s %s", serial, args);
    if (n < 0 || n >= (int)sizeof(scoped)) return -4;
    scoped[sizeof(scoped) - 1] = 0;
    return zl_adb_spawn(adb, scoped, onLine, ctx);
}
#endif
