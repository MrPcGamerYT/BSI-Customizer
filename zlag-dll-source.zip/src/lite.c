/* =====================================================================
 *  lite.c -- texture-detail reduction ("potato graphics").
 *
 *  LOGIC ONLY: one sampler parameter, one hook, one cache.
 *
 *      GL_TEXTURE_LOD_BIAS (0x8501)
 *      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_LOD_BIAS, bias);
 *
 *  A positive bias makes the GPU sample a coarser mip level of an already
 *  mipmapped texture. Softer textures, less texture-cache pressure. Nothing
 *  is deleted, no draw call is skipped or reordered, no resolution and no
 *  filtering mode is touched.
 *
 *      remaining detail ~= 1 / 2^bias      bias = log2(100 / percent)
 *      100% -> 0.00 (stock)   50% -> 1.00   25% -> 2.00
 *       10% -> 3.32           6.25% -> 4.00
 *
 *  WHAT THIS FILE DELIBERATELY DOES NOT DO
 *    - no mipmap generation, no GL_TEXTURE_MIN_FILTER / MAG_FILTER change,
 *      no nearest sampling, no resolution change
 *    - no glGetError, no glGetTexLevelParameteriv, no synchronous queries
 *    - no draw-call hooks of any kind, no per-draw work
 *    - no per-frame table memset
 *    - no depth / blend / cull / scissor / stencil access
 *    - no FPS limiter
 *
 *  The earlier revision of this file built mip chains and switched the min
 *  filter so that textures uploaded without mipmaps would still change.
 *  That is where the stutter came from: a mip generate or a texture query
 *  inside the present call is milliseconds of driver work in the middle of
 *  a frame. It is gone. The cost of removing it is stated below, plainly.
 *
 *  KNOWN LIMITS -- not worked around, by design
 *    - affects ONLY textures that have a mip chain. Upload without mipmaps
 *      and the visible change is zero. That is the mechanism, not a bug.
 *    - cannot target individual objects: GL gives a texture name, never a
 *      semantic label ("character", "wall"), so per-object detail is not
 *      expressible here.
 *    - cannot remove geometry (grass, clouds, skybox). That needs draw-call
 *      culling, which this design refuses to do.
 *    - does nothing under Vulkan, DirectX or ANGLE: no GL functions there.
 *    - HUD/UI usually stays sharp on its own because UI atlases are
 *      typically uploaded without mipmaps. There is NO HUD detection here.
 *    - reduces GPU texture cost only. On a CPU-bound host, expect little or
 *      no FPS gain.
 * ===================================================================== */
#include <stdlib.h>
#include "common.h"
#include "gl_loader.h"

#include "MinHook.h"
#include <math.h>
#include <string.h>

#ifndef GL_TEXTURE_2D
#define GL_TEXTURE_2D 0x0DE1
#endif
#ifndef GL_TEXTURE_LOD_BIAS
#define GL_TEXTURE_LOD_BIAS 0x8501
#endif

#define BIAS_UNSET (-9999.0f)
#define LITE_N     65536
#define LITE_REFRESH_FRAMES 512

typedef void (APIENTRY* PFN_bindTexture)(GLenum, GLuint);
typedef void (APIENTRY* PFN_texparamf)(GLenum, GLenum, GLfloat);
typedef void (APIENTRY* PFN_teximage2d)(GLenum, GLint, GLint, GLsizei, GLsizei,
                                        GLint, GLenum, GLenum, const void*);

static PFN_bindTexture o_bindTexture = NULL;
static PFN_texparamf   p_texparamf   = NULL;
static PFN_teximage2d  o_texImage2D  = NULL;

/* ------------------------------------------------------------------ */
/*  size class per texture name                                       */
/*                                                                     */
/*  One byte, written at UPLOAD time (glTexImage2D), never queried.    */
/*  A 256 KB float table walked per bind was affordable; a synchronous */
/*  glGetTexLevelParameteriv inside the present call was not -- that is */
/*  what the previous revision did and it stuttered.                   */
/* ------------------------------------------------------------------ */
static unsigned char s_size[LITE_N];   /* 0 unknown, 1..5 = size class     */
#if defined(_MSC_VER)
#  define ZL_LITE_TLS __declspec(thread)
#else
#  define ZL_LITE_TLS __thread
#endif
/* Bindings and the private-pass guard are per GL thread, not per process. */
static ZL_LITE_TLS GLuint s_bound2D = 0;

/* ------------------------------------------------------------------ */
/*  filter class, so nothing ever goes blocky                         */
/*                                                                     */
/*  A positive LOD bias on a texture whose MIN_FILTER is NEAREST-based */
/*  (0x2700 / 0x2701) samples a coarser mip level with NEAREST within  */
/*  that level -- which is exactly visible blocky pixels, the one      */
/*  look this feature must never produce. GL's own default min filter  */
/*  is NEAREST_MIPMAP_NEAREST, so this is not a rare corner case.      */
/*                                                                     */
/*  So: the filter is recorded when the application sets it, and the   */
/*  bias is only applied to textures that filter LINEARLY within a     */
/*  level. Blocky is then impossible by construction -- bilinear within */
/*  a mip level blurs, it cannot checker.                              */
/*                                                                     */
/*  Recorded at glTexParameteri rather than queried: a parameter set   */
/*  happens once per texture, a query inside the bind path is a stall. */
/* ------------------------------------------------------------------ */
#define FLT_UNKNOWN 0
#define FLT_LINEAR  1                  /* safe: smooth within a level   */
#define FLT_NEAREST 2                  /* never bias: would checker     */

static unsigned char s_filter[LITE_N];
static unsigned char s_upf[LITE_N];      /* box-down factor used at upload */

typedef void (APIENTRY* PFN_texparami)(GLenum, GLenum, GLint);
static PFN_texparami o_texParameteri = NULL;

#define SZ_UNKNOWN 0
#define SZ_LT256   1
#define SZ_256     2
#define SZ_512     3
#define SZ_1024    4
#define SZ_2048    5

static unsigned char size_class(int w, int h)
{
    int m = w > h ? w : h;
    if (m >= 2048) return SZ_2048;
    if (m >= 1024) return SZ_1024;
    if (m >= 512)  return SZ_512;
    if (m >= 256)  return SZ_256;
    if (m > 0)     return SZ_LT256;
    return SZ_UNKNOWN;
}

/* "keep this size and above sharp" -> smallest class that qualifies */
static int protect_class(int threshold)
{
    if (threshold >= 2048) return SZ_2048;
    if (threshold >= 1024) return SZ_1024;
    if (threshold >= 512)  return SZ_512;
    if (threshold >= 256)  return SZ_256;
    return 99;                       /* protection off */
}

static volatile float s_bias     = 0.0f;   /* 0 = stock look                 */
static ZL_LITE_TLS int s_ownPass = 0;       /* inside our own GL work         */
static volatile LONG  s_ready    = 0;      /* hook installed + bias known    */
volatile LONG         zl_lite_biases = 0;  /* textures actually biased       */
volatile LONG         zl_lite_binds  = 0;  /* 2D binds seen since install    */
volatile LONG         zl_lite_skip   = 0;  /* left at stock: filter unknown  */
volatile LONG         zl_lite_scaled = 0;  /* textures re-uploaded smaller   */
volatile LONG         zl_lite_uploads = 0; /* glTexImage2D calls seen        */
int                   up_hooked = 0;       /* upload hook is on a real export */
static void (APIENTRY* p_getiv)(GLenum, GLint*) = NULL;
static const GLubyte* (APIENTRY* p_getstr)(GLenum) = NULL;
static void (APIENTRY* p_pixelstore)(GLenum, GLint) = NULL;
static void (APIENTRY* o_texSubImage2D)(GLenum, GLint, GLint, GLint, GLsizei, GLsizei,
                                         GLenum, GLenum, const void*) = NULL;

/* One float per texture name, 256 KB, static. Never malloc'd: this array
 * is read on every texture bind, and an allocation in that path is a hitch. */
static float s_cache[LITE_N];
static int   s_cacheReady = 0;

static void cache_init2(void)
{
    /* A sentinel, not 0.0f: zero is a real bias (stock), so a zero-filled
     * table would claim every texture is already correct and no bias would
     * ever be applied. */
    int i;
    for (i = 0; i < LITE_N; i++) s_cache[i] = BIAS_UNSET;
    s_cacheReady = 1;
}

static void cache_init(void)
{
    /* s_upf is deliberately NOT cleared here. This runs every 512 frames,
     * and a texture that was uploaded at a quarter size stays at a quarter
     * size -- forgetting that is how a later update lands at the original
     * size and the driver throws the whole upload away. */
    cache_init2();
}

/* ------------------------------------------------------------------ */
/*  upload hook: the only place texture size is ever learned          */
/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/*  upload downscale -- the mechanism that works on GLES               */
/*                                                                     */
/*  GL_TEXTURE_LOD_BIAS does not exist in GLES 2 or 3, so on ANGLE --  */
/*  which is what BlueStacks runs -- the bias lane is a no-op no matter */
/*  what value it is given. That is why the slider did nothing.        */
/*                                                                     */
/*  This does the thing the bias was standing in for: smaller textures.*/
/*  A box average over factor x factor blocks, taken from the pixels   */
/*  the app itself uploaded -- smooth by construction, no nearest       */
/*  subsampling anywhere, so no blocks and no sparkle. VRAM and fill    */
/*  bandwidth both actually drop, which is a real gain and not a        */
/*  cosmetic one.                                                      */
/*                                                                     */
/*  Deliberately narrow: level 0, 2D, 8-bit RGB/RGBA, no compressed or  */
/*  float formats, no GL_UNPACK_ROW_LENGTH tricks. Anything else is     */
/*  passed through untouched, and the count of what was and was not     */
/*  touched is printed in the panel.                                   */
/* ------------------------------------------------------------------ */
static int upload_factor(float bias)
{
    if (bias < 3.0f)  return 1;
    if (bias < 8.0f)  return 2;
    if (bias < 16.0f) return 4;
    return 8;
}

/* Inspect the actual upload state from the same GL implementation as the
 * image hook. Never treat a pixel-unpack-buffer offset as a CPU address. */
static int has_ext(const char* extensions, const char* name)
{
    const char* at;
    size_t n;
    if (!extensions || !name || !name[0]) return 0;
    n = strlen(name);
    at = extensions;
    while ((at = strstr(at, name)) != NULL) {
        if ((at == extensions || at[-1] == ' ') && (at[n] == 0 || at[n] == ' ')) return 1;
        at += n;
    }
    return 0;
}

static int safe_unpack(int w, int bpp, GLint* alignment, size_t* stride)
{
    const char* version;
    const char* exts = NULL;
    int es, major = 0, minor = 0, pbo = 0, sub = 0;
    GLint a = 0, v = 0;
    if (!p_getiv || !p_getstr || !p_pixelstore || w <= 0 || bpp <= 0) return 0;
    version = (const char*)p_getstr(0x1F02 /* GL_VERSION */);
    if (!version) return 0;
    es = strncmp(version, "OpenGL ES", 9) == 0;
    if (es) {
        const char* q = version + 9;
        while (*q && (*q < '0' || *q > '9')) ++q;
        if (sscanf(q, "%d.%d", &major, &minor) < 1 || major < 2) return 0;
        if (major >= 3) pbo = sub = 1;
        else {
            exts = (const char*)p_getstr(0x1F03 /* GL_EXTENSIONS */);
            if (!exts) return 0;
            pbo = has_ext(exts, "GL_NV_pixel_buffer_object") ||
                  has_ext(exts, "GL_EXT_pixel_buffer_object") ||
                  has_ext(exts, "GL_ARB_pixel_buffer_object");
            sub = has_ext(exts, "GL_EXT_unpack_subimage");
            if ((strstr(exts, "pixel_buffer_object") && !pbo) ||
                strstr(exts, "pixel_transfer_buffer")) return 0;
        }
    } else {
        if (sscanf(version, "%d.%d", &major, &minor) != 2 || major < 1) return 0;
        sub = 1; /* row length / skip are core in desktop GL */
        if (major > 2 || (major == 2 && minor >= 1)) pbo = 1;
        else {
            exts = (const char*)p_getstr(0x1F03);
            if (!exts) return 0;
            pbo = has_ext(exts, "GL_ARB_pixel_buffer_object") ||
                  has_ext(exts, "GL_EXT_pixel_buffer_object");
        }
        p_getiv(0x0CF0 /* GL_UNPACK_SWAP_BYTES */, &v);
        if (v != 0) return 0;
    }
    if (pbo) {
        p_getiv(0x88EF /* GL_PIXEL_UNPACK_BUFFER_BINDING */, &v);
        if (v != 0) return 0;
    }
    if (sub) {
        p_getiv(0x0CF2 /* GL_UNPACK_ROW_LENGTH */, &v); if (v != 0) return 0;
        p_getiv(0x0CF3 /* GL_UNPACK_SKIP_ROWS */, &v); if (v != 0) return 0;
        p_getiv(0x0CF4 /* GL_UNPACK_SKIP_PIXELS */, &v); if (v != 0) return 0;
    }
    p_getiv(0x0CF5 /* GL_UNPACK_ALIGNMENT */, &a);
    if (a != 1 && a != 2 && a != 4 && a != 8) return 0;
    *alignment = a;
    *stride = ((size_t)w * (size_t)bpp + (size_t)a - 1u) & ~((size_t)a - 1u);
    return 1;
}

static int valid_pixels(GLenum format, GLenum type)
{
    if (type == 0x1401) return format == 0x1908 || format == 0x1907;
    if (type == 0x8363) return format == 0x1907;
    if (type == 0x8033 || type == 0x8034) return format == 0x1908;
    return 0;
}

/* 16-bit packed formats are everywhere in mobile art, and a resizer that
 * only understands RGBA8 covers a fraction of a real game. These decode to
 * 8 bits per channel, average, then re-encode -- so the result is still a
 * smooth box average, not a bit shift. */
static void unpack16(unsigned int v, int type, unsigned char o[4])
{
    if (type == 0x8363) {          /* UNSIGNED_SHORT_5_6_5 */
        unsigned int r = (v >> 11) & 0x1F, g = (v >> 5) & 0x3F, b = v & 0x1F;
        o[0] = (unsigned char)((r << 3) | (r >> 2));
        o[1] = (unsigned char)((g << 2) | (g >> 4));
        o[2] = (unsigned char)((b << 3) | (b >> 2));
        o[3] = 255;
    } else if (type == 0x8033) {   /* UNSIGNED_SHORT_4_4_4_4 */
        o[0] = (unsigned char)(((v >> 12) & 0xF) * 17);
        o[1] = (unsigned char)(((v >> 8)  & 0xF) * 17);
        o[2] = (unsigned char)(((v >> 4)  & 0xF) * 17);
        o[3] = (unsigned char)(( v        & 0xF) * 17);
    } else {                       /* UNSIGNED_SHORT_5_5_5_1 */
        unsigned int r = (v >> 11) & 0x1F, g = (v >> 6) & 0x1F, b = (v >> 1) & 0x1F;
        o[0] = (unsigned char)((r << 3) | (r >> 2));
        o[1] = (unsigned char)((g << 3) | (g >> 2));
        o[2] = (unsigned char)((b << 3) | (b >> 2));
        o[3] = (v & 1) ? 255 : 0;
    }
}

static unsigned int pack16(const unsigned char i[4], int type)
{
    if (type == 0x8363) {
        return ((unsigned int)(i[0] >> 3) << 11) |
               ((unsigned int)(i[1] >> 2) << 5) |
                (unsigned int)(i[2] >> 3);
    }
    if (type == 0x8033) {
        return ((unsigned int)(i[0] >> 4) << 12) |
               ((unsigned int)(i[1] >> 4) << 8) |
               ((unsigned int)(i[2] >> 4) << 4) |
                (unsigned int)(i[3] >> 4);
    }
    return ((unsigned int)(i[0] >> 3) << 11) |
           ((unsigned int)(i[1] >> 3) << 6) |
           ((unsigned int)(i[2] >> 3) << 1) |
            (unsigned int)(i[3] ? 1 : 0);
}

static void* box_down16(const unsigned char* src, int w, int h,
                        int nw, int nh, int f, int type, size_t stride)
{
    unsigned char* dst;
    int x, y, sx, sy, c;

    if (!src || nw <= 0 || nh <= 0) return NULL;
    dst = (unsigned char*)malloc((size_t)nw * (size_t)nh * 2u);
    if (!dst) return NULL;

    for (y = 0; y < nh; y++) {
        for (x = 0; x < nw; x++) {
            unsigned int acc[4] = { 0, 0, 0, 0 };
            unsigned char px[4];
            unsigned int  out;
            unsigned char* d = dst + ((size_t)y * (size_t)nw + (size_t)x) * 2u;
            for (sy = 0; sy < f; sy++) {
                const unsigned char* row = src +
                    (size_t)(y * f + sy) * stride + (size_t)(x * f) * 2u;
                for (sx = 0; sx < f; sx++) {
                    unsigned int v = (unsigned int)row[sx * 2] |
                                     ((unsigned int)row[sx * 2 + 1] << 8);
                    unpack16(v, type, px);
                    for (c = 0; c < 4; c++) acc[c] += px[c];
                }
            }
            for (c = 0; c < 4; c++) px[c] = (unsigned char)(acc[c] / (unsigned int)(f * f));
            out = pack16(px, type);
            d[0] = (unsigned char)(out & 0xFF);
            d[1] = (unsigned char)((out >> 8) & 0xFF);
        }
    }
    return dst;
}

static void* box_down(const unsigned char* src, int w, int h,
                      int nw, int nh, int f, int bpp, size_t stride)
{
    unsigned char* dst;
    int x, y, sx, sy, c;

    if (!src || nw <= 0 || nh <= 0) return NULL;
    dst = (unsigned char*)malloc((size_t)nw * (size_t)nh * (size_t)bpp);
    if (!dst) return NULL;

    for (y = 0; y < nh; y++) {
        for (x = 0; x < nw; x++) {
            unsigned int acc[4] = { 0, 0, 0, 0 };
            unsigned char* d = dst + ((size_t)y * (size_t)nw + (size_t)x) * (size_t)bpp;
            for (sy = 0; sy < f; sy++) {
                const unsigned char* row = src +
                    (size_t)(y * f + sy) * stride + (size_t)(x * f) * (size_t)bpp;
                for (sx = 0; sx < f; sx++) {
                    const unsigned char* p = row + (size_t)sx * (size_t)bpp;
                    for (c = 0; c < bpp; c++) acc[c] += p[c];
                }
            }
            for (c = 0; c < bpp; c++)
                d[c] = (unsigned char)(acc[c] / (unsigned int)(f * f));
        }
    }
    return dst;
}

static void APIENTRY hk_texImage2D(GLenum target, GLint level, GLint internal,
                                   GLsizei w, GLsizei h, GLint border,
                                   GLenum format, GLenum type, const void* px)
{
    const void* use = px;
    GLsizei     uw = w, uh = h;
    InterlockedIncrement(&zl_lite_uploads);
    void*       tmp = NULL;
    int         f = 1, used_factor = 1;
    GLint       unpack_alignment = 0, bound = 0;
    size_t      source_stride = 0;

    if (!s_ownPass && target == GL_TEXTURE_2D && level == 0 && p_getiv)
        p_getiv(0x8069 /* GL_TEXTURE_BINDING_2D */, &bound);
    if (o_texImage2D) {
        if (!s_ownPass && s_ready && g_cfg.liteOn && s_bias >= 3.0f &&
            target == GL_TEXTURE_2D && level == 0 && border == 0 && px &&
            valid_pixels(format, type) && bound > 0 && bound < LITE_N &&
            o_texSubImage2D && w >= 16 && h >= 16 && w <= 8192 && h <= 8192) {
            f = upload_factor(s_bias);
            if (f > 1) {
                /* the character rule applies here exactly as it does to the
                 * bias: big atlases stay sharp unless superman is on */
                int prot = (!g_cfg.liteSuper && g_cfg.liteProtect > 0)
                             ? protect_class(g_cfg.liteProtect) : 99;
                if (size_class(w, h) >= prot) f = 1;
            }
        }
        if (f > 1) {
            int bpp = type == 0x1401 ? (format == 0x1908 ? 4 : 3) : 2;
            int nw = w / f, nh = h / f;
            if (nw >= 4 && nh >= 4 && w % f == 0 && h % f == 0 &&
                safe_unpack(w, bpp, &unpack_alignment, &source_stride)) {
                if (type == 0x1401)
                    tmp = box_down((const unsigned char*)px, w, h, nw, nh, f, bpp, source_stride);
                else
                    tmp = box_down16((const unsigned char*)px, w, h, nw, nh, f, (int)type, source_stride);
                if (tmp) {
                    use = tmp; uw = nw; uh = nh;
                    used_factor = f;
                    InterlockedIncrement(&zl_lite_scaled);
                    p_pixelstore(0x0CF5 /* GL_UNPACK_ALIGNMENT */, 1);
                }
            }
        }

        o_texImage2D(target, level, internal, uw, uh, border, format, type, use);

        if (tmp) {
            p_pixelstore(0x0CF5, unpack_alignment);
            free(tmp);
        }
    }
    if (s_ownPass || level != 0 || target != GL_TEXTURE_2D) return;
    if (bound <= 0 || bound >= LITE_N) return;
    s_size[bound] = size_class(uw, uh);
    s_upf[bound]  = (unsigned char)used_factor;
}


/* If a texture was uploaded at half or a quarter size, a later update with
 * the ORIGINAL width and height is a GL error and leaves the texture stale.
 * So the same block average is applied to the update, at the matching
 * offset. An update whose rectangle does not divide by the factor is
 * dropped rather than guessed at -- one stale frame instead of a corrupt
 * texture. */
static void APIENTRY hk_texSubImage2D(GLenum target, GLint level, GLint xoff,
                                      GLint yoff, GLsizei w, GLsizei h,
                                      GLenum format, GLenum type, const void* px)
{
    int f = 1;
    GLint bound = 0;

    if (!o_texSubImage2D) return;

    if (!s_ownPass && s_ready && target == GL_TEXTURE_2D && level == 0 && p_getiv) {
        p_getiv(0x8069 /* GL_TEXTURE_BINDING_2D */, &bound);
        if (bound > 0 && bound < LITE_N) f = s_upf[bound];
    }

    if (f > 1) {
        GLint alignment = 0;
        size_t stride = 0;
        int bpp = type == 0x1401 ? (format == 0x1908 ? 4 : 3) : 2;
        int nw = w / f, nh = h / f;
        if (!px || !valid_pixels(format, type) || xoff < 0 || yoff < 0 ||
            w < f || h < f || w > 8192 || h > 8192 ||
            (xoff % f) || (yoff % f) || (w % f) || (h % f) ||
            !safe_unpack(w, bpp, &alignment, &stride)) {
            InterlockedIncrement(&zl_lite_skip);
            return; /* Unsupported update: never dereference an offset. */
        }
        void* tmp = type == 0x1401
                      ? box_down((const unsigned char*)px, w, h, nw, nh, f, bpp, stride)
                      : box_down16((const unsigned char*)px, w, h, nw, nh, f, (int)type, stride);
        if (!tmp) { InterlockedIncrement(&zl_lite_skip); return; }
        p_pixelstore(0x0CF5, 1);
        o_texSubImage2D(target, level, xoff / f, yoff / f, nw, nh, format, type, tmp);
        p_pixelstore(0x0CF5, alignment);
        free(tmp);
        return;
    }

    o_texSubImage2D(target, level, xoff, yoff, w, h, format, type, px);
}

static void APIENTRY hk_texParameteri(GLenum target, GLenum pname, GLint param)
{
    if (o_texParameteri) o_texParameteri(target, pname, param);

    /* GL_TEXTURE_MIN_FILTER = 0x2801 */
    if (target != GL_TEXTURE_2D || pname != 0x2801) return;
    if (s_bound2D == 0 || s_bound2D >= LITE_N) return;
    s_filter[s_bound2D] = (param == 0x2702 || param == 0x2703)
                          ? FLT_LINEAR : FLT_NEAREST;
}

/* ------------------------------------------------------------------ */
/*  the hook                                                          */
/* ------------------------------------------------------------------ */
static void APIENTRY hk_bindTexture(GLenum target, GLuint tex)
{
    if (o_bindTexture) o_bindTexture(target, tex);
    if (target == GL_TEXTURE_2D) s_bound2D = tex;
    if (!s_ownPass && s_ready && target == GL_TEXTURE_2D)
        InterlockedIncrement(&zl_lite_binds);
    /* GL_TEXTURE_LOD_BIAS is not legal in GLES: upload scaling is the
     * only active mechanism. Do not pollute the host's GL error state. */
}

/* ------------------------------------------------------------------ */
/*  per-frame                                                         */
/* ------------------------------------------------------------------ */
void zl_lite_tick(void)
{
    /* Required by the design: recycled texture names must not inherit a
     * stale "already biased" verdict. This is a 256 KB walk once every 512
     * frames -- about 8 s at 60 fps -- and by itself it is nothing. What
     * made an earlier revision freeze was the work this refresh used to
     * trigger: a re-probe of every texture, in one frame, with synchronous
     * queries and mip builds behind it. With the refresh now causing only a
     * bias re-set, the cost is a handful of glTexParameterf calls. */
    static unsigned long long frame = 0;
    if ((++frame & (LITE_REFRESH_FRAMES - 1)) != 0) return;
    cache_init();
}

void zl_lite_own_pass(int on)
{
    s_ownPass = on ? 1 : 0;
}

/* ------------------------------------------------------------------ */
/*  settings                                                          */
/* ------------------------------------------------------------------ */
/* The slider runs 100% -> 0%. "0%" cannot be a literal zero detail -- a
 * bias of infinity is not a number the sampler accepts -- so 0 maps to a
 * finite ceiling. 16 is past the end of every practical mip chain (a 4096
 * px texture is 12 levels deep), so any bias at or above that samples the
 * 1x1 level for every texture that exists. That IS the floor of what a
 * sampler setting can do; it is not a promise of invisibility, because a
 * 1024 px surface still has one texel of colour left at the deepest level. */
#define LITE_BIAS_MAX 16.0f

float zl_lite_bias_for_percent(float pct)
{
    if (pct > 100.0f) pct = 100.0f;
    if (pct >= 100.0f) return 0.0f;
    if (pct <= 0.01f)  return LITE_BIAS_MAX;
    {
        float b = (float)(log(100.0 / (double)pct) / log(2.0));
        if (b > LITE_BIAS_MAX) b = LITE_BIAS_MAX;
        return b;
    }
}

/* The slider used to be labelled in "percent detail", which is the inverse
 * of the thing that actually changes: bias = log2(100/pct). That mapping is
 * violently non-linear -- the bottom third of the travel (100% -> 60% detail)
 * is bias 0.74, which is invisible. So most of the slider genuinely did
 * nothing, which is what "the slider does not work" means. The control is
 * now the bias itself, 0..16 in normal mode and 0..24 with superman, and
 * every step of travel is a visible step. */
float zl_lite_pct_for_bias(float bias)
{
    if (bias <= 0.0f) return 100.0f;
    {
        float pct = (float)(100.0 / pow(2.0, (double)bias));
        if (pct > 100.0f) pct = 100.0f;
        if (pct < 0.4f)   pct = 0.4f;     /* legacy field only */
        return pct;
    }
}

void zl_lite_apply(void)
{
    static float lastLogged = -1.0f;
    float b = g_cfg.liteOn ? g_cfg.liteBias : 0.0f;
    if (g_cfg.liteOn && b <= 0.0f)      /* configs from before the bias field */
        b = zl_lite_bias_for_percent(g_cfg.litePct);
    if (b < 0.0f)  b = 0.0f;
    if (b > 24.0f) b = 24.0f;
    s_bias = b;
    g_cfg.litePct = zl_lite_pct_for_bias(b);

    /* Live by construction: the factor is read from s_bias at the moment a
     * texture is created or bound, never cached at install time. So a drag
     * of the slider changes every texture the app uploads from that frame
     * on, with no restart and no reload of this DLL. Textures already
     * resident in the driver cannot be resized by anyone -- the pixels are
     * gone -- so they change when the app re-uploads them (a scene change,
     * a level load, or an instance restart).
     *
     * What is fully live on the GL lane: the bias cache is dropped here, so
     * every already-resident texture is re-biased on its next bind. */
    if (b != lastLogged) {
        lastLogged = b;
        zl_log(LOG_OK, "potato: bias %.2f live (factor %d on new uploads)",
               (double)b, (int)(b >= 16.0f ? 8 : b >= 8.0f ? 4 : b >= 3.0f ? 2 : 1));
    }
    cache_init();                 /* drop the bias cache: re-apply on bind */
    zl_lite_install_hooks();
    zl_d3d_install();             /* arm the D3D11 lane too, if it was not */
}

/* ------------------------------------------------------------------ */
/*  find the function the application ACTUALLY calls                  */
/*                                                                     */
/*  zgl_* resolves through opengl32 / wglGetProcAddress. BlueStacks    */
/*  runs ANGLE and calls libGLESv2.dll's exports directly, so a hook   */
/*  installed on opengl32's copy patches a function nothing calls --    */
/*  which is precisely why the textures never changed.                 */
/*                                                                     */
/*  This walks the loaded modules, asks each one for the export, and    */
/*  hooks the first distinct address it finds, preferring the GLES and  */
/*  opengl32 modules. Two distinct implementations of the same call at  */
/*  once would need two trampolines; that does not happen here, and if  */
/*  it did the second one is reported instead of silently half-hooked.  */
/* ------------------------------------------------------------------ */
#include <tlhelp32.h>

static void* g_hooked_addr[8];
static int   g_hooked_n = 0;
char g_hook_mod_name[64] = "";      /* where glTexImage2D came from */

static int already_hooked(void* a)
{
    int i;
    for (i = 0; i < g_hooked_n; i++) if (g_hooked_addr[i] == a) return 1;
    return 0;
}

/* 0 = hooked, 1 = not found, 2 = already */
static int hook_export(const char* name, void* detour, void** orig, int* howmany)
{
    HANDLE snap;
    MODULEENTRY32 me;
    void* cand[32];
    int   n = 0, i, distinct = 0;

    *howmany = 0;
    snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, GetCurrentProcessId());
    if (snap == INVALID_HANDLE_VALUE) return 1;

    me.dwSize = sizeof(me);
    if (Module32First(snap, &me)) {
        do {
            HMODULE h = (HMODULE)me.hModule;
            FARPROC  p = GetProcAddress(h, name);
            if (!p) continue;
            for (i = 0; i < n; i++) if (cand[i] == (void*)p) break;
            if (i == n && n < 32) cand[n++] = (void*)p;
        } while (Module32Next(snap, &me));
    }
    CloseHandle(snap);

    if (!n) return 1;

    /* prefer a module that looks like a GL implementation */
    {
        int best = 0;
        for (i = 0; i < n; i++) {
            MEMORY_BASIC_INFORMATION mbi;
            char path[MAX_PATH];
            if (VirtualQuery(cand[i], &mbi, sizeof(mbi))) {
                HMODULE h;
                if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                                       (LPCSTR)cand[i], &h) && h) {
                    GetModuleFileNameA(h, path, MAX_PATH);
                    if (strstr(path, "GLES") || strstr(path, "gles") ||
                        strstr(path, "opengl32") || strstr(path, "ANGLE")) {
                        best = i;
                        break;
                    }
                }
            }
        }
        if (best) { void* t = cand[0]; cand[0] = cand[best]; cand[best] = t; }
    }

    distinct = n;
    *howmany = distinct;

    if (already_hooked(cand[0])) return 2;
    if (MH_CreateHook(cand[0], detour, orig) != MH_OK) return 1;
    if (MH_EnableHook(cand[0]) != MH_OK)     return 1;
    if (g_hooked_n < 8) g_hooked_addr[g_hooked_n++] = cand[0];

    /* record the module so the panel can name it */
    {
        HMODULE h = NULL;
        char path[MAX_PATH];
        if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                               GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                               (LPCSTR)cand[0], &h) && h) {
            GetModuleFileNameA(h, path, MAX_PATH);
            if (strcmp(name, "glTexImage2D") == 0) {
                p_getiv = (void (APIENTRY*)(GLenum, GLint*))GetProcAddress(h, "glGetIntegerv");
                p_getstr = (const GLubyte* (APIENTRY*)(GLenum))GetProcAddress(h, "glGetString");
                p_pixelstore = (void (APIENTRY*)(GLenum, GLint))GetProcAddress(h, "glPixelStorei");
            }
            {
                char* sl = strrchr(path, '\\');
                lstrcpynA(g_hook_mod_name, sl ? sl + 1 : path, sizeof(g_hook_mod_name));
            }
        }
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/*  install                                                           */
/* ------------------------------------------------------------------ */
void zl_lite_install_hooks(void)
{
    static DWORD last = 0;
    static int   hooked = 0;
    DWORD now = GetTickCount();

    /* Nothing is hooked until the feature is switched on.
     *
     * Potato used to arm its texture hooks at start-up whether or not it was
     * enabled, which means every launch of the emulator went through module
     * enumeration and MinHook patching before the panel had ever appeared.
     * That is a lot of risk carried by a setting the user has not asked
     * for. Off means: no snapshot, no patching, no GL touched. */
    if (!g_cfg.liteOn) return;

    if (hooked) {
        if (now - last < 1000u) return;
        last = now;
        InterlockedExchange(&s_ready, 1);
        return;
    }
    if (last && now - last < (hooked ? 1000u : 5000u)) return;
    last = now;

    p_texparamf = NULL; /* no GLES-incompatible LOD parameter calls */

    {
        int many = 0, r;
        char why[4][24];
        int  nwhy = 0;

        r = hook_export("glBindTexture", (void*)&hk_bindTexture,
                        (void**)&o_bindTexture, &many);
        if (r == 1) {
            _snprintf(why[nwhy++], sizeof(why[0]), "glBindTexture missing");
        } else {
            hooked = 1;
            InterlockedExchange(&s_ready, 1);
            zl_log(LOG_OK, "lite graphics: glBindTexture hooked (%d export%s)",
                   many, many == 1 ? "" : "s");
        }

        r = hook_export("glTexImage2D", (void*)&hk_texImage2D,
                        (void**)&o_texImage2D, &many);
        if (r == 1) _snprintf(why[nwhy++], sizeof(why[0]), "glTexImage2D missing");
        else {
            up_hooked = 1;
            zl_log(LOG_OK, "lite graphics: glTexImage2D hooked (%d export%s) -- "
                           "potato resizes textures at upload", many,
                   many == 1 ? "" : "s");
        }

        r = hook_export("glTexSubImage2D", (void*)&hk_texSubImage2D,
                        (void**)&o_texSubImage2D, &many);
        if (r == 0) zl_log(LOG_INFO, "lite graphics: texture updates follow a resized upload");

        r = hook_export("glTexParameteri", (void*)&hk_texParameteri,
                        (void**)&o_texParameteri, &many);
        if (r == 0) zl_log(LOG_INFO, "lite graphics: min-filter tracked");

        if (nwhy) {
            char msg[160] = "";
            int k;
            for (k = 0; k < nwhy; k++) { strcat(msg, why[k]); if (k + 1 < nwhy) strcat(msg, ", "); }
            zl_log(LOG_ERR, "lite graphics: NOT hooked -- %s", msg);
        }
        zl_log(LOG_INFO, "lite graphics: level %.2f, supported uploads only", (double)s_bias);
    }
}

/* ------------------------------------------------------------------ */
/*  status -- what the panel reports about this lane                   */
/* ------------------------------------------------------------------ */
int   zl_lite_is_hooked(void) { return (int)(s_ready != 0); }
float zl_lite_bias_now(void)  { return (float)s_bias; }
