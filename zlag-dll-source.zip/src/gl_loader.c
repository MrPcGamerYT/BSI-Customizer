/* =====================================================================
 *  gl_loader.c  --  resolve every GL entry point we use, lazily.
 * ===================================================================== */
#include <string.h>
#include "common.h"
#include "gl_loader.h"

ZGL zgl;
static int s_loaded = 0;

static void* gpa(const char* n)
{
    FARPROC p = (FARPROC)wglGetProcAddress(n);
    if (p && p != (FARPROC)1 && p != (FARPROC)2 && p != (FARPROC)3 &&
        p != (FARPROC)-1)
        return (void*)p;
    return NULL;
}

/* opengl32.dll exports only the 1.1 set -- always get those from the module */
static void* gl1(const char* n)
{
    HMODULE h = GetModuleHandleA("opengl32.dll");
    if (!h) return NULL;
    return (void*)GetProcAddress(h, n);
}

/* ANGLE / native GLES: libEGL exports eglGetProcAddress, libGLESv2 has the
 * entry points as plain exports. Both are tried before giving up. */
static void* eglproc(const char* n)
{
    HMODULE he = GetModuleHandleA("libEGL.dll");
    if (he) {
        typedef void* (__stdcall* PFNEGLGETPROC)(const char*);
        PFNEGLGETPROC f = (PFNEGLGETPROC)GetProcAddress(he, "eglGetProcAddress");
        if (f) { void* p = f(n); if (p) return p; }
    }
    HMODULE hg = GetModuleHandleA("libGLESv2.dll");
    if (hg) {
        void* p = (void*)GetProcAddress(hg, n);
        if (p) return p;
    }
    return NULL;
}

/* Which window-system owns the CURRENT context? This decides the lookup
 * order, and getting it wrong is fatal: on an EGL/ANGLE host, symbols
 * resolved from opengl32.dll belong to a *different* context and every
 * call silently does nothing. */
static int s_lane = -1;      /* -1 unknown, 0 = WGL, 1 = EGL */

/* Which window system owns the CURRENT context?
 *
 * Order matters and is deliberately conservative: "is a context current at
 * all?" is answered first, by *asking each system*. Guessing from module
 * presence is wrong -- libEGL.dll is loaded in WGL-only processes too, and
 * deciding too early (before the render thread made anything current)
 * resolves every symbol to NULL and kills the whole overlay. */
static int current_lane(void)
{
    if (s_lane >= 0) return s_lane;

    HMODULE ho = GetModuleHandleA("opengl32.dll");
    HMODULE he = GetModuleHandleA("libEGL.dll");

    int wglCur = 0, eglCur = 0;
    if (ho) {
        typedef void* (__stdcall* PFN_WGLGETCTX)(void);
        PFN_WGLGETCTX f = (PFN_WGLGETCTX)GetProcAddress(ho, "wglGetCurrentContext");
        if (f && f() != NULL) wglCur = 1;
    }
    if (he) {
        typedef void* (__stdcall* PFN_GETCTX)(void);
        PFN_GETCTX f = (PFN_GETCTX)GetProcAddress(he, "eglGetCurrentContext");
        if (f && f() != NULL) eglCur = 1;
    }

    if (wglCur && !eglCur) { s_lane = 0; return s_lane; }
    if (eglCur && !wglCur) { s_lane = 1; return s_lane; }

    /* neither context is provably current: stay undecided and let the
     * symbol lookups try BOTH lanes. Guessing here is what broke the
     * overlay on hosts that call wglGetProcAddress before MakeCurrent. */
    if (wglCur && eglCur) { s_lane = 0; return s_lane; }
    return -1;
}

static void* sym(const char* n)
{
    void* p;
    int lane = current_lane();

    if (lane == 1) {                     /* EGL / ANGLE / native GLES */
        p = eglproc(n);
        if (p) return p;
        p = gpa(n);
        if (p) return p;
        return gl1(n);
    }
    if (lane == 0) {                     /* desktop WGL */
        p = gpa(n);
        if (p) return p;
        p = gl1(n);
        if (p) return p;
        return eglproc(n);
    }
    /* undecided: try every lane rather than giving up */
    p = gpa(n);       if (p) return p;
    p = eglproc(n);   if (p) return p;
    return gl1(n);
}

int zgl_load(void)
{
    if (s_loaded && zgl.ok2) return 1;
    memset(&zgl, 0, sizeof(zgl));

    /* ---- 1.1 ---- */
    zgl.glGetString      = (void*)sym("glGetString");
    zgl.glGetIntegerv    = (void*)sym("glGetIntegerv");
    zgl.glGetFloatv      = (void*)sym("glGetFloatv");
    zgl.glGetBooleanv    = (void*)sym("glGetBooleanv");
    zgl.glEnable         = (void*)sym("glEnable");
    zgl.glDisable        = (void*)sym("glDisable");
    zgl.glBlendFunc      = (void*)sym("glBlendFunc");
    zgl.glBlendFuncSeparate     = (void*)sym("glBlendFuncSeparate");
    zgl.glBlendEquationSeparate = (void*)sym("glBlendEquationSeparate");
    zgl.glDepthFunc      = (void*)sym("glDepthFunc");
    zgl.glDepthMask      = (void*)sym("glDepthMask");
    zgl.glColorMask      = (void*)sym("glColorMask");
    zgl.glGetVertexAttribiv = (void*)sym("glGetVertexAttribiv");
    zgl.glViewport       = (void*)sym("glViewport");
    zgl.glScissor        = (void*)sym("glScissor");
    zgl.glClear          = (void*)sym("glClear");
    zgl.glClearColor     = (void*)sym("glClearColor");
    zgl.glClearStencil   = (void*)sym("glClearStencil");
    zgl.glPixelStorei    = (void*)sym("glPixelStorei");
    zgl.glReadPixels     = (void*)sym("glReadPixels");
    zgl.glTexImage2D     = (void*)sym("glTexImage2D");
    zgl.glTexSubImage2D  = (void*)sym("glTexSubImage2D");
    zgl.glCopyTexSubImage2D = (void*)sym("glCopyTexSubImage2D");
    zgl.glTexParameteri  = (void*)sym("glTexParameteri");
    zgl.glTexParameterf  = (void*)sym("glTexParameterf");
    zgl.glBindTexture    = (void*)sym("glBindTexture");
    zgl.glGenTextures    = (void*)sym("glGenTextures");
    zgl.glDeleteTextures = (void*)sym("glDeleteTextures");
    zgl.glGenBuffers     = (void*)sym("glGenBuffers");
    zgl.glDeleteBuffers  = (void*)sym("glDeleteBuffers");
    zgl.glBindBuffer     = (void*)sym("glBindBuffer");
    zgl.glBufferData     = (void*)sym("glBufferData");
    zgl.glBufferSubData  = (void*)sym("glBufferSubData");
    zgl.glActiveTexture  = (void*)sym("glActiveTexture");
    zgl.glDrawArrays     = (void*)sym("glDrawArrays");
    zgl.glDrawElements   = (void*)sym("glDrawElements");
    zgl.glFlush          = (void*)sym("glFlush");
    zgl.glFinish         = (void*)sym("glFinish");
    zgl.glGetError       = (unsigned (APIENTRY*)(void))sym("glGetError");
    zgl.glIsEnabled      = (unsigned char (APIENTRY*)(GLenum))sym("glIsEnabled");

    /* ---- 2.0 core ---- */
    zgl.glCreateShader   = (void*)sym("glCreateShader");
    zgl.glShaderSource   = (void*)sym("glShaderSource");
    zgl.glCompileShader  = (void*)sym("glCompileShader");
    zgl.glGetShaderiv    = (void*)sym("glGetShaderiv");
    zgl.glGetShaderInfoLog = (void*)sym("glGetShaderInfoLog");
    zgl.glDeleteShader   = (void*)sym("glDeleteShader");
    zgl.glCreateProgram  = (void*)sym("glCreateProgram");
    zgl.glAttachShader   = (void*)sym("glAttachShader");
    zgl.glLinkProgram    = (void*)sym("glLinkProgram");
    zgl.glGetProgramiv   = (void*)sym("glGetProgramiv");
    zgl.glGetProgramInfoLog = (void*)sym("glGetProgramInfoLog");
    zgl.glUseProgram     = (void*)sym("glUseProgram");
    zgl.glDeleteProgram  = (void*)sym("glDeleteProgram");
    zgl.glGetUniformLocation = (void*)sym("glGetUniformLocation");
    zgl.glUniform1f      = (void*)sym("glUniform1f");
    zgl.glUniform2f      = (void*)sym("glUniform2f");
    zgl.glUniform3f      = (void*)sym("glUniform3f");
    zgl.glUniform4f      = (void*)sym("glUniform4f");
    zgl.glUniform1i      = (void*)sym("glUniform1i");
    zgl.glGetAttribLocation = (void*)sym("glGetAttribLocation");
    zgl.glBindAttribLocation = (void*)sym("glBindAttribLocation");
    zgl.glVertexAttribPointer = (void*)sym("glVertexAttribPointer");
    zgl.glEnableVertexAttribArray = (void*)sym("glEnableVertexAttribArray");
    zgl.glDisableVertexAttribArray = (void*)sym("glDisableVertexAttribArray");

    zgl.ok2 = zgl.glCreateShader && zgl.glCreateProgram && zgl.glUseProgram &&
              zgl.glGetUniformLocation && zgl.glActiveTexture &&
              zgl.glGenBuffers;

    /* ---- 3.0 FBO / VAO (with ARB fallbacks) ---- */
    zgl.glGenVertexArrays  = (void*)sym("glGenVertexArrays");
    zgl.glBindVertexArray  = (void*)sym("glBindVertexArray");
    zgl.glDeleteVertexArrays = (void*)sym("glDeleteVertexArrays");
    zgl.glGenFramebuffers  = (void*)sym("glGenFramebuffers");
    zgl.glBindFramebuffer  = (void*)sym("glBindFramebuffer");
    zgl.glFramebufferTexture2D = (void*)sym("glFramebufferTexture2D");
    zgl.glCheckFramebufferStatus = (void*)sym("glCheckFramebufferStatus");
    zgl.glDeleteFramebuffers = (void*)sym("glDeleteFramebuffers");
    zgl.glBlitFramebuffer  = (void*)sym("glBlitFramebuffer");
    zgl.ok3 = zgl.glGenFramebuffers && zgl.glBindFramebuffer &&
              zgl.glFramebufferTexture2D && zgl.glCheckFramebufferStatus;

    zgl.glDebugMessageCallbackARB = (void*)sym("glDebugMessageCallbackARB");
    zgl.ok31 = zgl.glDebugMessageCallbackARB != NULL;

    /* diagnostics: name exactly what is missing, so a failed load on a
     * real host is a one-line answer instead of a guessing game */
    {
        struct { const char* n; void* p; } need[] = {
            {"glCreateShader",(void*)zgl.glCreateShader},
            {"glCreateProgram",(void*)zgl.glCreateProgram},
            {"glUseProgram",(void*)zgl.glUseProgram},
            {"glGetUniformLocation",(void*)zgl.glGetUniformLocation},
            {"glActiveTexture",(void*)zgl.glActiveTexture},
            {"glGenBuffers",(void*)zgl.glGenBuffers},
            {"glGenFramebuffers",(void*)zgl.glGenFramebuffers},
            {"glBindFramebuffer",(void*)zgl.glBindFramebuffer},
            {"glFramebufferTexture2D",(void*)zgl.glFramebufferTexture2D},
            {"glCheckFramebufferStatus",(void*)zgl.glCheckFramebufferStatus},
        };
        char miss[256]; miss[0]=0;
        for (unsigned i=0;i<sizeof(need)/sizeof(need[0]);i++)
            if (!need[i].p) { strncat(miss, need[i].n, 40); strncat(miss, " ", 2); }
        if (miss[0])
            zl_log(LOG_ERR, "GL loader missing: %s(lane=%d)", miss, current_lane());
        else
            zl_log(LOG_INFO, "GL loader complete (lane=%d)", current_lane());
    }

    s_loaded = 1;
    return zgl.ok2;
}

int zgl_have(void) { return s_loaded && zgl.ok2; }

int zgl_lane(void) { return current_lane(); }

/* Same lookup the table above uses, exposed for modules that need a
 * function the paint pass never touches (glGenerateMipmap, error checks).
 * Resolving through this instead of GetProcAddress keeps every pointer on
 * one lane, which is the difference between biasing the emulator's
 * textures and biasing something in another context entirely. */
void* gl_resolve(const char* name) { return sym(name); }

void zgl_reload(void)
{
    s_loaded = 0;
    s_lane = -1;
    memset(&zgl, 0, sizeof(zgl));
    zgl_load();
}
