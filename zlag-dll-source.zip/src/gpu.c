/* =====================================================================
 *  gpu.c -- where the process is allowed to run, and how hard.
 *
 *  What this can honestly do
 *  -------------------------
 *  1. Windows GPU preference. HKCU\Software\Microsoft\DirectX\
 *     UserGpuPreferences is the documented per-application switch that
 *     tells DXGI (and therefore anything built on it, including BlueStacks'
 *     DirectX and ANGLE render paths) to use the DISCRETE adapter instead
 *     of the integrated one. On a hybrid laptop that is the difference
 *     between rendering on the iGPU and rendering on the real card. It is a
 *     per-user key, so no administrator rights are needed, and it takes
 *     effect the next time the application starts.
 *
 *  2. Power throttling / EcoQoS. Windows 11 puts background processes into
 *     an efficiency state that caps their scheduling class. A game loop in
 *     that state runs slowly no matter what else is tuned. Opting the
 *     process out is one call, immediate, and reversible.
 *
 *  What this CANNOT do, and the panel says so too
 *  ----------------------------------------------
 *  There is no switch that moves a CPU-bound workload onto the GPU. What
 *  makes an Android emulator CPU-heavy is the ARM-to-x86 translation of the
 *  guest's instructions -- that is the emulator's design, it happens on the
 *  CPU by definition, and no flag from inside the process changes it. The
 *  emulator's own engine choice (OpenGL / DirectX / Vulkan, in BlueStacks'
 *  settings) decides which API the frame is drawn with; it does not decide
 *  where the translation runs.
 *
 *  So: "force discrete GPU" moves RENDERING to the fast adapter. It does
 *  not move translation off the CPU, because translation is not on the GPU
 *  to begin with.
 * ===================================================================== */
#include "common.h"
#include <windows.h>
#include <stdio.h>

#define GPUKEY L"Software\\Microsoft\\DirectX\\UserGpuPreferences"

/* ------------------------------------------------------------------ */
/*  discrete-GPU preference                                           */
/* ------------------------------------------------------------------ */
static int reg_read_dword_str(const wchar_t* name, char* out, DWORD outSz)
{
    HKEY k;
    DWORD type = 0, sz = outSz;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, GPUKEY, 0, KEY_READ, &k) != ERROR_SUCCESS)
        return 0;
    if (RegQueryValueExW(k, name, NULL, &type, (LPBYTE)out, &sz) != ERROR_SUCCESS ||
        type != REG_SZ) {
        RegCloseKey(k);
        return 0;
    }
    RegCloseKey(k);
    out[outSz - 1] = 0;
    return 1;
}

int zl_gpu_pref_get(void)
{
    char buf[128];
    wchar_t path[MAX_PATH];
    DWORD n = GetModuleFileNameW(NULL, path, MAX_PATH);
    if (!n) return 0;
    if (!reg_read_dword_str(path, buf, sizeof(buf))) return 0;
    /* "GpuPreference=2;" = high performance, 1 = power saving */
    return strstr(buf, "GpuPreference=2") ? 2 : 1;
}

int zl_gpu_pref_set(int high)
{
    wchar_t path[MAX_PATH];
    HKEY k;
    LONG r;
    DWORD n = GetModuleFileNameW(NULL, path, MAX_PATH);
    if (!n) return 0;

    if (RegCreateKeyExW(HKEY_CURRENT_USER, GPUKEY, 0, NULL,
                        REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &k, NULL)
        != ERROR_SUCCESS)
        return 0;

    if (high) {
        const wchar_t* val = L"GpuPreference=2;";
        r = RegSetValueExW(k, path, 0, REG_SZ, (const BYTE*)val,
                           (DWORD)((wcslen(val) + 1) * sizeof(wchar_t)));
    } else {
        r = RegDeleteValueW(k, path);
        if (r == ERROR_FILE_NOT_FOUND) r = ERROR_SUCCESS;
    }
    RegCloseKey(k);
    return r == ERROR_SUCCESS;
}

/* ------------------------------------------------------------------ */
/*  power throttling (EcoQoS)                                         */
/* ------------------------------------------------------------------ */
#define ZL_ProcessPowerThrottling 4
#define ZL_THROTTLE_EXECUTION_SPEED 0x1

typedef struct {
    ULONG Version;
    ULONG ControlMask;
    ULONG StateMask;
} ZL_POWER_THROTTLING_STATE;

typedef BOOL (WINAPI* PFN_SetProcessInformation)(HANDLE, int, void*, DWORD);

int zl_gpu_nothrottle(int on)
{
    HMODULE k32 = GetModuleHandleA("kernel32.dll");
    PFN_SetProcessInformation spi =
        (PFN_SetProcessInformation)GetProcAddress(k32, "SetProcessInformation");
    ZL_POWER_THROTTLING_STATE st;

    if (!spi) return 0;                 /* pre-Win10 1709: nothing to set  */

    st.Version     = 1;
    st.ControlMask = ZL_THROTTLE_EXECUTION_SPEED;
    st.StateMask   = on ? 0 : ZL_THROTTLE_EXECUTION_SPEED;  /* 0 = opt out */
    return spi(GetCurrentProcess(), ZL_ProcessPowerThrottling, &st, sizeof(st))
           ? 1 : 0;
}
