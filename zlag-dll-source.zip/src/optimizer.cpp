/* =====================================================================
 *  optimizer.cpp  --  the OPTIMIZE tab back-end.
 *
 *  Ground rules taken from the ENIGMA notes: HKCU only, reversible,
 *  no service stops, no driver fiddling, no android debloat executed
 *  without an explicit second confirmation (see README -- it is left
 *  out of the automatic path on purpose).
 * ===================================================================== */
#include "common.h"

#include <tlhelp32.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <psapi.h>
#include <winreg.h>

char            g_applyLog[4096] = {0};
int             zl_pick_res_w = 0, zl_pick_res_h = 0;
volatile LONG   g_applyRunning = 0;
static CRITICAL_SECTION s_applyLogLock;
static volatile LONG s_applyLogState = 0; /* 0 uninitialized, 1 initializing, 2 ready */
static void apply_log_lock(void)
{
    if (InterlockedCompareExchange(&s_applyLogState, 1, 0) == 0) {
        InitializeCriticalSection(&s_applyLogLock);
        InterlockedExchange(&s_applyLogState, 2);
    } else {
        while (InterlockedCompareExchange(&s_applyLogState, 0, 0) != 2) Sleep(0);
    }
    EnterCriticalSection(&s_applyLogLock);
}
extern "C" void zl_apply_log_copy(char* out, size_t size)
{
    if (!out || !size) return;
    apply_log_lock();
    size_t n = strlen(g_applyLog);
    if (n >= size) n = size - 1;
    memcpy(out, g_applyLog, n); out[n] = 0;
    LeaveCriticalSection(&s_applyLogLock);
}

/* ------------------------------------------------------------------ */
void apply_log(const char* fmt, ...)
{
    char line[512];
    va_list ap; va_start(ap, fmt);
    _vsnprintf(line, sizeof(line) - 1, fmt, ap);
    va_end(ap);
    line[sizeof(line) - 1] = 0;

    apply_log_lock();
    size_t used = strlen(g_applyLog);
    if (used + strlen(line) + 2 < sizeof(g_applyLog)) {
        strcat(g_applyLog, line);
        strcat(g_applyLog, "\n");
    } else {
        /* scroll: drop the first half */
        char* nl = strchr(g_applyLog + used / 2, '\n');
        if (nl) memmove(g_applyLog, nl + 1, strlen(nl + 1) + 1);
        strcat(g_applyLog, line);
        strcat(g_applyLog, "\n");
    }
    LeaveCriticalSection(&s_applyLogLock);
    zl_log(LOG_INFO, "optimize: %s", line);
}

/* ---- run a command hidden, return exit code ----------------------- */
static int run_hidden(const char* exe, const char* args, DWORD* winPid)
{
    char cmd[1024];
    _snprintf(cmd, sizeof(cmd), "\"%s\" %s", exe, args);
    cmd[sizeof(cmd) - 1] = 0;

    STARTUPINFOA si; memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi; memset(&pi, 0, sizeof(pi));

    if (!CreateProcessA(NULL, cmd, NULL, NULL, FALSE,
                        CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        if (winPid) *winPid = 0;
        return -1;
    }
    WaitForSingleObject(pi.hProcess, 15000);
    DWORD code = (DWORD)-1;
    GetExitCodeProcess(pi.hProcess, &code);
    if (winPid) *winPid = pi.dwProcessId;
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return (int)code;
}

/* ================================================================== */
/* 1. power plan                                                      */
/* ================================================================== */
static void do_power(void)
{

    char sys[MAX_PATH] = {0};
    GetSystemDirectoryA(sys, MAX_PATH);
    strcat(sys, "\\powercfg.exe");

    /* already duplicated? then just select it */
    int rc = run_hidden(sys, "/setactive e9a42b02-d5df-448d-aa00-03f14749eb61", NULL);
    if (rc == 0) {
        apply_log("[ok] ultimate performance plan is now active");
        return;
    }
    rc = run_hidden(sys, "-duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61", NULL);
    if (rc == 0) {
        run_hidden(sys, "/setactive e9a42b02-d5df-448d-aa00-03f14749eb61", NULL);
        apply_log("[ok] ultimate performance scheme duplicated and selected");
        return;
    }
    rc = run_hidden(sys, "/setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c", NULL);
    if (rc == 0) {
        apply_log("[ok] high performance plan selected (ultimate not available)");
        return;
    }

    /* powercfg needs an elevated token even for a plain plan switch. In an
     * emulator that was started normally -- which is how everyone starts it
     * -- SetActive fails and there is nothing a DLL can do about it: you
     * cannot raise your own privileges without a UAC prompt, and a UAC prompt
     * from a background DLL is not something to do to somebody.
     *
     * Saying "locked by policy?" made this look like a bug in Z-Lag when it
     * is Windows saying no. Name the real cause and the real fix. */
    apply_log("[!!] power plan unchanged: Windows needs an administrator for "
              "this. Run BlueStacks as administrator and press this again, or "
              "set the plan once in Settings > Power. Everything else on this "
              "page works without admin.");
}

/* ================================================================== */
/* 2. HKCU gaming flags                                               */
/* ================================================================== */
static void reg_set_dword(HKEY root, const char* path, const char* name, DWORD val)
{
    HKEY k = NULL;
    if (RegCreateKeyExA(root, path, 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) != ERROR_SUCCESS) {
        apply_log("[!!] registry open failed: %s", path);
        return;
    }
    RegSetValueExA(k, name, 0, REG_DWORD, (const BYTE*)&val, sizeof(val));
    RegCloseKey(k);
}

static void do_regs(void)
{
    const char* GC = "System\\GameConfigStore";
    reg_set_dword(HKEY_CURRENT_USER, GC, "GameDVR_Enabled", 0);
    apply_log("[ok] GameDVR capture disabled");
    reg_set_dword(HKEY_CURRENT_USER, GC, "GameDVR_FSEBehaviorMode", 2);
    reg_set_dword(HKEY_CURRENT_USER, GC, "GameDVR_FSEBehavior", 2);
    reg_set_dword(HKEY_CURRENT_USER, GC, "GameDVR_HonorUserFSEBehaviorMode", 1);
    reg_set_dword(HKEY_CURRENT_USER, GC, "GameDVR_DXGIHonorFSEWindowsCompatible", 1);
    apply_log("[ok] true fullscreen behaviour forced");

    reg_set_dword(HKEY_CURRENT_USER, "SOFTWARE\\Microsoft\\GameBar", "AutoGameModeEnabled", 1);
    reg_set_dword(HKEY_CURRENT_USER, "SOFTWARE\\Microsoft\\GameBar", "UseNexusForGameBarEnabled", 0);
    apply_log("[ok] Game Mode on, Game Bar switcher off");

    reg_set_dword(HKEY_CURRENT_USER,
                  "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\GameDVR",
                  "AppCaptureEnabled", 0);
    apply_log("[ok] app capture off");
}

static void do_regs_revert(void)
{
    const char* GC = "System\\GameConfigStore";
    reg_set_dword(HKEY_CURRENT_USER, GC, "GameDVR_Enabled", 1);
    reg_set_dword(HKEY_CURRENT_USER, GC, "GameDVR_FSEBehaviorMode", 0);
    reg_set_dword(HKEY_CURRENT_USER, GC, "GameDVR_FSEBehavior", 0);
    reg_set_dword(HKEY_CURRENT_USER,
                  "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\GameDVR",
                  "AppCaptureEnabled", 1);
    apply_log("[ok] gaming flags restored to Windows defaults");
}

/* ================================================================== */
/* 3. process priority + working set                                  */
/* ================================================================== */
static DWORD find_host_pid(void)
{
    if (g_state.pid) return g_state.pid;
    return GetCurrentProcessId();
}

static void do_priority(void)
{
    DWORD pid = find_host_pid();
    HANDLE h = OpenProcess(PROCESS_SET_INFORMATION | PROCESS_QUERY_INFORMATION,
                           FALSE, pid);
    if (!h) { apply_log("[!!] could not open the emulator process"); return; }
    DWORD before = GetPriorityClass(h);
    if (before == HIGH_PRIORITY_CLASS || before == REALTIME_PRIORITY_CLASS) {
        apply_log("[i] priority already above the gentle setting; left unchanged");
    } else if (SetPriorityClass(h, ABOVE_NORMAL_PRIORITY_CLASS)) {
        apply_log("[ok] emulator priority set to above normal for this session");
    } else {
        apply_log("[!!] emulator priority was not changed (error %lu)", GetLastError());
    }
    CloseHandle(h);
}

typedef BOOL (WINAPI* PFN_EmptyWorkingSet)(HANDLE);
typedef BOOL (WINAPI* PFN_SetProcessWorkingSetSizeEx)(HANDLE, SIZE_T, SIZE_T, ULONG);
typedef BOOL (WINAPI* PFN_SetProcessInformation)(HANDLE, DWORD, void*, DWORD);

static void do_trim(void)
{
    DWORD pid = find_host_pid();
    HANDLE h = OpenProcess(PROCESS_SET_QUOTA | PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!h) { apply_log("[!!] cannot open pid %lu for trim", pid); return; }

    HMODULE ps = GetModuleHandleA("psapi.dll");
    PFN_EmptyWorkingSet ews = ps ? (PFN_EmptyWorkingSet)GetProcAddress(ps, "EmptyWorkingSet") : NULL;
    BOOL ok = ews ? ews(h) : FALSE;

    if (ok) apply_log("[ok] working set trimmed on pid %lu", pid);
    else    apply_log("[!!] EmptyWorkingSet unavailable/failed");
    CloseHandle(h);
}

/* ================================================================== */
/* 3b. timer resolution + GPU preference                              */
/* ================================================================== */
/* Both of these are no-admin and both are real. A 1 ms timer stops the
 * scheduler from batching this process up in 15.6 ms slots, which shows
 * up as frame-time jitter more than as frame rate; the per-app GPU
 * preference tells the driver this exe wants the discrete adapter
 * instead of whatever Windows picked. Neither is a miracle, and the log
 * says exactly what was written rather than claiming a speed-up. */
static void do_timer_res(void)
{
    static volatile LONG active = 0;
    if (InterlockedCompareExchange(&active, 1, 0) != 0) {
        apply_log("[i] 1 ms timer request is already active for this session");
        return;
    }
    HMODULE wm = LoadLibraryA("winmm.dll");
    if (!wm) {
        InterlockedExchange(&active, 0);
        apply_log("[!!] timer resolution left unchanged");
        return;
    }
    typedef UINT (WINAPI* PFN_TBP)(UINT);
    PFN_TBP tbp = (PFN_TBP)GetProcAddress(wm, "timeBeginPeriod");
    if (!tbp || tbp(1) != 0) {
        InterlockedExchange(&active, 0);
        FreeLibrary(wm);
        apply_log("[!!] timer request was refused");
        return;
    }
    apply_log("[ok] 1 ms timer requested for this session (released on exit)");
}

static void do_gpu_pref(void)
{
    char exe[MAX_PATH];
    if (!GetModuleFileNameA(NULL, exe, MAX_PATH)) {
        apply_log("[!!] cannot read own exe path -- GPU preference skipped");
        return;
    }
    const char* key = "Software\\Microsoft\\DirectX\\UserGpuPreferences";
    HKEY k;
    if (RegCreateKeyExA(HKEY_CURRENT_USER, key, 0, NULL, 0, KEY_SET_VALUE,
                        NULL, &k, NULL) != ERROR_SUCCESS) {
        apply_log("[!!] cannot open UserGpuPreferences");
        return;
    }
    const char* val = "GpuPreference=2;";     /* 2 = high performance */
    LONG r = RegSetValueExA(k, exe, 0, REG_SZ, (const BYTE*)val,
                            (DWORD)strlen(val) + 1);
    RegCloseKey(k);
    if (r == ERROR_SUCCESS)
        apply_log("[ok] GPU preference: high performance for %s", g_state.exeName);
    else
        apply_log("[!!] RegSetValueEx failed (%ld)", (long)r);
}

/* ================================================================== */
/* 4. android-side debloat (opt-in, explicit)                         */
/* ================================================================== */
/* The EXACT package lists from the recovered optimization module.
 * Nothing here runs automatically; the button is hidden behind a
 * confirmation and it is not wired into any auto path.                */
static const char* ZL_BLOAT_UNINSTALL[] __attribute__((unused)) = {
    "com.android.calendar", "com.android.contacts", "com.android.dialer",
    "com.android.camera2", "com.android.deskclock", "com.android.gallery3d",
    "com.android.bookmarkprovider", "com.android.htmlviewer",
    "com.android.wallpaper.livepicker", "com.android.wallpapercropper",
    "com.android.wallpaperpicker", "com.android.printspooler",
    "com.android.printservice.recommendation", "com.android.bips",
    "com.android.providers.calendar", "com.android.providers.blockednumber",
    "com.android.providers.userdictionary", "com.android.statementservice",
    "com.android.simappdialog", "com.android.carrierconfig",
    "com.android.carrierdefaultapp", "com.android.cts.priv.ctsshim",
    "com.android.cts.ctsshim",
    "com.android.internal.display.cutout.emulation.corner",
    "com.android.internal.display.cutout.emulation.double",
    "com.android.internal.display.cutout.emulation.tall",
    "com.android.companiondevicemanager", "com.android.traceur",
    "com.android.settings.intelligence", "com.android.storagemanager",
    "com.android.sharedstoragebackup", "com.android.backupconfirm",
    "com.android.vpndialogs", "com.android.provision",
    "com.android.onetimeinitializer", "com.android.calculator2",
    "com.android.email",
    "gg.now.billing.service", "gg.now.billing.service2", "gg.now.accounts",
    "com.google.android.onetimeinitializer",
    "com.google.android.syncadapters.contacts",
    "com.google.android.syncadapters.calendar",
    "com.google.android.partnersetup",
    "com.google.android.backuptransport",
    "com.google.android.play.games",
    NULL
};

extern "C" void zl_optimizer_debloat(int disabledOnly)
{
    char adb[MAX_PATH] = {0};
    /* HD-Adb.exe lives in the BlueStacks install dir */
    const char* cand[] = {
        "C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe",
        "C:\\Program Files\\BlueStacks\\HD-Adb.exe",
        "C:\\Program Files (x86)\\BlueStacks\\HD-Adb.exe",
        NULL
    };
    for (int i = 0; cand[i] && !adb[0]; i++)
        if (GetFileAttributesA(cand[i]) != INVALID_FILE_ATTRIBUTES)
            lstrcpynA(adb, cand[i], MAX_PATH);

    if (!adb[0]) {
        apply_log("[!!] HD-Adb.exe not found -- debloat skipped");
        return;
    }
    apply_log("[..] adb: %s (debloat is opt-in and needs a connected instance)", adb);
    if (disabledOnly) apply_log("[--] dry run only, nothing was changed");
}

/* ================================================================== */
extern "C" void zl_optimizer_run(int mask)
{
    InterlockedExchange(&g_applyRunning, 1);
    apply_log("--- tuning pass ---");

    if (mask & ZL_APPLY_POWER)    do_power();
    if (mask & ZL_APPLY_REGS)     do_regs();
    if (mask & ZL_APPLY_REGS_OFF) do_regs_revert();
    if (mask & ZL_APPLY_PRIORITY) do_priority();
    if (mask & ZL_APPLY_TRIM)     do_trim();
    if (mask & ZL_APPLY_TIMER)    do_timer_res();
    if (mask & ZL_APPLY_GPUPREF)  do_gpu_pref();
    if (mask & ZL_APPLY_VSYNC)    apply_log("[ok] vsync override %s", g_cfg.vsyncOff ? "on" : "off");

    /* Android boot script -- see initsh.cpp */
    if (mask & ZL_APPLY_INITSH)       zl_initsh_install();
    if (mask & ZL_APPLY_INITSH_RUN)   zl_initsh_run();
    if (mask & ZL_APPLY_INITSH_OFF)   zl_initsh_uninstall();
    if (mask & ZL_APPLY_INITSH_CHECK) zl_initsh_status();

    /* build.prop extras -- see buildprop.cpp */
    if (mask & ZL_APPLY_PROP_APPLY)   zl_buildprop_apply();
    if (mask & ZL_APPLY_PROP_PERSIST) zl_buildprop_persist();
    if (mask & ZL_APPLY_PROP_REVERT)  zl_buildprop_revert();
    if (mask & ZL_APPLY_PROP_DIFF)    zl_buildprop_diff();

    /* Android speed actions -- debloat.cpp */
    if (mask & ZL_APPLY_ANIM_OFF)   zl_android_anim(0);
    if (mask & ZL_APPLY_ANIM_ON)    zl_android_anim(1);
    if (mask & ZL_APPLY_KILLBG)     zl_android_killbg();
    if (mask & ZL_APPLY_GAMEBOOST)  zl_android_gameboost();
    if (mask & ZL_APPLY_GMS_SUSPEND) zl_android_gms(1);
    if (mask & ZL_APPLY_GMS_RESUME)  zl_android_gms(0);
    if (mask & ZL_APPLY_ANDROID_CMD) {
        LONG c = InterlockedExchange((volatile LONG*)&zl_android_cmd, 0);
        if (c == 1) zl_android_deep();
        else if (c == 2) zl_android_stock();
        else if (c == 3) zl_ff_detect();
        else if (c == 4) zl_ff_optimize();
        else if (c == 5) zl_android_res(100);
        else if (c == 6) zl_android_res(85);
        else if (c == 7) zl_android_res(75);
        else if (c == 8) zl_android_res(60);
        else if (c == 9) zl_host_threadboost();
        else if (c == 10) zl_host_awake(1);
        else if (c == 11) zl_host_awake(0);
        else if (c == 13) zl_host_set_res(zl_pick_res_w, zl_pick_res_h);
        else if (c == 14) zl_host_res_native();
        else if (c == 15) zl_host_restart_explorer();
    }

    /* ADB tab -- debloat.cpp */
    if (mask & ZL_APPLY_DB_CHECK)   zl_db_scan_apps();
    if (mask & ZL_APPLY_DB_REMOVE) { /* explicit legacy recovery */
        zl_debloat_restore();
        zl_db_forget_scan();
    }
    if (mask & ZL_APPLY_DB_DISABLE) zl_db_disable_selected();
    if (mask & ZL_APPLY_DB_RESTORE) zl_db_restore_changes();
    if (mask & ZL_APPLY_DB_PRESET) {
        LONG command = InterlockedExchange(&g_dbPresetCommand, 0);
        if (command == 1) zl_db_remove_requested();
        else if (command == 2) zl_db_recover_removed();
        else apply_log("[!!] no valid requested-app action was queued");
    }
    if (mask & ZL_APPLY_DB_CONNECT)
        zl_debloat_connect(g_cfg.adbPort > 0 ? g_cfg.adbPort : 5555);
    if (mask & ZL_APPLY_DB_DISCONNECT) zl_debloat_disconnect();
    /* the ADB tab's progress bar is driven by this: clearing it here means
     * "busy" can never stick on after a pass that finished or bailed out */
    if (mask & (ZL_APPLY_DB_CHECK | ZL_APPLY_DB_REMOVE |
                ZL_APPLY_DB_DISABLE | ZL_APPLY_DB_RESTORE | ZL_APPLY_DB_PRESET |
                ZL_APPLY_DB_CONNECT | ZL_APPLY_DB_DISCONNECT))
        InterlockedExchange((volatile LONG*)&g_dbRunning, 0);

    apply_log("--- done ---");
    InterlockedExchange(&g_applyRunning, 0);
}

/* =====================================================================
 *  Host display mode: the resolution picker.
 *
 *  Changing the desktop mode makes the driver rebuild the swap chain and
 *  gives the emulator's window a fresh surface, which is why "my FPS
 *  dropped, switching resolution fixed it" is a thing.
 *
 *  Safety: the mode in use is read and remembered first, and "Back to
 *  native" always returns to it. If a change is refused, the driver's code
 *  is logged rather than the failure being swallowed.
 * ===================================================================== */
static DEVMODEA s_origMode;
static int      s_haveOrigMode = 0;

static void save_orig_mode(void)
{
    if (s_haveOrigMode) return;
    ZeroMemory(&s_origMode, sizeof(s_origMode));
    s_origMode.dmSize = sizeof(s_origMode);
    /* the mode the user has chosen in Windows, not whatever is current */
    if (EnumDisplaySettingsA(NULL, ENUM_REGISTRY_SETTINGS, &s_origMode))
        s_haveOrigMode = 1;
    else if (EnumDisplaySettingsA(NULL, ENUM_CURRENT_SETTINGS, &s_origMode))
        s_haveOrigMode = 1;
}

static LONG display_set(int w, int h)
{
    DEVMODEA dm;
    ZeroMemory(&dm, sizeof(dm));
    dm.dmSize = sizeof(dm);
    if (!EnumDisplaySettingsA(NULL, ENUM_CURRENT_SETTINGS, &dm)) return -999;
    dm.dmPelsWidth  = (DWORD)w;
    dm.dmPelsHeight = (DWORD)h;
    dm.dmFields     = DM_PELSWIDTH | DM_PELSHEIGHT;
    return ChangeDisplaySettingsA(&dm, 0);
}

extern "C" void zl_host_set_res(int w, int h)
{
    save_orig_mode();
    LONG r = display_set(w, h);
    if (r == DISP_CHANGE_SUCCESSFUL)
        apply_log("[ok] display is now %dx%d", w, h);
    else
        apply_log("[!!] %dx%d was refused by the driver (code %ld) -- mode unchanged",
                  w, h, (long)r);
}

extern "C" void zl_host_res_native(void)
{
    save_orig_mode();
    if (!s_haveOrigMode) { apply_log("[!!] no saved mode to go back to"); return; }
    LONG r = display_set((int)s_origMode.dmPelsWidth, (int)s_origMode.dmPelsHeight);
    apply_log(r == DISP_CHANGE_SUCCESSFUL
              ? "[ok] back to your Windows resolution: %dx%d"
              : "[!!] restore refused (code %ld)",
              (int)s_origMode.dmPelsWidth, (int)s_origMode.dmPelsHeight, (long)r);
}

extern "C" void zl_host_restart_explorer(void)
{
    char sys[MAX_PATH] = {0};
    GetSystemDirectoryA(sys, MAX_PATH);
    char tk[MAX_PATH];
    _snprintf(tk, sizeof(tk), "%s\\taskkill.exe", sys);
    tk[sizeof(tk) - 1] = 0;
    run_hidden(tk, "/f /im explorer.exe", NULL);
    Sleep(600);
    STARTUPINFOA si; ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    PROCESS_INFORMATION pi; ZeroMemory(&pi, sizeof(pi));
    char exe[MAX_PATH] = {0};
    GetWindowsDirectoryA(exe, MAX_PATH);
    strcat(exe, "\\explorer.exe");
    if (CreateProcessA(NULL, exe, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
        apply_log("[ok] Explorer restarted (start menu and taskbar came back)");
    } else {
        apply_log("[!!] Explorer did not restart (err %lu) -- start it from Task Manager",
                  GetLastError());
    }
}
