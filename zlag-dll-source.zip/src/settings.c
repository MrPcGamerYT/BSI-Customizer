/* =====================================================================
 *  settings.c  --  logging (file + in-memory ring) and zlag.ini
 * ===================================================================== */
#include "common.h"
#include "strings.h"
#include <stdarg.h>

/* Bumped whenever the default for autoOpen changes. A config written under
 * an older policy cannot prove the user *chose* the old value, so the
 * shipped default wins once and the file is rewritten. After that the user's
 * own toggle is authoritative forever. */
#define ZL_AUTOOPEN_POLICY 2

ZLagSettings g_cfg = {
    /* Designated initialisers on purpose: this struct gains fields, and a
     * positional list silently shifts every value after the insertion point
     * (a stray 1 once landed in bannerFrames and autoOpen read as 0). */
    .masterOn      = 1,
    .sat = 0.0f, .con = 0.0f, .shp = 0.0f, .blm = 0.0f,
    .lift = 0.0f, .vig = 0.0f, .hdr = 0.0f, .amb = 0.0f,
    .mblur = 0.0f, .warm = 0.0f, .fxaa = 0.0f, .flow = 1.0f,
    .vsyncOff      = 1,
#ifdef ZL_DEFAULT_MENUWINDOW
    .menuWindow    = 1,     /* this product IS the external window */
    .menuX = -1, .menuY = -1, .menuW = 0, .menuH = 0,
    .adbPort = 5555,
    .fpsBoost = 1.0f,
    .sres = 0.0f,
    .rcas = 0.0f,
#else
    .menuWindow    = 0,
#endif
    .fpsCap        = 0,
    .showOsd       = 1,
    .hotkeyCtrl    = 0,     /* F2 toggles the panel; see ZL_TOGGLE_VK */
    .hotkeyVk      = ZL_TOGGLE_VK,
    .maxFpsBound   = 0,
    .helpSeen      = 0,
    .launcherForced = 0,
    .autoOpen      = 1,     /* open the panel as soon as the host draws */
    .autoOpenPolicy = ZL_AUTOOPEN_POLICY,
    .bannerFrames  = 0,
    .liteOn        = 0,     /* stock look until the user asks for it */
    .litePct       = 10.0f,
    .liteBias      = 0.0f,
    .fpsMulPct     = 0,
    .roundRadius   = 0,
    .liteSuper     = 0,
    .liteProtect   = 512,
    .gpuPref       = 0,   /* characters and UI stay sharp by default */
};

ZLagState g_state = {0};

/* ------------------------------------------------------------------ */
/*  log ring                                                          */
/* ------------------------------------------------------------------ */
#define LOG_RING_N   256
#define LOG_RING_LEN 320

static char  s_ring[LOG_RING_N][LOG_RING_LEN];
static LONG  s_ringHead = 0;

static char  s_dir[MAX_PATH];
static char  s_logPath[MAX_PATH];
static char  s_diagPath[MAX_PATH];
static int   s_ready = 0;
static CRITICAL_SECTION s_cs;
static int   s_csInit = 0;

int zl_log_ring_count(void) { return (int)ZL_MIN(s_ringHead, (LONG)LOG_RING_N); }

const char* zl_log_ring_get(int age)
{
    LONG n = ZL_MIN(s_ringHead, (LONG)LOG_RING_N);
    if (age < 0 || age >= n) return "";
    LONG idx = (s_ringHead - 1 - age) % LOG_RING_N;
    if (idx < 0) idx += LOG_RING_N;
    return s_ring[idx];
}

static void ring_push(int level, const char* text)
{
    static const char* tag[4] = { "i", "+", "!", "x" };
    LONG idx = s_ringHead % LOG_RING_N;
    _snprintf(s_ring[idx], LOG_RING_LEN, "[%s] %s", tag[level & 3], text);
    s_ring[idx][LOG_RING_LEN - 1] = 0;
    InterlockedIncrement(&s_ringHead);
}

/* ------------------------------------------------------------------ */
/* Override where zlag.ini and zlag.log live. Called before zl_log_init()
 * by a build that is loaded from somewhere other than where the user's
 * files are. */
void zl_cfg_set_dir(const char* dir)
{
    if (dir && dir[0]) lstrcpynA(s_dir, dir, MAX_PATH);
}

const char* zl_cfg_ini_path(char* buf, DWORD n)
{
    if (!s_dir[0]) {
        HMODULE self = NULL;
        GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)&zl_cfg_ini_path, &self);
        char full[MAX_PATH] = {0};
        GetModuleFileNameA(self, full, MAX_PATH);
        char* p = strrchr(full, '\\');
        if (p) *p = 0;
        lstrcpynA(s_dir, full, MAX_PATH);
    }
    _snprintf(buf, n, "%s\\zlag.ini", s_dir);
    buf[n - 1] = 0;
    return buf;
}

void zl_log_init(void)
{
    if (s_csInit) return;
    InitializeCriticalSection(&s_cs);
    s_csInit = 1;

    char ini[MAX_PATH];
    zl_cfg_ini_path(ini, MAX_PATH);
    lstrcpynA(s_logPath, ini, MAX_PATH);
    char* p = strrchr(s_logPath, '\\');
    if (p) lstrcpynA(p + 1, "zlag.log", MAX_PATH - (int)(p - s_logPath));

    /* rotate at 1 MB */
    FILE* f = fopen(s_logPath, "rb");
    if (f) {
        fseek(f, 0, SEEK_END);
        long sz = ftell(f);
        fclose(f);
        if (sz > 1024 * 1024) {
            char old[MAX_PATH];
            _snprintf(old, MAX_PATH, "%s.old", s_logPath);
            DeleteFileA(old);
            MoveFileA(s_logPath, old);
        }
    }
    s_ready = 1;
}

void zl_log(int level, const char* fmt, ...)
{
    if (!s_csInit) return;
    EnterCriticalSection(&s_cs);

    FILE* f = s_ready ? fopen(s_logPath, "a") : NULL;
    if (f) {
        SYSTEMTIME st; GetLocalTime(&st);
        static const char* tag[4] = { "i", "+", "!", "x" };
        fprintf(f, "[%02d:%02d:%02d.%03d] [%s] ", st.wHour, st.wMinute,
                st.wSecond, st.wMilliseconds, tag[level & 3]);
        va_list ap; va_start(ap, fmt);
        vfprintf(f, fmt, ap);
        va_end(ap);
        fputc('\n', f);
        fclose(f);
    }

    {
        char tmp[LOG_RING_LEN];
        va_list ap; va_start(ap, fmt);
        _vsnprintf(tmp, LOG_RING_LEN - 1, fmt, ap);
        va_end(ap);
        tmp[LOG_RING_LEN - 1] = 0;
        ring_push(level, tmp);
    }

    LeaveCriticalSection(&s_cs);
}

void zl_log_hexdump_quiet(void) {}

/* ------------------------------------------------------------------ */
/*  ini                                                               */
/* ------------------------------------------------------------------ */
static void trim(char* s)
{
    char* p = s;
    while (*p == ' ' || *p == '\t') p++;
    if (p != s) memmove(s, p, strlen(p) + 1);
    size_t n = strlen(s);
    while (n && (s[n-1] == '\n' || s[n-1] == '\r' || s[n-1] == ' ' || s[n-1] == '\t'))
        s[--n] = 0;
}

static int sawAutoOpen = 0;
static int sawPolicy   = 0;
static int policyFromFile = 0;
static int autoOpenFromFile = 1;

void zl_settings_load(void)
{
    char ini[MAX_PATH];
    zl_cfg_ini_path(ini, MAX_PATH);

    FILE* f = fopen(ini, "r");
    if (!f) { zl_settings_save(); return; }

    char line[512];
    while (fgets(line, sizeof(line), f)) {
        trim(line);
        if (!line[0] || line[0] == ';' || line[0] == '#' || line[0] == '[') continue;
        char* eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        char* k = line; char* v = eq + 1;
        trim(k); trim(v);

        if      (!_stricmp(k, "master"))   g_cfg.masterOn  = atoi(v);
        else if (!_stricmp(k, "sat"))      g_cfg.sat       = (float)atof(v);
        else if (!_stricmp(k, "con"))      g_cfg.con       = (float)atof(v);
        else if (!_stricmp(k, "shp"))      g_cfg.shp       = (float)atof(v);
        else if (!_stricmp(k, "blm"))      g_cfg.blm       = (float)atof(v);
        else if (!_stricmp(k, "lift"))     g_cfg.lift      = (float)atof(v);
        else if (!_stricmp(k, "vig"))      g_cfg.vig       = (float)atof(v);
        else if (!_stricmp(k, "hdr"))      g_cfg.hdr       = (float)atof(v);
        else if (!_stricmp(k, "amb"))      g_cfg.amb       = (float)atof(v);
        else if (!_stricmp(k, "mblur"))    g_cfg.mblur     = (float)atof(v);
        else if (!_stricmp(k, "warm"))     g_cfg.warm      = (float)atof(v);
        else if (!_stricmp(k, "fxaa"))     g_cfg.fxaa      = (float)atof(v);
        else if (!_stricmp(k, "flow"))     g_cfg.flow      = (float)atof(v);
        else if (!_stricmp(k, "vsyncoff")) g_cfg.vsyncOff  = atoi(v);
#ifdef ZL_DEFAULT_MENUWINDOW
        /* An old ini must not switch this external-window build into the
         * obsolete host-overlay mode. */
        else if (!_stricmp(k, "menuwindow")) g_cfg.menuWindow = 1;
#else
        else if (!_stricmp(k, "menuwindow")) g_cfg.menuWindow = atoi(v);
#endif
        else if (!_stricmp(k, "menux"))    g_cfg.menuX = atoi(v);
        else if (!_stricmp(k, "menuy"))    g_cfg.menuY = atoi(v);
        else if (!_stricmp(k, "menuw"))    g_cfg.menuW = atoi(v);
        else if (!_stricmp(k, "menuh"))    g_cfg.menuH = atoi(v);
        else if (!_stricmp(k, "adbport"))  g_cfg.adbPort = atoi(v);
        else if (!_stricmp(k, "rcas")) {
            float f = (float)atof(v);
            g_cfg.rcas = (f >= 0.0f && f <= 1.0f) ? f : 0.0f;
        }
        else if (!_stricmp(k, "sres")) {
            float f = (float)atof(v);
            g_cfg.sres = (f >= 0.0f && f <= 1.0f) ? f : 0.0f;
        }
        /* "fpsboost" from older ini files is ignored on purpose: the
         * display multiplier is gone and the timer's number is the number. */
        else if (!_stricmp(k, "fpscap"))   g_cfg.fpsCap    = atoi(v);
        else if (!_stricmp(k, "liteon"))   g_cfg.liteOn    = atoi(v) ? 1 : 0;
        else if (!_stricmp(k, "liteprotect")) g_cfg.liteProtect = atoi(v);
        else if (!_stricmp(k, "gpupref"))  g_cfg.gpuPref = atoi(v) ? 1 : 0;
        else if (!_stricmp(k, "liteSuper")) g_cfg.liteSuper = atoi(v) ? 1 : 0;
        else if (!_stricmp(k, "roundradius")) { g_cfg.roundRadius = atoi(v);
                                             if (g_cfg.roundRadius < 0)  g_cfg.roundRadius = 0;
                                             if (g_cfg.roundRadius > 40) g_cfg.roundRadius = 40; }
        /* The display multiplier is NEVER restored from disk. It hooks the
         * CRT's string formatter, which is called during process start-up,
         * and a saved "on" means every launch arms that hook before the
         * panel exists. It is a per-session cosmetic switch now: you turn it
         * on in the panel or it stays off. */
        else if (!_stricmp(k, "fpsmul"))    { g_cfg.fpsMulPct = 0; (void)v; }
        else if (!_stricmp(k, "_fpsmul_old")) { g_cfg.fpsMulPct = atoi(v);
                                             if (g_cfg.fpsMulPct < 0)   g_cfg.fpsMulPct = 0;
                                             if (g_cfg.fpsMulPct > 300) g_cfg.fpsMulPct = 300; }
        else if (!_stricmp(k, "litebias")) { g_cfg.liteBias = (float)atof(v);
                                             if (g_cfg.liteBias < 0.0f)  g_cfg.liteBias = 0.0f;
                                             if (g_cfg.liteBias > 24.0f) g_cfg.liteBias = 24.0f; }
        else if (!_stricmp(k, "litepct"))  { g_cfg.litePct = (float)atof(v);
                                             if (g_cfg.litePct < 0.0f) g_cfg.litePct = 0.0f;
                                             if (g_cfg.litePct > 100.0f) g_cfg.litePct = 100.0f; }
        else if (!_stricmp(k, "osd"))      g_cfg.showOsd   = atoi(v);
        else if (!_stricmp(k, "helpseen")) g_cfg.helpSeen  = atoi(v);
        else if (!_stricmp(k, "autoopen")) {
            g_cfg.autoOpen = atoi(v);
            autoOpenFromFile = g_cfg.autoOpen;
            sawAutoOpen = 1;
        }
        else if (!_stricmp(k, "autoopenpolicy")) {
            policyFromFile = atoi(v);
            sawPolicy = 1;
        }
#ifdef ZL_DEFAULT_MENUWINDOW
        /* Old saved shortcuts cannot override the fixed F2 toggle. */
        else if (!_stricmp(k, "hotkey") || !_stricmp(k, "hotkeyctrl")) { (void)v; }
#else
        else if (!_stricmp(k, "hotkey"))   g_cfg.hotkeyVk  = atoi(v);
        else if (!_stricmp(k, "hotkeyctrl")) g_cfg.hotkeyCtrl = atoi(v);
#endif
    }
    fclose(f);
    zl_log(LOG_INFO, "settings loaded from %s (autoopen=%d%s)", ini,
           g_cfg.autoOpen, sawAutoOpen ? "" : ", default");

    /* Heal a config written under an older default. Builds up to R65
     * shipped autoOpen with the wrong default and could persist a 0 that
     * the user never asked for; without this, upgrading still starts
     * minimised with no way to tell why. A file written under the current
     * policy is left exactly as the user left it. */
    if (sawAutoOpen && policyFromFile < ZL_AUTOOPEN_POLICY) {
        g_cfg.autoOpen = 1;
        zl_log(LOG_OK, "settings from an older build (autoopen was %d) -- "
                       "policy upgraded, panel will open at startup",
               autoOpenFromFile);
        zl_settings_save();
    } else if (sawAutoOpen && !g_cfg.autoOpen) {
        zl_log(LOG_INFO, "autoopen=0 is set in %s -- panel starts closed",
               ini);
    }
    (void)sawPolicy;
}

/* Sliders used to write the ini file on every frame of a drag: a disk flush
 * per frame, which is a stall on any machine with a busy disk. Dragging now
 * marks the file dirty and the flush happens once the hand stops. */
static DWORD s_dirtyTick = 0;

void zl_settings_save_soon(void) { if (!s_dirtyTick) s_dirtyTick = GetTickCount() | 1; }

void zl_settings_tick(void)
{
    if (!s_dirtyTick) return;
    if (GetTickCount() - s_dirtyTick < 600) return;
    s_dirtyTick = 0;
    zl_settings_save();
}

void zl_settings_save(void)
{
    char ini[MAX_PATH];
    zl_cfg_ini_path(ini, MAX_PATH);
    FILE* f = fopen(ini, "w");
    if (!f) return;
    fprintf(f, "; %s v%s -- settings, safe to edit\n", ZL_NAME, ZL_VER);
    fprintf(f, "; written by %s\n", ZL_BUILD_ID);
    fprintf(f, "; the hotkey is fixed: F2.\n");
    fprintf(f, "[zlag]\n");
    fprintf(f, "master=%d\n",   g_cfg.masterOn);
    fprintf(f, "sat=%.4f\n",    g_cfg.sat);
    fprintf(f, "con=%.4f\n",    g_cfg.con);
    fprintf(f, "shp=%.4f\n",    g_cfg.shp);
    fprintf(f, "blm=%.4f\n",    g_cfg.blm);
    fprintf(f, "lift=%.4f\n",   g_cfg.lift);
    fprintf(f, "vig=%.4f\n",    g_cfg.vig);
    fprintf(f, "hdr=%.4f\n",    g_cfg.hdr);
    fprintf(f, "amb=%.4f\n",    g_cfg.amb);
    fprintf(f, "mblur=%.4f\n",  g_cfg.mblur);
    fprintf(f, "warm=%.4f\n",   g_cfg.warm);
    fprintf(f, "fxaa=%.4f\n",   g_cfg.fxaa);
    fprintf(f, "flow=%.4f\n",   g_cfg.flow);
    fprintf(f, "vsyncoff=%d\n", g_cfg.vsyncOff);
    fprintf(f, "menuwindow=%d\n", g_cfg.menuWindow);
    fprintf(f, "menux=%d\n", g_cfg.menuX);
    fprintf(f, "menuy=%d\n", g_cfg.menuY);
    fprintf(f, "menuw=%d\n", g_cfg.menuW);
    fprintf(f, "menuh=%d\n", g_cfg.menuH);
    fprintf(f, "adbport=%d\n", g_cfg.adbPort);
    fprintf(f, "fpsboost=%.2f\n", g_cfg.fpsBoost);
    fprintf(f, "sres=%.2f\n", g_cfg.sres);
    fprintf(f, "rcas=%.2f\n", g_cfg.rcas);
    fprintf(f, "fpscap=%d\n",   g_cfg.fpsCap);
    fprintf(f, "liteon=%d\n",   g_cfg.liteOn);
    fprintf(f, "litepct=%.2f\n", g_cfg.litePct);
    fprintf(f, "litebias=%.3f\n", g_cfg.liteBias);
    fprintf(f, "fpsmul=%d\n", g_cfg.fpsMulPct);
    fprintf(f, "roundradius=%d\n", g_cfg.roundRadius);
    fprintf(f, "liteSuper=%d\n", g_cfg.liteSuper);
    fprintf(f, "liteprotect=%d\n", g_cfg.liteProtect);
    fprintf(f, "gpupref=%d\n", g_cfg.gpuPref);
    fprintf(f, "osd=%d\n",      g_cfg.showOsd);
    fprintf(f, "helpseen=%d\n",  g_cfg.helpSeen);
    fprintf(f, "autoopen=%d\n",  g_cfg.autoOpen);   /* R55: open on start */
    fprintf(f, "autoopenpolicy=%d\n", ZL_AUTOOPEN_POLICY);
    fprintf(f, "hotkeyctrl=%d\n", g_cfg.hotkeyCtrl);
    fprintf(f, "hotkey=%d\n",   g_cfg.hotkeyVk);
    fclose(f);
}

/* ------------------------------------------------------------------ */
/*  private diagnostics                                                */
/*                                                                     */
/*  Crash detail is deliberately NOT written to zlag.log. It goes to a */
/*  side file as fixed-size encoded records, so the log stays a plain   */
/*  readable history for the user and the pointer arithmetic that        */
/*  describes where execution died is not sitting in text for anyone to */
/*  read off. This raises the cost of using the log as a map; it does   */
/*  not make the binary unreadable -- nothing in-process can.           */
/*                                                                     */
/*  Record: 20 bytes, fixed. 17 data bytes, all encoded:                 */
/*  [code u32][rva u64][tid u32][where u8], then 3 zero bytes.           */
/* ------------------------------------------------------------------ */
static const unsigned char s_dk[16] = {
    0x9E, 0x3B, 0x71, 0xC4, 0x2D, 0x88, 0x5F, 0x16,
    0xAB, 0x60, 0xD3, 0x39, 0x7C, 0xE5, 0x12, 0x94
};

void zl_priv_crash(unsigned int code, unsigned long long rva,
                   unsigned int tid, unsigned int where)
{
    if (!s_csInit || !s_diagPath[0]) return;

    unsigned char rec[20];
    unsigned int  st = 0x7A5C31F1u;   /* fixed seed: the decoder must
                                       * be able to start the stream without
                                       * knowing the plaintext */

    memset(rec, 0, sizeof(rec));
    memcpy(rec + 0, &code, 4);
    memcpy(rec + 4, &rva,  8);
    memcpy(rec + 12, &tid, 4);
    rec[16] = (unsigned char)(where & 0xFF);

    for (int i = 0; i < 17; i++) {
        st = st * 1664525u + 1013904223u;
        rec[i] ^= (unsigned char)((st >> 17) & 0xFF) ^ s_dk[i & 15];
    }

    EnterCriticalSection(&s_cs);
    {
        /* keep it small */
        FILE* f = fopen(s_diagPath, "rb");
        if (f) { fseek(f, 0, SEEK_END); long sz = ftell(f); fclose(f);
                 if (sz > 65536) DeleteFileA(s_diagPath); }
        f = fopen(s_diagPath, "ab");
        if (f) { fwrite(rec, 1, sizeof(rec), f); fclose(f); }
    }
    LeaveCriticalSection(&s_cs);
}
