/* =====================================================================
 *  presets.c  --  one-click looks (only slider values, nothing global)
 *  order: sat con shp blm lift vig hdr amb mblur warm fxaa
 * ===================================================================== */
#include "common.h"

static const ZLagPreset s_presets[] = {
    { "Neutral (bit-exact)", { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      "everything off - the frame is exactly what the emulator drew" },

    { "BP9 Competitive",     { -0.10f, 0.12f, 0.28f, 0.0f, 0.0f, 0.10f, 0.00f, 0.0f, 0.0f, 0.0f, 0.35f },
      "sharp, slightly cold, tiny vignette - best for reading enemies" },

    { "Cinematic",           { 0.18f, 0.16f, 0.10f, 0.35f, 0.06f, 0.28f, 0.22f, 0.12f, 0.22f, 0.03f, 0.30f },
      "bloom + hdr pop + warmth, soft corners, light camera smear" },

    { "HDR Pop",             { 0.10f, 0.22f, 0.14f, 0.22f, 0.0f, 0.08f, 0.55f, 0.0f, 0.0f, 0.0f, 0.25f },
      "the pivot-locked s-curve pushed hard - punchy highlights" },

    { "Moonlight",           { -0.22f, 0.10f, 0.08f, 0.18f, 0.10f, 0.22f, 0.05f, 0.42f, 0.10f, -0.06f, 0.20f },
      "ambient blue floor everywhere the luma falls off" },

    { "Anime / Cel",         { 0.30f, 0.05f, 0.45f, 0.10f, 0.0f, 0.0f, 0.10f, 0.0f, 0.0f, 0.04f, 0.55f },
      "saturation + strong edge crispening, no blur stages" },

    { "Max FPS",             { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      "uses no shader passes at all - pair with vsync off" },
};

int zl_preset_count(void) { return (int)(sizeof(s_presets) / sizeof(s_presets[0])); }

const ZLagPreset* zl_preset_get(int i)
{
    if (i < 0 || i >= zl_preset_count()) return NULL;
    return &s_presets[i];
}

void zl_apply_preset(int i)
{
    const ZLagPreset* p = zl_preset_get(i);
    if (!p) return;
    g_cfg.sat   = p->v[0];
    g_cfg.con   = p->v[1];
    g_cfg.shp   = p->v[2];
    g_cfg.blm   = p->v[3];
    g_cfg.lift  = p->v[4];
    g_cfg.vig   = p->v[5];
    g_cfg.hdr   = p->v[6];
    g_cfg.amb   = p->v[7];
    g_cfg.mblur = p->v[8];
    g_cfg.warm  = p->v[9];
    g_cfg.fxaa  = p->v[10];

    if (i == zl_preset_count() - 1) {   /* Max FPS */
        g_cfg.masterOn = 1;
        g_cfg.vsyncOff = 1;
    } else {
        g_cfg.masterOn = 1;
    }
    zl_log(LOG_OK, "preset '%s' applied", p->name);
}
