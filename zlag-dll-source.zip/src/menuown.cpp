/* =====================================================================
 *  menuown.cpp  --  the entry point for the injected (non-proxy) build
 *
 *  The proxy build is loaded by the loader because the host imports
 *  version.dll. An injected build has nobody to call it, so the injector
 *  calls this. Everything after this line is identical: same hooks, same
 *  overlay, same settings file.
 * ===================================================================== */
#include "common.h"
#include "strings.h"
#include <stdio.h>

static LONG g_ownDeferred = 0;

/* Beacon first thing, before anything that could fail or deadlock: if the
 * file appears, the worker ran; if it does not, the worker never started
 * and the problem is the attach, not the overlay. Written next to the
 * module so it lands in the folder the DLL was loaded from. */
static void own_beacon(const char* what)
{
    char path[MAX_PATH] = {0};
    HMODULE self = NULL;
    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCSTR)&own_beacon, &self);
    DWORD length = GetModuleFileNameA(self, path, MAX_PATH);
    if (!length || length >= MAX_PATH) return;
    char* p = strrchr(path, '\\');
    if (!p) return;
    ++p;
    lstrcpynA(p, "zlag-attach.txt", MAX_PATH - (int)(p - path));
    FILE* f = fopen(path, "a");
    if (f) { fprintf(f, "%s\n", what); fclose(f); }
}

/* Every module the injector stages lives in the user's temp folder, so
 * "next to the DLL" would put zlag.ini and zlag.log somewhere nobody will
 * ever find them. The settings belong beside the Z-Lag.exe the user ran.
 * This runs before zl_log_init(), which is what caches the directory. */
static void own_use_launcher_dir(void)
{
    HMODULE self = NULL;
    GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       (LPCSTR)&own_use_launcher_dir, &self);
    /* Z-Lag.exe leaves zlag-dir.txt beside the staged copy, containing the
     * folder the user launched from. That is where zlag.ini and zlag.log
     * belong -- not in a temp directory nobody will look in. */
    char payload[MAX_PATH] = {0};
    DWORD payloadLength = GetModuleFileNameA(self, payload, MAX_PATH);
    if (!payloadLength || payloadLength >= MAX_PATH) return;
    char* slash = strrchr(payload, '\\');
    if (slash) {
        char hint[MAX_PATH];
        lstrcpynA(hint, payload, MAX_PATH);
        char* hl = strrchr(hint, '\\');
        if (hl) lstrcpynA(hl + 1, "zlag-dir.txt", MAX_PATH - (int)(hl - hint));
        FILE* hf = fopen(hint, "r");
        if (hf) {
            char dir[MAX_PATH] = {0};
            if (fgets(dir, MAX_PATH, hf)) {
                size_t len = strlen(dir);
                while (len && (dir[len-1] == '\n' || dir[len-1] == '\r')) dir[--len] = 0;
                if (len && GetFileAttributesA(dir) != INVALID_FILE_ATTRIBUTES)
                    zl_cfg_set_dir(dir);
            }
            fclose(hf);
        }
    }
}


/* ---- HD-Player.exe only ---------------------------------------------------
 *
 * The user asked for a build that works in HD-Player.exe and nowhere else.
 * This module is the one that creates a window, starts a worker, and installs
 * the GL hooks, so the check belongs here, at the only place that decides to
 * start anything.
 *
 * Why it is worth having rather than being pedantic:
 *   - Windows loads a DLL named version.dll into ANY program that imports
 *     "version.dll" from that folder. Explorer, a game launcher, an
 *     installer -- all of them import the Windows version API. Without this
 *     check, the menu window and the GL hooks land inside a process that
 *     never asked for them.
 *   - BlueStacks itself ships HD-Service.exe and HD-Agent.exe in the same
 *     folder. They import version.dll too. Hooked there, the hooks see no
 *     OpenGL context and the menu is meaningless -- but the DLL would still
 *     be resident and could interfere with BlueStacks' own startup.
 *
 * Only HD-Player.exe starts the menu or hooks. Other processes retain the
 * ordinary forwarded Windows version APIs without our worker thread.
 */
static int zl_host_is_player(void)
{
    char exe[MAX_PATH] = {0};
    DWORD count = GetModuleFileNameA(NULL, exe, MAX_PATH);
    if (!count || count >= MAX_PATH) return 0;
    const char* leaf = strrchr(exe, '\\');
    leaf = leaf ? leaf + 1 : exe;
    return _stricmp(leaf, "HD-Player.exe") == 0;
}

static DWORD WINAPI own_worker(LPVOID)
{
    if (!zl_host_is_player()) return 0;
    own_beacon("worker started");
    /* Forward the Windows version API to the real system DLL. */
    zl_version_api_ready();
    own_beacon("host accepted: HD-Player.exe");
    own_use_launcher_dir();
    zl_log_init();
    own_beacon("log initialised");
    zl_log(LOG_OK, "%s -- %s", ZL_BANNER, "attached (injected)");
    zl_settings_load();

    char exe[MAX_PATH] = {0};
    GetModuleFileNameA(NULL, exe, MAX_PATH);
    char* leaf = strrchr(exe, '\\');
    lstrcpynA(g_state.exeName, leaf ? leaf + 1 : exe, sizeof(g_state.exeName));
    g_state.pid = GetCurrentProcessId();
    g_state.tAttachMs = GetTickCount();
    zl_log(LOG_INFO, "host: %s (pid %lu, %s-bit)", g_state.exeName,
           (unsigned long)g_state.pid, sizeof(void*) == 8 ? "64" : "32");

#ifdef ZL_DEFAULT_MENUWINDOW
    zl_external_menu_boot();     /* independent of the host renderer */
#endif
    zl_lite_apply();             /* honour a saved detail level */
    zl_hooks_install();
    zl_log(LOG_INFO, "%s", ZL_MSG_COPYRIGHT);
    return 0;
}

extern "C" __declspec(dllexport) DWORD zlag_attach(void)
{
    if (!zl_host_is_player()) return 0;
    own_beacon("zlag_attach called");
    static LONG started = 0;
    if (InterlockedExchange(&started, 1)) { own_beacon("already started"); return 1; }
    HANDLE h = CreateThread(NULL, 0, own_worker, NULL, 0, NULL);
    if (h) { CloseHandle(h); own_beacon("worker thread created"); return 1; }
    own_beacon("CreateThread FAILED");
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
        if (!zl_host_is_player()) {
            /* Not the emulator: no thread, no hooks, no window. The version
             * API functions this file also exports stay fully functional. */
            return TRUE;
        }
#ifdef ZL_MERGED
        /* One file, two ways in. Which one is this?
         *
         * PROXY LANE: the loader imported us because HD-Player.exe imports
         *   version.dll. Somebody needs the Windows version-API functions
         *   to work, and nobody is going to call zlag_attach, so start now.
         *
         * EXTERNAL LANE: Z-Lag.exe injected us with LoadLibraryA from a
         *   remote thread. Nothing imported us, nothing wants the version
         *   API, and zlag_attach is about to be called -- starting here as
         *   well would give two workers and two overlays.
         *
         * The discriminator is the importing module: in the proxy lane the
         * process's own image imports us by name, so GetModuleHandle would
         * find us already there before we were loaded. The injector's
         * LoadLibraryA has no such import to satisfy -- but the reliable
         * signal is the remote thread: the injector calls zlag_attach
         * immediately, so the external lane simply does nothing here and
         * lets zlag_attach do the starting. The proxy lane cannot rely on
         * that call, so it starts unconditionally only when this file is
         * sitting next to the emulator's own binary. That is a file-system
         * question, and it is answerable without touching the loader. */
        {
            char self[MAX_PATH] = {0}, exedir[MAX_PATH] = {0};
            DWORD selfLen = GetModuleFileNameA((HMODULE)inst, self, MAX_PATH);
            DWORD exeLen = GetModuleFileNameA(NULL, exedir, MAX_PATH);
            if (!selfLen || selfLen >= MAX_PATH || !exeLen || exeLen >= MAX_PATH)
                return TRUE; /* fail closed rather than use a truncated path */
            char* a = strrchr(self, '\\');   if (a) *a = 0;
            char* b = strrchr(exedir, '\\'); if (b) *b = 0;
            if (_stricmp(self, exedir) == 0) {
                /* we live in the emulator's folder: proxy lane, start now */
                HANDLE h = CreateThread(NULL, 0, own_worker, NULL, 0, NULL);
                if (h) CloseHandle(h);
                else InterlockedExchange(&g_ownDeferred, 1);
                return TRUE;
            }
            /* otherwise the injector owns the start, via zlag_attach */
            /* No file I/O while the loader lock is held. */
        }
#endif
        /* CreateThread from DllMain is legal (the loader lock is held but
         * a new thread does not need it to be scheduled). The worker does
         * every call that could touch the loader, and by then the lock is
         * long released. Falling back to the exported zlag_attach() keeps
         * this working on the builds where CreateThread is refused. */
        HANDLE h = CreateThread(NULL, 0, own_worker, NULL, 0, NULL);
        if (h) CloseHandle(h);
        else InterlockedExchange(&g_ownDeferred, 1);
    } else if (reason == DLL_PROCESS_DETACH) {
        InterlockedExchange(&g_state.shuttingDown, 1);
    }
    return TRUE;
}
