/* =====================================================================
 *  gpu_lanes.cpp -- the same potato, on the host's other two backends
 *
 *  The GL lane only ever sees ANGLE. BlueStacks can also hand work to
 *  D3D11 directly, and then no GL entry point is called at all. This
 *  lane catches the textures where D3D11 makes them:
 *
 *      D3D11CreateDevice / D3D11CreateDeviceAndSwapChain  (to find the
 *      device), then the device's own CreateTexture2D in its vtable.
 *
 *  Resampling happens in the same place as the GL lane -- at creation,
 *  box averaged, from the caller's own pixels -- so the result is smooth
 *  and the texture is genuinely smaller in VRAM.
 *
 *  Hard skips, because getting these wrong breaks a game rather than
 *  softening it:
 *      render targets and depth/stencil (BindFlags)
 *      any mip chain longer than one level (data layout is per level)
 *      textures with no initial data (created empty, filled later)
 *      formats other than 8-bit RGBA / BGRA variants
 *
 *  D3D12 and Vulkan are NOT here, and the panel says so rather than
 *  pretending. Both allocate through descriptor heaps and explicit
 *  memory, which is a different project, not another branch.
 * ===================================================================== */
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "common.h"
#include "MinHook.h"

extern "C" {
volatile LONG zl_d3d_seen   = 0;
volatile LONG zl_d3d_scaled = 0;
int           zl_d3d_state  = 0;
}

/* ------------------------------------------------------------------ */
/*  minimal D3D11 shapes -- declared here so the lane does not depend  */
/*  on a particular SDK header revision                              */
/* ------------------------------------------------------------------ */
typedef struct { unsigned int Count, Quality; } DXGI_SAMPLE_DESC_M;
typedef struct {
    unsigned int Width, Height;
    unsigned int MipLevels, ArraySize;
    unsigned int Format;
    DXGI_SAMPLE_DESC_M SampleDesc;
    unsigned int Usage, BindFlags, CPUAccessFlags, MiscFlags;
} T2D_DESC_M;
typedef struct { const void* pSysMem; unsigned int SysMemPitch, SysMemSlicePitch; } SUBRES_M;

#define FMT_RGBA8      28
#define FMT_BGRA8      87
#define FMT_RGBA8_SRGB 29
#define FMT_BGRA8_SRGB 91
#define BIND_RT        0x20
#define BIND_DS        0x40

typedef HRESULT (STDMETHODCALLTYPE* PFN_CreateTexture2D)(
    void* self, const T2D_DESC_M* desc, const SUBRES_M* init, void** out);
typedef HRESULT (STDMETHODCALLTYPE* PFN_D3D11CreateDevice)(
    void*, int, HMODULE, unsigned int, const int*, unsigned int, unsigned int,
    void**, int*, void**);
typedef HRESULT (STDMETHODCALLTYPE* PFN_D3D11CreateDeviceAndSwapChain)(
    void*, int, HMODULE, unsigned int, const int*, unsigned int, unsigned int,
    const void*, void**, void**, int*, void**);

static void* s_pendingDev = NULL;      /* captured in a hook, patched on the tick */
static PFN_CreateTexture2D o_createTex2D = NULL;
static PFN_D3D11CreateDevice o_createDev = NULL;
static PFN_D3D11CreateDeviceAndSwapChain o_createDevSC = NULL;
static void**  s_devVtbl = NULL;
static void*   s_devVtblOrig = NULL;

/* ------------------------------------------------------------------ */
/*  box average, BGRA/RGBA------------------------------------------------ */
/* ------------------------------------------------------------------ */
static void* d3d_box(const unsigned char* src, unsigned int pitch,
                     unsigned int w, unsigned int h,
                     unsigned int nw, unsigned int nh, unsigned int f,
                     unsigned int* outPitch)
{
    unsigned char* dst;
    unsigned int x, y, sx, sy, c;
    unsigned int dp = nw * 4u;

    if (!src || !nw || !nh) return NULL;
    dst = (unsigned char*)malloc((size_t)dp * (size_t)nh);
    if (!dst) return NULL;

    for (y = 0; y < nh; y++) {
        for (x = 0; x < nw; x++) {
            unsigned int acc[4] = { 0, 0, 0, 0 };
            unsigned char* d = dst + (size_t)y * dp + (size_t)x * 4u;
            for (sy = 0; sy < f; sy++) {
                const unsigned char* row = src +
                    (size_t)(y * f + sy) * pitch + (size_t)(x * f) * 4u;
                for (sx = 0; sx < f; sx++) {
                    const unsigned char* p = row + (size_t)sx * 4u;
                    for (c = 0; c < 4; c++) acc[c] += p[c];
                }
            }
            for (c = 0; c < 4; c++) d[c] = (unsigned char)(acc[c] / (f * f));
        }
    }
    *outPitch = dp;
    return dst;
}

static unsigned int d3d_factor(void)
{
    float b = zl_lite_bias_now();
    if (!g_cfg.liteOn || b < 3.0f)  return 1;
    if (b < 8.0f)                   return 2;
    if (b < 16.0f)                  return 4;
    return 8;
}

static HRESULT STDMETHODCALLTYPE hk_createTex2D(void* self, const T2D_DESC_M* desc,
                                                const SUBRES_M* init, void** out)
{
    InterlockedIncrement(&zl_d3d_seen);

    if (o_createTex2D && desc && init && init->pSysMem && out) {
        unsigned int f = d3d_factor();
        unsigned int fmt = desc->Format;
        int ok = (fmt == FMT_RGBA8 || fmt == FMT_BGRA8 ||
                  fmt == FMT_RGBA8_SRGB || fmt == FMT_BGRA8_SRGB);

        if (ok && f > 1 &&
            desc->MipLevels == 1 && desc->ArraySize == 1 &&
            desc->Usage == 1 /* D3D11_USAGE_IMMUTABLE: no later updates */ &&
            desc->SampleDesc.Count == 1 && desc->MiscFlags == 0 &&
            !(desc->BindFlags & (BIND_RT | BIND_DS)) &&
            desc->Width >= 16 && desc->Height >= 16 &&
            desc->Width <= 8192 && desc->Height <= 8192 &&
            desc->Width % f == 0 && desc->Height % f == 0 &&
            init->SysMemPitch >= desc->Width * 4u) {

            /* the character rule, same threshold as the GL lane */
            int prot = (!g_cfg.liteSuper && g_cfg.liteProtect > 0) ? g_cfg.liteProtect : 0;
            unsigned int mx = desc->Width > desc->Height ? desc->Width : desc->Height;
            if (prot && (int)mx >= prot && !g_cfg.liteSuper) ok = 0;

            if (ok) {
                unsigned int nw = desc->Width / f, nh = desc->Height / f;
                unsigned int np = 0;
                void* buf = d3d_box((const unsigned char*)init->pSysMem,
                                    init->SysMemPitch,
                                    desc->Width, desc->Height, nw, nh, f, &np);
                if (buf) {
                    T2D_DESC_M nd = *desc;
                    SUBRES_M   ni;
                    HRESULT    hr;

                    nd.Width  = nw;
                    nd.Height = nh;
                    ni.pSysMem          = buf;
                    ni.SysMemPitch      = np;
                    ni.SysMemSlicePitch = 0;

                    hr = o_createTex2D(self, &nd, &ni, out);
                    free(buf);
                    if (SUCCEEDED(hr)) {
                        InterlockedIncrement(&zl_d3d_scaled);
                        return hr;
                    }
                    /* refused: fall through and create it at full size */
                }
            }
        }
    }
    return o_createTex2D(self, desc, init, out);
}

/* ------------------------------------------------------------------ */
/*  device capture + vtable slot                                       */
/* ------------------------------------------------------------------ */
static void patch_device(void* dev)
{
    void** vt;
    if (!dev || s_devVtbl) return;

    vt = *(void***)dev;
    if (!vt) return;

    s_devVtbl = vt;
    s_devVtblOrig = vt[5];                 /* ID3D11Device::CreateTexture2D */

    if (MH_CreateHook(s_devVtblOrig, (void*)&hk_createTex2D, (void**)&o_createTex2D) == MH_OK &&
        MH_EnableHook(s_devVtblOrig) == MH_OK) {
        zl_d3d_state = 1;
        zl_log(LOG_OK, "lite graphics: D3D11 CreateTexture2D hooked (device %p)", dev);
    } else {
        /* MinHook may refuse an address outside a known module image. The
         * vtable slot is writable, so write it directly as the fallback. */
        DWORD old = 0;
        if (VirtualProtect(vt + 5, sizeof(void*), PAGE_READWRITE, &old)) {
            o_createTex2D = (PFN_CreateTexture2D)vt[5];
            vt[5] = (void*)&hk_createTex2D;
            VirtualProtect(vt + 5, sizeof(void*), old, &old);
            zl_d3d_state = 1;
            zl_log(LOG_OK, "lite graphics: D3D11 CreateTexture2D patched in place");
        } else {
            zl_log(LOG_WARN, "lite graphics: could not take the D3D11 texture slot");
        }
    }
}

static HRESULT STDMETHODCALLTYPE hk_D3D11CreateDevice(
    void* adapter, int driverType, HMODULE sw, unsigned int flags,
    const int* levels, unsigned int nlevels, unsigned int sdk,
    void** dev, int* gotLevel, void** ctx)
{
    HRESULT hr = o_createDev ? o_createDev(adapter, driverType, sw, flags, levels,
                                          nlevels, sdk, dev, gotLevel, ctx)
                             : E_FAIL;
    if (SUCCEEDED(hr) && dev && *dev) s_pendingDev = *dev;   /* patched on the tick */
    return hr;
}

static HRESULT STDMETHODCALLTYPE hk_D3D11CreateDeviceAndSwapChain(
    void* adapter, int driverType, HMODULE sw, unsigned int flags,
    const int* levels, unsigned int nlevels, unsigned int sdk,
    const void* scDesc, void** sc, void** dev, int* gotLevel, void** ctx)
{
    HRESULT hr = o_createDevSC ? o_createDevSC(adapter, driverType, sw, flags, levels,
                                               nlevels, sdk, scDesc, sc, dev, gotLevel, ctx)
                               : E_FAIL;
    if (SUCCEEDED(hr) && dev && *dev) s_pendingDev = *dev;
    return hr;
}

/* Called from the frame lane, never from inside a hook: MinHook suspends
 * every other thread while it rewrites bytes, and doing that while the
 * caller is already inside one of our hooks is a deadlock waiting for a
 * slow frame. */
extern "C" void zl_d3d_tick(void)
{
    static unsigned int last = 0;
    unsigned int now = GetTickCount();

    if (!last || now - last > 2000) {
        last = now;
        zl_d3d_install();          /* no-op once armed or once tried */
    }
    if (s_pendingDev && !zl_d3d_state) {
        void* d = s_pendingDev;
        s_pendingDev = NULL;
        patch_device(d);
    }
}

/* ------------------------------------------------------------------ */
/*  install / report                                                   */
/* ------------------------------------------------------------------ */
extern "C" void zl_d3d_install(void)
{
    HMODULE h;
    if (!g_cfg.liteOn) return;          /* nothing is armed for a setting that is off */
    h = GetModuleHandleA("d3d11.dll");
    FARPROC p1, p2;
    static int tried = 0;
    if (zl_d3d_state || tried) return;

    /* NOT LoadLibrary. Forcing d3d11 into a process that never asked for it
     * is how a host ends up choosing a backend it was not going to use. We
     * only hook the library if it is already loaded, and keep looking. */
    if (!h) return;
    tried = 1;

    MH_Initialize();
    p1 = GetProcAddress(h, "D3D11CreateDevice");
    p2 = GetProcAddress(h, "D3D11CreateDeviceAndSwapChain");

    if (p1 && MH_CreateHook((void*)p1, (void*)&hk_D3D11CreateDevice,
                            (void**)&o_createDev) == MH_OK &&
        MH_EnableHook((void*)p1) == MH_OK)
        zl_log(LOG_INFO, "lite graphics: waiting for a D3D11 device");

    if (p2 && MH_CreateHook((void*)p2, (void*)&hk_D3D11CreateDeviceAndSwapChain,
                            (void**)&o_createDevSC) == MH_OK &&
        MH_EnableHook((void*)p2) == MH_OK)
        zl_log(LOG_INFO, "lite graphics: swap-chain device path armed");
}

/* What the panel shows: which host API the emulator is actually using. */
extern "C" const char* zl_backend_name(void)
{
    if (zl_d3d_state)                 return "Direct3D 11";
    if (GetModuleHandleA("vulkan-1.dll")) return "Vulkan (not supported by potato)";
    if (GetModuleHandleA("libGLESv2.dll")) return "ANGLE / GLES";
    if (GetModuleHandleA("d3d12.dll"))  return "Direct3D 12 (not supported by potato)";
    if (GetModuleHandleA("opengl32.dll")) return "OpenGL";
    return "not detected yet";
}
