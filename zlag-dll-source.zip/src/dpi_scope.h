/* DPI awareness for an individual thread, never the host process. */
#ifndef ZL_DPI_SCOPE_H
#define ZL_DPI_SCOPE_H

#include <windows.h>

typedef HANDLE (WINAPI *ZLSetThreadDpiFn)(HANDLE);

static ZLSetThreadDpiFn zl_set_thread_dpi_fn(void)
{
    static ZLSetThreadDpiFn fn = (ZLSetThreadDpiFn)(void*)GetProcAddress(
        GetModuleHandleA("user32.dll"), "SetThreadDpiAwarenessContext");
    return fn;
}

/* Use unvirtualized coordinates while this scope is alive. The original
 * thread DPI context is restored even on an early return. Windows versions
 * without per-thread contexts simply leave the current context unchanged. */
class ZLNativeDpiScope {
    ZLSetThreadDpiFn fn_;
    HANDLE previous_;
public:
    ZLNativeDpiScope() : fn_(zl_set_thread_dpi_fn()), previous_(NULL) {
        if (fn_) {
            previous_ = fn_((HANDLE)(INT_PTR)-4); /* PER_MONITOR_AWARE_V2 */
            if (!previous_) previous_ = fn_((HANDLE)(INT_PTR)-3); /* v1 */
        }
    }
    ~ZLNativeDpiScope() { if (fn_ && previous_) fn_(previous_); }
    bool active() const { return previous_ != NULL; }
private:
    ZLNativeDpiScope(const ZLNativeDpiScope&);
    ZLNativeDpiScope& operator=(const ZLNativeDpiScope&);
};

#endif
