/* =====================================================================
 *  zlag_imgui.h  --  ImGui in-process overlay (menu + OSD) interface.
 *  Everything declared here is consumed by hooks.c (plain C).
 * ===================================================================== */
#ifndef ZLAG_IMGUI_H
#define ZLAG_IMGUI_H

/* The narrowest surface the tabbed panel can lay out in. The window's own
 * width floor and the compact-mode fallback both use this one number, so
 * they cannot drift apart and silently hide the tab bar. */
#define ZL_MENU_MIN_TABBED_W   640.0f   /* sidebar + body */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---------------------------------------------------------------------
 *  Input is a QUEUE, not a set of level flags.
 *
 *  A click is two events (press, release) that routinely land inside one
 *  rendered frame -- BlueStacks presents at 30-240 Hz while a click lasts
 *  ~40-80 ms. With level flags the release overwrote the press before the
 *  UI thread ever looked, and every fast click was lost. The WndProc
 *  appends events here; the GL thread drains them in order each frame.
 * ------------------------------------------------------------------- */
#define ZL_IN_RING 128          /* must be a power of two */

enum {
    ZL_EV_POS = 1,              /* a = x, b = y        */
    ZL_EV_BTN,                  /* a = button, b = down */
    ZL_EV_WHEEL,                /* a = ticks           */
    ZL_EV_KEY,                  /* a = vk, b = down    */
    ZL_EV_CHAR                  /* a = codepoint       */
};

typedef struct ZLagEvent { LONG type, a, b; } ZLagEvent;

typedef struct ZLagInput {
    ZLagEvent      ring[ZL_IN_RING];
    volatile LONG  head;        /* producer index (monotonic) */
    volatile LONG  tail;        /* consumer index (monotonic) */
    volatile LONG  mousePos[2]; /* latest absolute position   */
} ZLagInput;

extern ZLagInput g_in;

/* optimizer actions requested from UI or console, executed by a worker */
extern volatile LONG zl_pending_apply;

/* boots ImGui on the render thread; 0 = unsupported host */
int  zl_ui_init_once(void);

/* builds + renders the panel, OSD and toasts for this frame */
int  zl_ui_frame(int w, int h);

void zl_ui_shutdown(void);

/* 1.7 s notification bubble */
void zl_ui_toast(const char* text);

#ifdef __cplusplus
}
#endif

#endif /* ZLAG_IMGUI_H */
