/* Explicit cleanup, restricted to old BlueStacks log files. Never touch
 * Windows temp, arbitrary guest files, game data, or animation snapshots. */
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "common.h"

void apply_log(const char* fmt, ...);
volatile LONG zl_pending_tempclean = 0;

typedef struct CleanStat {
    unsigned long long bytes;
    int removed, skipped;
} CleanStat;

static int old_log(const WIN32_FIND_DATAA* fd)
{
    const char* ext = strrchr(fd->cFileName, '.');
    if (!ext || _stricmp(ext, ".log") != 0) return 0;
    FILETIME nowFt;
    GetSystemTimeAsFileTime(&nowFt);
    ULARGE_INTEGER now, then;
    now.LowPart = nowFt.dwLowDateTime; now.HighPart = nowFt.dwHighDateTime;
    then.LowPart = fd->ftLastWriteTime.dwLowDateTime;
    then.HighPart = fd->ftLastWriteTime.dwHighDateTime;
    const unsigned long long week = 7ULL * 24 * 60 * 60 * 10000000ULL;
    return now.QuadPart > then.QuadPart && now.QuadPart - then.QuadPart >= week;
}

static void clean_logs(const char* dir, int depth, CleanStat* stat)
{
    if (depth > 4) return;
    DWORD attr = GetFileAttributesA(dir);
    if (attr == INVALID_FILE_ATTRIBUTES || !(attr & FILE_ATTRIBUTE_DIRECTORY) ||
        (attr & FILE_ATTRIBUTE_REPARSE_POINT)) return;
    char pattern[MAX_PATH * 2];
    int n = _snprintf(pattern, sizeof(pattern), "%s\\*", dir);
    if (n < 0 || n >= (int)sizeof(pattern)) return;
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (!strcmp(fd.cFileName, ".") || !strcmp(fd.cFileName, "..") ||
            (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)) continue;
        char full[MAX_PATH * 2];
        n = _snprintf(full, sizeof(full), "%s\\%s", dir, fd.cFileName);
        if (n < 0 || n >= (int)sizeof(full)) continue;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            clean_logs(full, depth + 1, stat);
        } else if (old_log(&fd)) {
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_READONLY) { stat->skipped++; continue; }
            if (DeleteFileA(full)) {
                stat->removed++;
                stat->bytes += ((unsigned long long)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
            } else stat->skipped++;
        }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
}

static void engine_logs(const char* engine, CleanStat* stat)
{
    DWORD attr = GetFileAttributesA(engine);
    if (attr == INVALID_FILE_ATTRIBUTES || !(attr & FILE_ATTRIBUTE_DIRECTORY) ||
        (attr & FILE_ATTRIBUTE_REPARSE_POINT)) return;
    char pat[MAX_PATH * 2];
    int n = _snprintf(pat, sizeof(pat), "%s\\*", engine);
    if (n < 0 || n >= (int)sizeof(pat)) return;
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pat, &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ||
            (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) ||
            !strcmp(fd.cFileName, ".") || !strcmp(fd.cFileName, "..")) continue;
        char sub[MAX_PATH * 2];
        n = _snprintf(sub, sizeof(sub), "%s\\%s\\Logs", engine, fd.cFileName);
        if (n >= 0 && n < (int)sizeof(sub)) clean_logs(sub, 0, stat);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
}

extern "C" void zl_host_tempclean(void)
{
    char loc[MAX_PATH] = {0}, prog[MAX_PATH] = {0}, path[MAX_PATH * 2];
    CleanStat stat = {0};
    apply_log("--- Clean old emulator logs ---");
    DWORD n = GetEnvironmentVariableA("LOCALAPPDATA", loc, MAX_PATH);
    if (n && n < MAX_PATH) {
        int count = _snprintf(path, sizeof(path), "%s\\BlueStacks_nxt\\Logs", loc);
        if (count >= 0 && count < (int)sizeof(path)) clean_logs(path, 0, &stat);
    }
    n = GetEnvironmentVariableA("ProgramData", prog, MAX_PATH);
    if (n && n < MAX_PATH) {
        int count = _snprintf(path, sizeof(path), "%s\\BlueStacks_nxt\\Logs", prog);
        if (count >= 0 && count < (int)sizeof(path)) clean_logs(path, 0, &stat);
        count = _snprintf(path, sizeof(path), "%s\\BlueStacks_nxt\\Engine", prog);
        if (count >= 0 && count < (int)sizeof(path)) engine_logs(path, &stat);
    }
    apply_log("[ok] removed %d old log files (%.1f MB); %d skipped",
              stat.removed, (double)stat.bytes / (1024.0 * 1024.0), stat.skipped);
    apply_log("[i] guest data, Windows temp, recent logs and saved settings were left alone");
}
