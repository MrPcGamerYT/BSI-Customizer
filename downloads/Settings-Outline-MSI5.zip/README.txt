MSI APP PLAYER SETTINGS OUTLINE

Target supplied by user:
C:\Program Files\BlueStacks_msi5\HD-Player.exe

1. Back up the original EXE/resource. Close every MSI App Player instance,
   including its tray process. Nothing in this package edits the EXE itself.
2. Copy BSISettingsOutline.qml to:
   C:\Program Files\BlueStacks_msi5\Assets\BSISettingsOutline.qml
   Windows may require administrator permission to copy into Program Files.
3. In the embedded UiSettingsWindow.qml, replace ONLY the existing
   UiShadowContainer { ... } block with bridge.qml.txt.
   Keep the imports, outer Window, native functions, dialogs, onClosing and
   onVisibleChanged. Do not paste this fragment over the entire resource.
4. Save with the native resource writer. Respect any capacity/mapping refusal.
   Matching compiled QML must be invalidated; restart the emulator to test.
5. Check all tabs, saving/discarding, shortcuts and closing. If the local style
   cannot load, the window shows an error; Alt+F4 uses the original close handler.

UiSettingsWindow.qml is a complete example based on the source posted in chat,
not a fresh extraction from this particular EXE. Its Qt qCompress(level 9)
payload was checked at 2,362 bytes, with a 2,701-byte limit. Your actual resource
writer remains authoritative. Native page loaders remain in the embedded QML,
so original page URLs, context, arguments and callbacks are preserved.

Do not delete/move the style asset while this bridge is installed. Restore the
original resource with matching compiled-cache handling to remove the bridge.

Tested: isolated Qt 6.8 software rendering with model/page doubles and preserved
native-style navigation/initialization/close flow. Not tested in actual MSI App
Player or Qt 5.15. No EXE was modified or Windows build produced here.
